#!/usr/bin/env python3
"""
verify_theory.py

Symbolic (sympy) and numerical (numpy/scipy/mpmath) verification of every closed form,
first-order condition, envelope derivative and limit stated in
  sections/model.tex           (Section "A Model of the Growth--Profitability Frontier")
  sections/appendix_proofs.tex (Appendices "Additional Theoretical Results" and "Proofs")
including the full-cost ceiling, the attainable and expected frontiers and the value-based generalization
(sections 20 to 27; sections 20, 25 and 26 read notes/calibration_results.json, so run code/calibrate_horizons.py first)
of "The Efficient Frontier of Growth and Profitability: A Theory of the Rule of 40
and Its Limits under AI Automation".

Run:  python3 verify_theory.py   (about two minutes)
Exit code is 0 if and only if every check passes. Section headers cite results by their LaTeX labels.

Notation follows the paper:
  g = G + lambda * sigma^alpha * h(s),  h(s) = 1 - s/sbar,  Delta = g - G
  m_op = gamma - a - sigma,  m0 = gamma - a,  m = m_op - k g   (FCF margin)
  beta = 1/alpha,  kappa = (lambda h)^(-beta),  y = X - k,  C_alpha = (1-alpha) alpha^(alpha/(1-alpha))
  R_X = X g + m
"""
import math
import sys

import mpmath as mp
import numpy as np
import sympy as sp
from scipy.optimize import minimize_scalar

mp.mp.dps = 50
RNG = np.random.default_rng(20261028)
RESULTS = []


def check(name, ok, detail=""):
    RESULTS.append((name, bool(ok)))
    tag = "PASS" if ok else "FAIL"
    print(f"[{tag}] {name}" + (f"  ::  {detail}" if detail else ""))


def header(title):
    print("\n" + "=" * 78 + f"\n{title}\n" + "=" * 78)


def log_equal(a, b):
    """For positive expressions a, b: check log(a) - log(b) == 0 after forced log expansion."""
    d = sp.expand_log(sp.log(a), force=True) - sp.expand_log(sp.log(b), force=True)
    return sp.simplify(d) == 0


def is_zero(e):
    return sp.simplify(e) == 0


# ----------------------------------------------------------------------------------------------
# Symbols (all positive so that power and log identities are valid)
# ----------------------------------------------------------------------------------------------
sig, lam, h, al, G, k, m0, X, Dl, y, s, sbar, nu = sp.symbols(
    "sigma lambda h alpha G k m_0 X Delta y s sbar nu", positive=True
)
beta = 1 / al
kappa = (lam * h) ** (-beta)
Calpha = (1 - al) * al ** (al / (1 - al))
Dstar = (lam * h) ** (1 / (1 - al)) * (al * y) ** (al / (1 - al))
sigstar_cf = (al * lam * h * y) ** (1 / (1 - al))

# ==============================================================================================
header("1. Efficient frontier (Proposition prop:frontier)")
# ==============================================================================================
g_of_sig = G + lam * sig**al * h
sig_of_D = (Dl / (lam * h)) ** (1 / al)
check("1a  sigma(Delta) inverts g(sigma):  g(sigma(Delta)) = G + Delta",
      is_zero(sp.powsimp(g_of_sig.subs(sig, sig_of_D), force=True) - G - Dl))
check("1b  kappa * Delta^beta = sigma(Delta) with kappa = (lambda h)^(-1/alpha)",
      log_equal(kappa * Dl**beta, sig_of_D))

mstar_D = m0 - k * (G + Dl) - kappa * Dl**beta  # frontier as a function of Delta = g - G
d1 = sp.diff(mstar_D, Dl)
d2 = sp.diff(mstar_D, Dl, 2)
check("1c  m*'(g) = -k - beta kappa Delta^(beta-1)",
      is_zero(d1 - (-k - beta * kappa * Dl ** (beta - 1))))
check("1d  m*''(g) = -beta (beta-1) kappa Delta^(beta-2)",
      is_zero(d2 - (-beta * (beta - 1) * kappa * Dl ** (beta - 2))))
# sign of m*'': write alpha = 1/(1+nu), nu > 0, so beta - 1 = nu > 0
d2_nu = (-beta * (beta - 1) * kappa * Dl ** (beta - 2)).subs(al, 1 / (1 + nu))
check("1e  m*'' < 0 for alpha in (0,1) (substitution alpha = 1/(1+nu), nu > 0)",
      sp.simplify(d2_nu).is_negative is True)
check("1f  slope at g = G is -k (limit Delta -> 0+ of m*')",
      sp.limit(d1.subs(al, sp.Rational(1, 2)), Dl, 0, "+") == -k
      and sp.limit(d1.subs(al, sp.Rational(3, 4)), Dl, 0, "+") == -k)

# numeric concavity / monotonicity on random draws
bad = 0
for _ in range(2000):
    a_ = RNG.uniform(0.1, 0.9)
    ell = RNG.uniform(0.05, 3.0)
    G_ = RNG.uniform(-0.05, 0.4)
    k_ = RNG.uniform(0.0, 2.0)
    m0_ = RNG.uniform(-0.2, 0.9)
    kap = ell ** (-1 / a_)
    gg = G_ + np.linspace(0, 2.0, 4001)
    mm = m0_ - k_ * gg - kap * (gg - G_) ** (1 / a_)
    sd = mm[2:] - 2 * mm[1:-1] + mm[:-2]
    if not (np.all(np.diff(mm) < 0) and np.all(sd < 1e-12 * (1 + np.abs(mm[1:-1])))):
        bad += 1
check("1g  frontier strictly decreasing and concave on 2000 random draws", bad == 0, f"violations={bad}")

# ==============================================================================================
header("2. Alternative timing convention (Lemma lem:timing)")
# ==============================================================================================
gsym = sp.symbols("g", positive=True)
mtil = m0 - k * gsym / (1 + gsym) - kappa * (gsym - G) ** beta
mtil2 = sp.diff(mtil, gsym, 2)
check("2a  alt. timing: m~''(g) = 2k/(1+g)^3 - beta(beta-1) kappa (g-G)^(beta-2)",
      is_zero(mtil2 - (2 * k / (1 + gsym) ** 3 - beta * (beta - 1) * kappa * (gsym - G) ** (beta - 2))))
check("2b  k g - k g/(1+g) = k g^2/(1+g) >= 0", is_zero(k * gsym - k * gsym / (1 + gsym) - k * gsym**2 / (1 + gsym)))

bad = 0
for _ in range(1000):
    a_ = mp.mpf(RNG.uniform(0.1, 0.45))
    ell = mp.mpf(RNG.uniform(0.05, 3.0))
    G_ = mp.mpf(RNG.uniform(0.0, 0.4))
    k_ = mp.mpf(RNG.uniform(0.05, 2.0))
    b_ = 1 / a_
    kap = ell ** (-b_)
    D_ = mp.mpf("1e-30")
    val = 2 * k_ / (1 + G_ + D_) ** 3 - b_ * (b_ - 1) * kap * D_ ** (b_ - 2)
    if not val > 0:
        bad += 1
check("2c  alpha < 1/2, k > 0: m~'' > 0 just to the right of G (1000 draws)", bad == 0, f"violations={bad}")

# explicit two-local-maxima example under the alternative timing (Lemma 1(c) in the text)
a_, G_, k_, X_, m0_, kap = 0.30, 0.10, 1.25, 1.0, 0.50, 0.50
b_ = 1 / a_
gg = np.linspace(G_, G_ + 3.0, 300001)
ftil = X_ * gg + m0_ - k_ * gg / (1 + gg) - kap * (gg - G_) ** b_
dfl = np.diff(ftil)
imax = np.where((dfl[:-1] > 0) & (dfl[1:] <= 0))[0]
deriv_at_G = X_ - k_ / (1 + G_) ** 2
check("2d  Lemma 1(c) example (alpha=0.3,k=1.25,kappa=0.5,G=0.1,m0=0.5,X=1): corner and interior local maxima",
      deriv_at_G < 0 and len(imax) == 1 and abs(ftil[0] - 0.48636) < 1e-5
      and abs(gg[imax[0] + 1] - 0.7393) < 1e-3 and abs(ftil[imax[0] + 1] - 0.5954) < 1e-3,
      f"right derivative at G={deriv_at_G:.4f}, corner score={ftil[0]:.5f}, interior argmax g={gg[imax[0] + 1]:.4f}, "
      f"score={ftil[imax[0] + 1]:.4f}")
d2_near_G = 2 * k_ / (1 + G_ + 1e-6) ** 3 - b_ * (b_ - 1) * kap * (1e-6) ** (b_ - 2)
check("2e  same example: m~ strictly convex just right of G; linear timing gives unique optimum g = G",
      d2_near_G > 0 and np.argmax(X_ * gg + m0_ - k_ * gg - kap * (gg - G_) ** b_) == 0
      and np.all(np.diff(X_ * gg + m0_ - k_ * gg - kap * (gg - G_) ** b_) < 0))
check("2f  gap between conventions at k=0.5, g=0.3 is k g^2/(1+g) = 0.0346", abs(0.5 * 0.09 / 1.3 - 0.0346) < 1e-4)

# ==============================================================================================
header("3. Maximal Rule-of-X score (Proposition prop:score)")
# ==============================================================================================
f_D = m0 + y * G + y * Dl - kappa * Dl**beta
check("3a  FOC in Delta: beta kappa Delta*^(beta-1) = X - k", log_equal(beta * kappa * Dstar ** (beta - 1), y))
check("3b  sigma* = kappa Delta*^beta = alpha (X-k) Delta*", log_equal(kappa * Dstar**beta, al * y * Dstar))
check("3c  sigma* = [alpha lambda h (X-k)]^(1/(1-alpha))", log_equal(al * y * Dstar, sigstar_cf))
f_sig = m0 + y * G + y * lam * h * sig**al - sig
check("3d  FOC in sigma: (X-k) lambda h alpha sigma*^(alpha-1) = 1",
      log_equal(y * lam * h * al * sigstar_cf ** (al - 1), sp.Integer(1)))
soc = sp.diff(f_sig, sig, 2).subs(al, 1 / (1 + nu))
check("3e  SOC in sigma: d2R/dsigma2 < 0", sp.simplify(soc).is_negative is True)
# R* = f(Delta*) = m0 + yG + y Delta* - kappa Delta*^beta = m0 + yG + (1-alpha) y Delta*  (by 3b)
Rstar_cf = m0 + y * G + (1 - al) * y * Dstar
check("3f  R* = m0 + (X-k)G + (1-alpha)(X-k)Delta*  [f(Delta*) - R* = alpha y Delta* - kappa Delta*^beta = 0 by 3b]",
      log_equal(kappa * Dstar**beta, al * y * Dstar))
Pi_cf = Calpha * (lam * h * y) ** (1 / (1 - al))
check("3g  growth surplus (1-alpha)(X-k)Delta* = C_alpha [lambda h (X-k)]^(1/(1-alpha))",
      log_equal((1 - al) * y * Dstar, Pi_cf))
check("3h  tangency: m*'(g*) = -X  (i.e. -k - beta kappa Delta*^(beta-1) = -(k + y))",
      log_equal(beta * kappa * Dstar ** (beta - 1), y))
check("3i  Delta* strictly increasing in X: d Delta*/dy = alpha/(1-alpha) Delta*/y",
      is_zero(sp.simplify(sp.diff(Dstar, y) / Dstar - al / ((1 - al) * y))))


def closed_form(m0_, G_, k_, X_, ell, a_):
    y_ = X_ - k_
    if y_ <= 0:
        return 0.0, 0.0, m0_ + y_ * G_
    D_ = ell ** (1 / (1 - a_)) * (a_ * y_) ** (a_ / (1 - a_))
    sg = a_ * y_ * D_
    return D_, sg, m0_ + y_ * G_ + (1 - a_) * y_ * D_


bad_R, bad_D, bad_corner, n_int = 0, 0, 0, 0
for _ in range(3000):
    a_ = RNG.uniform(0.15, 0.8)
    ell = RNG.uniform(0.05, 2.0)
    G_ = RNG.uniform(0.0, 0.4)
    k_ = RNG.uniform(0.0, 2.0)
    X_ = RNG.uniform(0.0, 3.5)
    m0_ = RNG.uniform(-0.2, 0.9)
    b_ = 1 / a_
    kap = ell ** (-b_)
    y_ = X_ - k_
    Dcf, scf, Rcf = closed_form(m0_, G_, k_, X_, ell, a_)

    def negf(D_):
        return -(m0_ + y_ * G_ + y_ * D_ - kap * D_**b_)

    if y_ > 0:
        n_int += 1
        D0 = (y_ / kap) ** (1 / (b_ - 1))  # root of y D = kappa D^beta: max lies in [0, D0]
        grid = np.linspace(0, D0, 20001)
        vals = -negf(grid)
        res = minimize_scalar(negf, bounds=(0, D0), method="bounded", options={"xatol": 1e-13 * max(D0, 1)})
        if not (vals.max() <= Rcf + 1e-11 * (1 + abs(Rcf)) and abs(-res.fun - Rcf) < 1e-9 * (1 + abs(Rcf))):
            bad_R += 1
        if abs(res.x - Dcf) > 1e-4 * max(Dcf, 1e-8) + 1e-9:
            bad_D += 1
    else:
        grid = np.linspace(0, 5, 5001)
        vals = -negf(grid)
        if not (np.argmax(vals) == 0 and abs(vals[0] - Rcf) < 1e-12):
            bad_corner += 1
check("3j  closed-form R* equals the numerical global maximum (interior draws)", bad_R == 0,
      f"interior draws={n_int}, violations={bad_R}")
check("3k  closed-form Delta* equals the numerical argmax (interior draws)", bad_D == 0, f"violations={bad_D}")
check("3l  X <= k: corner optimum g* = G with R* = m0 + (X-k)G", bad_corner == 0,
      f"corner draws={3000 - n_int}, violations={bad_corner}")

# high-precision spot checks of the closed forms
bad = 0
for _ in range(200):
    a_ = mp.mpf(RNG.uniform(0.1, 0.9))
    ell = mp.mpf(RNG.uniform(0.05, 3))
    y_ = mp.mpf(RNG.uniform(0.01, 3))
    b_ = 1 / a_
    kap = ell ** (-b_)
    D_ = ell ** (1 / (1 - a_)) * (a_ * y_) ** (a_ / (1 - a_))
    foc = y_ - b_ * kap * D_ ** (b_ - 1)
    sg1 = kap * D_**b_
    sg2 = (a_ * ell * y_) ** (1 / (1 - a_))
    Pi1 = y_ * D_ - sg1
    Pi2 = (1 - a_) * a_ ** (a_ / (1 - a_)) * (ell * y_) ** (1 / (1 - a_))
    if not (abs(foc) < mp.mpf("1e-40") and abs(sg1 - sg2) < mp.mpf("1e-35") * (1 + sg2)
            and abs(Pi1 - Pi2) < mp.mpf("1e-35") * (1 + Pi2)):
        bad += 1
check("3m  50-digit spot checks of FOC, sigma*, growth surplus (200 draws)", bad == 0, f"violations={bad}")

# ==============================================================================================
header("4. Saturation limit, small-base bound, demand-pull threshold (Proposition prop:saturation), myopic path (Proposition prop:myopic)")
# ==============================================================================================
Pi_h = Calpha * (lam * h * y) ** (1 / (1 - al))
check("4a  growth surplus -> 0 as h -> 0+ (s -> sbar), alpha = 1/2 and 3/4",
      sp.limit(Pi_h.subs(al, sp.Rational(1, 2)), h, 0, "+") == 0
      and sp.limit(Pi_h.subs(al, sp.Rational(3, 4)), h, 0, "+") == 0)
check("4b  dPi/dh > 0 (so R* strictly decreasing in s since h'(s) = -1/sbar < 0)",
      sp.simplify(sp.diff(Pi_h, h).subs(al, 1 / (1 + nu))).is_positive is True)

bad_mono, bad_lim = 0, 0
for _ in range(500):
    a_ = RNG.uniform(0.15, 0.8)
    lam_ = RNG.uniform(0.1, 2.0)
    G_ = RNG.uniform(0.0, 0.4)
    k_ = RNG.uniform(0.0, 1.5)
    X_ = RNG.uniform(k_ + 0.05, k_ + 3.0)
    m0_ = RNG.uniform(-0.2, 0.9)
    sbar_ = RNG.uniform(0.05, 0.95)
    ss = np.linspace(1e-9, sbar_ * (1 - 1e-9), 2001)
    floor = m0_ + (X_ - k_) * G_
    # growth surplus Pi(s) = R*(s) - R_inf, computed from the closed-form Delta*, not by subtraction
    Pis = np.array([(1 - a_) * (X_ - k_) * closed_form(m0_, G_, k_, X_, lam_ * (1 - si / sbar_), a_)[0] for si in ss])
    Pi_cf = (1 - a_) * a_ ** (a_ / (1 - a_)) * (lam_ * (1 - ss / sbar_) * (X_ - k_)) ** (1 / (1 - a_))
    if not (np.all(np.diff(Pis) < 0) and np.allclose(Pis, Pi_cf, rtol=1e-10, atol=0)):
        bad_mono += 1
    Pi0 = (1 - a_) * a_ ** (a_ / (1 - a_)) * (lam_ * (X_ - k_)) ** (1 / (1 - a_))
    if not (Pis[-1] < 1e-6 and np.all(Pis > 0) and np.all(Pis < Pi0) and abs(Pis[0] - Pi0) < 1e-6 * (1 + Pi0)):
        bad_lim += 1
check("4c  R*(s) - R_inf strictly decreasing in s and equal to C_alpha(lambda h y)^(1/(1-alpha)) (500 draws)",
      bad_mono == 0, f"violations={bad_mono}")
check("4d  0 < R*(s) - R_inf < R^0 - R_inf, -> 0 as s -> sbar and -> R^0 - R_inf as s -> 0", bad_lim == 0,
      f"violations={bad_lim}")

bad = 0
for _ in range(500):
    a_ = RNG.uniform(0.15, 0.8)
    G_ = RNG.uniform(0.0, 0.4)
    k_ = RNG.uniform(0.0, 1.5)
    X_ = RNG.uniform(k_ + 0.05, k_ + 3.0)
    m0_ = RNG.uniform(-0.2, 0.9)
    floor = m0_ + (X_ - k_) * G_
    Rbar = floor + RNG.uniform(0.01, 15)
    Ca = (1 - a_) * a_ ** (a_ / (1 - a_))
    Lam = ((Rbar - floor) / Ca) ** (1 - a_) / (X_ - k_)
    D_, sg, Rv = closed_form(m0_, G_, k_, X_, Lam, a_)
    ok = abs(Rv - Rbar) < 1e-9 * (1 + Rbar)
    ok &= abs(D_ - (Rbar - floor) / ((1 - a_) * (X_ - k_))) < 1e-8 * (1 + D_)
    ok &= abs(sg - a_ * (Rbar - floor) / (1 - a_)) < 1e-8 * (1 + sg)
    ok &= closed_form(m0_, G_, k_, X_, Lam * 0.999, a_)[2] < Rbar < closed_form(m0_, G_, k_, X_, Lam * 1.001, a_)[2]
    bad += (not ok)
check("4e  threshold Lambda(Rbar): R*(lambda h = Lambda) = Rbar; Delta*, sigma* identities at the threshold",
      bad == 0, f"violations={bad}")

# worked example used in the text: alpha = 0.3, X = 1, k = 0, m0 = 0.6, G = 0.2, Rule of 1000
a_, m0_, G_, X_, k_, Rbar = 0.3, 0.6, 0.2, 1.0, 0.0, 10.0
floor = m0_ + (X_ - k_) * G_
Ca = (1 - a_) * a_ ** (a_ / (1 - a_))
Lam = ((Rbar - floor) / Ca) ** (1 - a_) / (X_ - k_)
D_, sg, Rv = closed_form(m0_, G_, k_, X_, Lam, a_)
print(f"     Rule-of-1000 example: C_alpha={Ca:.4f}, Lambda={Lam:.4f}, Delta*={D_:.4f}, g*={G_ + D_:.4f}, "
      f"sigma*={sg:.4f}, m={m0_ - k_ * (G_ + D_) - sg:.4f}, R={Rv:.4f}")
check("4f  Rule-of-1000 example: Lambda ~ 8.71, Delta* ~ 13.14, sigma* ~ 3.94, m ~ -3.34",
      abs(Lam - 8.7086) < 1e-3 and abs(D_ - 9.2 / 0.7) < 1e-9 and abs(sg - 0.3 * 9.2 / 0.7) < 1e-9
      and abs(m0_ - sg + 3.3429) < 1e-3 and abs(Rv - 10) < 1e-9)

# Proposition prop:myopic: myopic path bound
from scipy.integrate import solve_ivp
bad = 0
for _ in range(100):
    a_ = RNG.uniform(0.15, 0.8)
    lam_ = RNG.uniform(0.2, 3.0)
    y_ = RNG.uniform(0.1, 2.5)
    u0 = RNG.uniform(0.001, 0.9)
    p_ = 1 / (1 - a_)
    nu_ = lam_ ** p_ * (a_ * y_) ** (a_ / (1 - a_))
    # integrate in h = 1 - u to keep precision near saturation: dh/dt = -nu (1 - h) h^p
    sol = solve_ivp(lambda t, hh: -nu_ * (1 - hh) * np.maximum(hh, 0) ** p_, (0, 60.0), [1 - u0],
                    rtol=1e-11, atol=1e-14, dense_output=True)
    ts = np.linspace(0, 60.0, 601)
    hs = sol.sol(ts)[0]
    Ca = (1 - a_) * a_ ** (a_ / (1 - a_))
    Pi_t = Ca * (lam_ * y_ * hs) ** p_
    bound = Ca * (lam_ * y_) ** p_ * ((1 - u0) ** (-a_ / (1 - a_)) + a_ / (1 - a_) * nu_ * u0 * ts) ** (-1 / a_)
    ok = np.all(Pi_t <= bound * (1 + 1e-7) + 1e-14) and np.all(np.diff(hs) <= 1e-14) and np.all(hs > 0)
    bad += (not ok)
check("4g  myopic path: R*(s(t)) - R_inf <= bound (eq. myopic) and decreasing along exact ODE paths (100 draws)",
      bad == 0, f"violations={bad}")

# ==============================================================================================
header("5. Score budget, sharpness and transience (Propositions prop:budget, prop:budget-sharp; Corollary cor:transient)")
# ==============================================================================================


def simulate_policy(lam_, a_, sbar_, s0, m0_, G_, k_, X_, durations, sigmas, n_sub=4000):
    """Exact logistic share path under piecewise-constant sigma (frontier margins); returns integrals."""
    y_ = X_ - k_
    u0 = s0 / sbar_
    logit = math.log(u0 / (1 - u0))
    I_pos, I_yDelta, I_Delta = 0.0, 0.0, 0.0
    for tau, sg in zip(durations, sigmas):
        nu_ = lam_ * sg**a_
        t = np.linspace(0, tau, n_sub + 1)
        h_t = 1 / (1 + np.exp(logit + nu_ * t))  # h = 1 - u
        Delta_t = nu_ * h_t
        R_minus_floor = y_ * Delta_t - sg  # R - R_inf on the frontier
        I_pos += np.trapezoid(np.maximum(R_minus_floor, 0), t)
        I_yDelta += np.trapezoid(y_ * Delta_t, t)
        I_Delta += np.trapezoid(Delta_t, t)
        logit += nu_ * tau
    log_uT = -math.log1p(math.exp(-logit)) if logit > -700 else logit
    return I_pos, I_yDelta, I_Delta, log_uT - math.log(u0), -math.log(u0), logit


bad_budget, bad_identity = 0, 0
for _ in range(400):
    a_ = RNG.uniform(0.15, 0.85)
    lam_ = RNG.uniform(0.1, 8.0)
    sbar_ = RNG.uniform(0.1, 0.9)
    s0 = sbar_ * RNG.uniform(1e-4, 0.5)
    m0_ = RNG.uniform(-0.2, 0.9)
    G_ = RNG.uniform(0.0, 0.4)
    k_ = RNG.uniform(0.0, 1.5)
    X_ = RNG.uniform(k_ + 0.05, k_ + 3.0)
    nseg = RNG.integers(1, 12)
    durations = RNG.uniform(0.05, 3.0, nseg)
    sigmas = np.where(RNG.uniform(size=nseg) < 0.2, 0.0, np.exp(RNG.normal(-1.0, 1.5, nseg)))
    I_pos, I_yD, I_D, logsT, logsbar, logitT = simulate_policy(lam_, a_, sbar_, s0, m0_, G_, k_, X_, durations, sigmas)
    y_ = X_ - k_
    # pointwise (R - R_inf)^+ <= y Delta, so the same quadrature preserves the inequality exactly
    if not (I_pos <= I_yD * (1 + 1e-12) and math.isfinite(logitT) and logsT <= logsbar):
        bad_budget += 1
    if abs(I_D - logsT) > 1e-5 * (1 + logsT):
        bad_identity += 1
check("5a  integral of Delta dt = ln(s(T)/s0) along exact share paths (400 random policies)", bad_identity == 0,
      f"violations={bad_identity}")
check("5b  integral of (R - R_inf)^+ dt <= (X-k) integral of Delta dt = (X-k) ln(s(T)/s0), with s(T) < sbar",
      bad_budget == 0, f"violations={bad_budget}")

# sharpness: constant-Delta policies with Delta = delta -> 0 up to s1 = 0.9 sbar approach y ln(s1/s0)
a_, lam_, sbar_, s0, y_ = 0.5, 1.0, 0.5, 0.01, 1.0
s1 = 0.9 * sbar_
ratios = []
for delta in [0.3, 0.1, 0.03, 0.01, 0.003, 0.001]:
    T1 = math.log(s1 / s0) / delta
    t = np.linspace(0, T1, 400001)
    st = s0 * np.exp(delta * t)
    sg_t = (delta / (lam_ * (1 - st / sbar_))) ** (1 / a_)
    integrand = np.maximum(y_ * delta - sg_t, 0)
    ratios.append(np.trapezoid(integrand, t) / (y_ * math.log(s1 / s0)))
print("     sharpness ratios (integral / (X-k) ln(s1/s0)), delta = 0.3, 0.1, 0.03, 0.01, 0.003, 0.001:",
      ", ".join(f"{r:.4f}" for r in ratios))
check("5c  prop:budget-sharp: bound approached by slow constant-growth policies (ratio -> 1)",
      all(np.diff(ratios) > 0) and ratios[-1] > 0.995 and ratios[-1] <= 1.0)

# Proposition prop:budget(b): discrete time
bad = 0
for _ in range(2000):
    m0_, G_, k_ = RNG.uniform(-0.2, 0.9), RNG.uniform(0, 0.4), RNG.uniform(0, 1.5)
    X_ = k_ + RNG.uniform(0.05, 3)
    y_ = X_ - k_
    sbar_ = RNG.uniform(0.1, 0.9)
    s = s0 = sbar_ * RNG.uniform(1e-4, 0.9)
    Rinf = m0_ + y_ * G_
    lhs = 0.0
    for _t in range(int(RNG.integers(1, 30))):
        g_t = G_ + RNG.exponential(RNG.uniform(0.01, 3))
        g_t = min(g_t, (1 + G_) * sbar_ / s - 1)  # keep s_{t+1} <= sbar
        g_t = max(g_t, G_)
        m_t = m0_ - k_ * g_t - RNG.exponential(0.3) * (RNG.uniform() < 0.7)
        R_t = X_ * g_t + m_t
        lhs += math.log1p(max(R_t - Rinf, 0) / (y_ * (1 + G_)))
        s = s * (1 + g_t) / (1 + G_)
    bad += not (lhs <= math.log(s / s0) + 1e-12 and math.log(s / s0) <= math.log(sbar_ / s0) + 1e-12)
check("5d  discrete-time budget (eq. budget-discrete) on 2000 random paths", bad == 0, f"violations={bad}")
def transient_bound(s0_, sbar_, Rbar, Rinf, y_, G_):
    """Corollary cor:transient, eq. (transient)."""
    return math.log(sbar_ / s0_) / math.log(1 + (Rbar - Rinf) / (y_ * (1 + G_)))


n1000 = transient_bound(0.01, 0.5, 10.0, 0.8, 1.0, 0.2)
n140 = transient_bound(0.01, 0.5, 1.4, 0.8, 1.0, 0.2)
n1000_small = transient_bound(1e-5, 0.5, 10.0, 0.8, 1.0, 0.2)
n140_small = transient_bound(1e-5, 0.5, 1.4, 0.8, 1.0, 0.2)
print(f"     Corollary cor:transient: s0=1%: N(1000) <= {n1000:.3f}, N(140) <= {n140:.3f}; "
      f"s0=1e-5: N(1000) <= {n1000_small:.3f}, N(140) <= {n140_small:.3f}")
check("5e  Corollary cor:transient: s0=1%: N(1000) <= 1.81 -> 1, N(140) <= 9.65 -> 9; s0=1e-5: N(1000) <= 5.01 -> 5",
      math.floor(n1000) == 1 and math.floor(n140) == 9 and abs(n1000 - 1.81) < 0.01 and abs(n140 - 9.65) < 0.01
      and math.floor(n1000_small) == 5 and abs(n1000_small - 5.01) < 0.01,
      f"bounds {n1000:.3f}, {n140:.3f}, {n1000_small:.3f}")

print("     Illustrations (X - k = 1):")
for s0_, sb_, exc in [(0.01, 0.5, 0.6), (0.01, 0.5, 9.2), (0.05, 0.5, 0.6), (0.001, 0.5, 9.2)]:
    print(f"       s0={s0_}, sbar={sb_}: budget ln(sbar/s0)={math.log(sb_ / s0_):.3f} score-years; "
          f"max years at {100 * exc:.0f} points above floor = {math.log(sb_ / s0_) / exc:.2f}; "
          f"discrete-time max periods (G=0.2) = {math.log(sb_ / s0_) / math.log(1 + exc / 1.2):.2f}")

# ==============================================================================================
header("6. Envelope results (Proposition prop:envelope) and capital-for-labor substitution (Corollary cor:capital)")
# ==============================================================================================
Rfull = m0 + y * G + Calpha * (lam * h * y) ** (1 / (1 - al))  # y = X - k, so d/dk = -d/dy, d/dX = d/dy
PiF = Calpha * (lam * h * y) ** (1 / (1 - al))
check("6a  dR*/dm0 = 1", sp.diff(Rfull, m0) == 1)
check("6b  dR*/dG = X - k", sp.diff(Rfull, G) == y)
check("6c  dR*/dy = G + Delta* = g*  (hence dR*/dk = -g*, dR*/dX = g*)", log_equal(sp.diff(PiF, y), Dstar))
check("6d  dR*/dlambda = (X-k) Delta*/lambda > 0", log_equal(sp.diff(PiF, lam), y * Dstar / lam))
check("6e  dR*/dh = (X-k) Delta*/h, so dR*/ds = -(X-k) Delta*/(sbar - s)", log_equal(sp.diff(PiF, h), y * Dstar / h))
check("6f  dR*/dlambda = (X-k) h sigma*^alpha (spec form)", log_equal(y * Dstar / lam, y * h * sigstar_cf**al))
check("6g  d2R*/dk2 = dDelta*/dy > 0 (convex in k)", sp.simplify(sp.diff(Dstar, y).subs(al, 1 / (1 + nu))).is_positive is True)
check("6h  d2R*/dk dlambda = -dDelta*/dlambda = -Delta*/((1-alpha) lambda) < 0",
      is_zero(sp.simplify(sp.diff(Dstar, lam) / Dstar - 1 / ((1 - al) * lam))))

# numeric finite-difference check of all envelope derivatives against an independent optimizer


def R_numeric(m0_, G_, k_, X_, lam_, h_, a_):
    y_ = X_ - k_
    if y_ <= 0:
        return m0_ + y_ * G_
    kap = (lam_ * h_) ** (-1 / a_)
    b_ = 1 / a_
    D0 = (y_ / kap) ** (1 / (b_ - 1))
    res = minimize_scalar(lambda D_: -(y_ * D_ - kap * D_**b_), bounds=(0, D0), method="bounded",
                          options={"xatol": 1e-14 * max(D0, 1)})
    return m0_ + y_ * G_ - res.fun


bad = 0
for _ in range(300):
    a_ = RNG.uniform(0.2, 0.8)
    lam_ = RNG.uniform(0.2, 1.5)
    h_ = RNG.uniform(0.1, 1.0)
    G_ = RNG.uniform(0.0, 0.4)
    k_ = RNG.uniform(0.0, 1.0)
    X_ = k_ + RNG.uniform(0.2, 2.5)
    m0_ = RNG.uniform(0.0, 0.8)
    Dcf, scf, Rcf = closed_form(m0_, G_, k_, X_, lam_ * h_, a_)
    eps = 1e-5
    fd = lambda f: (f(eps) - f(-eps)) / (2 * eps)
    dk = fd(lambda e: R_numeric(m0_, G_, k_ + e, X_, lam_, h_, a_))
    dG = fd(lambda e: R_numeric(m0_, G_ + e, k_, X_, lam_, h_, a_))
    dl = fd(lambda e: R_numeric(m0_, G_, k_, X_, lam_ + e, h_, a_))
    dm = fd(lambda e: R_numeric(m0_ + e, G_, k_, X_, lam_, h_, a_))
    ok = abs(dk + (G_ + Dcf)) < 1e-4 * (1 + G_ + Dcf)
    ok &= abs(dG - (X_ - k_)) < 1e-4
    ok &= abs(dl - (X_ - k_) * Dcf / lam_) < 1e-4 * (1 + (X_ - k_) * Dcf / lam_)
    ok &= abs(dm - 1) < 1e-6
    bad += (not ok)
check("6i  finite differences of numerically optimized R* match the envelope formulas (300 draws)", bad == 0,
      f"violations={bad}")

bad = 0
for _ in range(1000):
    a_ = RNG.uniform(0.15, 0.85)
    ell = RNG.uniform(0.05, 2.0)
    G_ = RNG.uniform(0.0, 0.4)
    k_ = RNG.uniform(0.0, 2.0)
    X_ = RNG.uniform(0.0, 3.0)
    m0_ = RNG.uniform(-0.2, 0.9)
    dk_ = RNG.uniform(0.001, 1.0)
    da_ = RNG.uniform(0.0, 1.0)
    gstar = lambda kk: G_ + closed_form(m0_, G_, kk, X_, ell, a_)[0]
    dR = da_ + closed_form(m0_, G_, k_ + dk_, X_, ell, a_)[2] - closed_form(m0_, G_, k_, X_, ell, a_)[2]
    ok = True
    if da_ > gstar(k_) * dk_:
        ok &= dR > -1e-12
    if dR > 1e-12:
        ok &= da_ > gstar(k_ + dk_) * dk_ - 1e-12
    lo, hi = gstar(k_ + dk_) * dk_, gstar(k_) * dk_
    ok &= lo - 1e-12 <= da_ - dR <= hi + 1e-12
    bad += (not ok)
check("6j  capital-for-labor: g*(k+dk)dk <= da - dR* <= g*(k)dk (exact bracket, 1000 draws)", bad == 0,
      f"violations={bad}")

# ==============================================================================================
header("7. Valuation foundation of the Rule of X (Lemmas lem:valuation, lem:valuation2)")
# ==============================================================================================
gv, r, mv, S0, q = sp.symbols("g r m S_0 q", positive=True)
A = sp.Function("A")
qg = (1 + gv) / (1 + r)
V_general = mv * S0 * A(qg)
Xg = sp.diff(V_general, gv) / sp.diff(V_general, mv)
Dgen = (q * sp.diff(A(q), q) / A(q)).subs(q, qg)  # D = q A'(q)/A(q) = sum t q^t / sum q^t
check("7a  general T (A(q) = sum_{t<=T} q^t): X = V_g/V_m = m D/(1+g) with D = q A'(q)/A(q)",
      is_zero(sp.simplify(Xg - mv * Dgen / (1 + gv)).doit()))

ok_all = True
for T in range(1, 26):
    t = sp.symbols("t", integer=True, positive=True)
    V = mv * S0 * sum(qg**tt for tt in range(1, T + 1))
    Xs = sp.diff(V, gv) / sp.diff(V, mv)
    D = sum(tt * qg**tt for tt in range(1, T + 1)) / sum(qg**tt for tt in range(1, T + 1))
    if sp.cancel(sp.together(Xs - mv * D / (1 + gv))) != 0:
        ok_all = False
check("7b  explicit finite sums, T = 1..25: X = m D/(1+g) (exact rational identity)", ok_all)

check("7c  numeric example: m = 0.25, D = 10, g = 0.25 gives X = 2", abs(0.25 * 10 / 1.25 - 2.0) < 1e-15)


def duration(gg_, rr_, T):
    qq = (1 + gg_) / (1 + rr_)
    w = qq ** np.arange(1, T + 1)
    return float(np.sum(np.arange(1, T + 1) * w) / np.sum(w))


for rr_ in [0.08, 0.10, 0.12]:
    Ds = [duration(0.25, rr_, T) for T in range(1, 41)]
    T10 = next(T for T in range(1, 41) if Ds[T - 1] >= 10)
    print(f"     r={rr_:.2f}, g=0.25: D(T=5)={Ds[4]:.2f}, D(T=10)={Ds[9]:.2f}, D(T=15)={Ds[14]:.2f}, "
          f"D(T=20)={Ds[19]:.2f}; smallest T with D>=10: T={T10} (D={Ds[T10 - 1]:.2f})")
check("7d  D increasing in g and in T (numeric, r = 0.10)",
      all(np.diff([duration(gg_, 0.10, 12) for gg_ in np.linspace(-0.05, 0.6, 50)]) > 0)
      and all(np.diff([duration(0.25, 0.10, T) for T in range(1, 40)]) > 0))

# two-stage valuation with terminal value and margin persistence theta
th, mb, Gam = sp.symbols("theta mbar Gamma", positive=True)
ok_all = True
for T in [1, 3, 5, 10]:
    AT = sum(qg**tt for tt in range(1, T + 1))
    mLR = th * mv + (1 - th) * mb
    V2 = S0 * (mv * AT + mLR * qg**T * Gam)
    Xs = sp.diff(V2, gv) / sp.diff(V2, mv)
    claim = (mv * sum(tt * qg**tt for tt in range(1, T + 1)) + mLR * T * qg**T * Gam) / ((1 + gv) * (AT + th * qg**T * Gam))
    if sp.cancel(sp.together(Xs - claim)) != 0:
        ok_all = False
check("7e  two-stage lemma: X = [m sum t q^t + m_LR T q^T Gamma] / [(1+g)(A_T + theta q^T Gamma)], T in {1,3,5,10}",
      ok_all)


def X_two_stage(m_, mbar_, theta_, g_, r_, Ginf, T):
    qq = (1 + g_) / (1 + r_)
    t = np.arange(1, T + 1)
    AT = np.sum(qq**t)
    St = np.sum(t * qq**t)
    Gm = (1 + Ginf) / (r_ - Ginf)
    mLR = theta_ * m_ + (1 - theta_) * mbar_
    return (m_ * St + mLR * T * qq**T * Gm) / ((1 + g_) * (AT + theta_ * qq**T * Gm))


def V_two_stage(m_, g_, mbar_, theta_, r_, Ginf, T):
    qq = (1 + g_) / (1 + r_)
    t = np.arange(1, T + 1)
    Gm = (1 + Ginf) / (r_ - Ginf)
    return m_ * np.sum(qq**t) + (theta_ * m_ + (1 - theta_) * mbar_) * qq**T * Gm


bad = 0
for _ in range(300):
    m_, mbar_, theta_ = RNG.uniform(-0.2, 0.4), RNG.uniform(0.05, 0.4), RNG.uniform(0, 1)
    g_, r_, Ginf, T = RNG.uniform(0, 0.6), RNG.uniform(0.06, 0.14), RNG.uniform(0.0, 0.05), int(RNG.integers(1, 15))
    e = 1e-6
    Vg = (V_two_stage(m_, g_ + e, mbar_, theta_, r_, Ginf, T) - V_two_stage(m_, g_ - e, mbar_, theta_, r_, Ginf, T)) / (2 * e)
    Vm = (V_two_stage(m_ + e, g_, mbar_, theta_, r_, Ginf, T) - V_two_stage(m_ - e, g_, mbar_, theta_, r_, Ginf, T)) / (2 * e)
    bad += abs(Vg / Vm - X_two_stage(m_, mbar_, theta_, g_, r_, Ginf, T)) > 1e-5 * (1 + abs(Vg / Vm))
check("7f  two-stage formula matches finite-difference MRS (300 draws)", bad == 0, f"violations={bad}")

bad = 0
for _ in range(300):
    mbar_ = RNG.uniform(0.05, 0.4)
    m_ = RNG.uniform(0, mbar_)
    g_, r_, Ginf, T = RNG.uniform(0, 0.6), RNG.uniform(0.06, 0.14), RNG.uniform(0.0, 0.05), int(RNG.integers(1, 15))
    xs = [X_two_stage(m_, mbar_, th_, g_, r_, Ginf, T) for th_ in np.linspace(0, 1, 21)]
    bad += not np.all(np.diff(xs) < 0)
check("7g  0 <= m <= mbar: X strictly decreasing in margin persistence theta (300 draws)", bad == 0,
      f"violations={bad}")

print("     Implied X (r=0.10, g=0.25, G_inf=0.03, mbar=0.25):")
print("       T   m     theta=0   theta=0.5   theta=1")
for T in [5, 10]:
    for m_ in [0.0, 0.10, 0.25]:
        row = [X_two_stage(m_, 0.25, th_, 0.25, 0.10, 0.03, T) for th_ in [0.0, 0.5, 1.0]]
        print(f"      {T:2d}  {m_:.2f}   {row[0]:7.2f}   {row[1]:9.2f}   {row[2]:7.2f}")

# ==============================================================================================
header("8. Free entry and replication (Proposition prop:entry)")
# ==============================================================================================
tt, rho_, u, b, P, x, F = sp.symbols("t rho u b P x F", positive=True)
rr = G + rho_  # r > G
npv = sp.integrate(sp.exp(-rho_ * tt) * ((P - u) - G * b) * x, (tt, 0, sp.oo)) - b * x - F
check("8a  entrant NPV = x (P - u - r b)/(r - G) - F  (continuous-time capacity growing at G)",
      is_zero(npv - (x * (P - u - rr * b) / rho_ - F)))

Ad, Bd, ch, n, xi, Qo = sp.symbols("A B chat n x_i Q_o", positive=True)
prof_i = (Ad - Bd * (xi + Qo) - ch) * xi
br = sp.solve(sp.diff(prof_i, xi), xi)[0]
xsym = sp.solve(sp.Eq(xi, br.subs(Qo, (n - 1) * xi)), xi)[0]
check("8b  symmetric Cournot: x_n = (A - chat)/(B(n+1))", is_zero(xsym - (Ad - ch) / (Bd * (n + 1))))
Pn = Ad - Bd * n * xsym
check("8c  P_n = (A + n chat)/(n+1)", is_zero(Pn - (Ad + n * ch) / (n + 1)))
check("8d  flow profit pi_n = (A-chat)^2/(B(n+1)^2)", is_zero((Pn - ch) * xsym - (Ad - ch) ** 2 / (Bd * (n + 1) ** 2)))
check("8e  Lerner L_n = (P_n - chat)/P_n = (A - chat)/(A + n chat)", is_zero((Pn - ch) / Pn - (Ad - ch) / (Ad + n * ch)))
rs = sp.symbols("r", positive=True)
check("8f  m_op = (P - u)/P = r k + L with k = b/P, chat = u + r b",
      is_zero((P - u) / P - (rs * b / P + (P - (u + rs * b)) / P)))
check("8g  L_n -> 0 as n -> oo", sp.limit((Ad - ch) / (Ad + n * ch), n, sp.oo) == 0)

bad_n, bad_L = 0, 0
for _ in range(2000):
    A_ = RNG.uniform(1.0, 10.0)
    B_ = RNG.uniform(0.1, 5.0)
    ch_ = RNG.uniform(0.05, 0.95) * A_
    Fh = RNG.uniform(1e-6, 0.25) * (A_ - ch_) ** 2 / (4 * B_)  # ensures Phi >= 2
    Phi = (A_ - ch_) / math.sqrt(B_ * Fh)
    pis = [(A_ - ch_) ** 2 / (B_ * (nn + 1) ** 2) for nn in range(1, 100000)]
    nstar_bf = max(nn for nn, p in zip(range(1, 100000), pis) if p >= Fh)
    if nstar_bf != math.floor(Phi) - 1:
        bad_n += 1
    L = (A_ - ch_) / (A_ + nstar_bf * ch_)
    if not (0 < L < (A_ - ch_) / (ch_ * (Phi - 1))):
        bad_L += 1
check("8h  n* = floor(Phi) - 1 by brute force (2000 draws)", bad_n == 0, f"violations={bad_n}")
check("8i  0 < L_{n*} < (A - chat)/(chat (Phi - 1))", bad_L == 0, f"violations={bad_L}")

A_, B_, u_, b_, r_, G_, X_ = 2.0, 1.0, 0.6, 0.8, 0.10, 0.05, 1.0
ch_ = u_ + r_ * b_
lim = X_ * G_ + (r_ - G_) * b_ / ch_
seq = []
for Fh in [1e-2, 1e-4, 1e-6, 1e-8]:
    Phi = (A_ - ch_) / math.sqrt(B_ * Fh)
    ns = math.floor(Phi) - 1
    Pn_ = (A_ + ns * ch_) / (ns + 1)
    kn = b_ / Pn_
    Ln = (A_ - ch_) / (A_ + ns * ch_)
    seq.append(X_ * G_ + (r_ - G_) * kn + Ln)
print(f"     R_X along F -> 0: {', '.join(f'{v:.6f}' for v in seq)};  limit XG + (r-G) b/chat = {lim:.6f}")
check("8j  R_X -> XG + (r-G) b/chat as F -> 0", abs(seq[-1] - lim) < 1e-3 and all(np.diff(np.abs(np.array(seq) - lim)) < 0))
kh = b_ / ch_
check("8k  X = 1: limit equals G(1-k) + r k", abs((G_ + (r_ - G_) * kh) - (G_ * (1 - kh) + r_ * kh)) < 1e-15)

Z = sp.symbols("Z", positive=True)
w = sp.symbols("w", positive=True)
Qn_w = n * (Ad - ch - w) / (Bd * (n + 1))
wn = sp.solve(sp.Eq(Qn_w, Z), w)[0]
check("8l  scarce input: w_n = A - chat - B Z (n+1)/n", is_zero(wn - (Ad - ch - Bd * Z * (n + 1) / n)))
PZ = Ad - Bd * Z
check("8m  binding input: price = A - B Z independent of n", is_zero(Ad - Bd * Qn_w.subs(w, wn) - PZ))
check("8n  rent share w_n/P_Z -> rho = 1 - chat/P_Z as n -> oo", is_zero(sp.limit(wn / PZ, n, sp.oo) - (1 - ch / PZ)))
check("8o  Lerner net of input cost: (P_Z - chat - w_n)/P_Z = B Z/(n P_Z) -> 0",
      is_zero((PZ - ch - wn) / PZ - Bd * Z / (n * PZ)) and sp.limit(Bd * Z / (n * PZ), n, sp.oo) == 0)
check("8p  per-firm flow profit with binding input = B Z^2/n^2", is_zero((PZ - ch - wn) * Z / n - Bd * Z**2 / n**2))

# ==============================================================================================
header("9. Price channels of AI (Lemma lem:prices)")
# ==============================================================================================
uu, pp, phi = sp.symbols("u p phi", positive=True)
pfun = sp.Function("p")
gam_u = 1 - uu / pfun(uu)
dgam = sp.diff(gam_u, uu).subs(sp.Derivative(pfun(uu), uu), phi).subs(pfun(uu), pp)
check("9a  d gamma/du = -(1/p)[1 - phi (1 - gamma)] with pass-through phi = dp/du",
      is_zero(dgam - (-(1 / pp) * (1 - phi * (uu / pp)))))
GQ, eps_, dp, t_ = sp.symbols("G_Q epsilon delta_p t", positive=True)
p0, Q0 = sp.symbols("p_0 Q_0", positive=True)
Mt = (p0 * sp.exp(-dp * t_)) * Q0 * sp.exp(GQ * t_) * (p0 * sp.exp(-dp * t_)) ** (-eps_)
check("9b  nominal market growth under deflation: G = G_Q - (1 - epsilon) delta_p",
      is_zero(sp.diff(sp.expand_log(sp.log(Mt), force=True), t_) - (GQ - (1 - eps_) * dp)))

# ==============================================================================================
header("10. AI shift of the frontier and the maximal score (Proposition prop:ai)")
# ==============================================================================================
bad = 0
for _ in range(300):
    a_ = RNG.uniform(0.2, 0.8)
    lam_ = RNG.uniform(0.2, 1.5)
    h_ = RNG.uniform(0.1, 1.0)
    G_ = RNG.uniform(0.0, 0.3)
    k_ = RNG.uniform(0.0, 1.0)
    X_ = k_ + RNG.uniform(0.2, 2.5)
    gam_, a0 = RNG.uniform(0.5, 0.9), RNG.uniform(0.05, 0.3)
    d = RNG.normal(size=5)  # (dgamma, da, dk, dlambda, dG)
    Dcf = closed_form(gam_ - a0, G_, k_, X_, lam_ * h_, a_)[0]
    formula = d[0] - d[1] + (X_ - k_) * d[4] - (G_ + Dcf) * d[2] + (X_ - k_) * Dcf * d[3] / lam_
    e = 1e-6
    Rp = R_numeric(gam_ + e * d[0] - (a0 + e * d[1]), G_ + e * d[4], k_ + e * d[2], X_, lam_ + e * d[3], h_, a_)
    Rm = R_numeric(gam_ - e * d[0] - (a0 - e * d[1]), G_ - e * d[4], k_ - e * d[2], X_, lam_ - e * d[3], h_, a_)
    bad += abs((Rp - Rm) / (2 * e) - formula) > 1e-4 * (1 + abs(formula))
check("10a dR*/dzeta = (dgamma - da) + (X-k) dG - g* dk + (X-k) Delta* dlambda/lambda (300 random directions)",
      bad == 0, f"violations={bad}")

bad = 0
for _ in range(2000):
    a_ = RNG.uniform(0.15, 0.85)
    m00, k0, G0, l0 = RNG.uniform(0, 0.8), RNG.uniform(0, 1.5), RNG.uniform(0, 0.3), RNG.uniform(0.1, 2)
    k1 = k0 * RNG.uniform(0, 1)
    G1 = G0 + RNG.uniform(0, 0.2)
    l1 = l0 * RNG.uniform(1, 2)
    m01 = m00 + (k1 * G1 - k0 * G0) + RNG.uniform(0, 0.2)  # m0 may fall; only m0 - kG must weakly rise
    kap0, kap1 = l0 ** (-1 / a_), l1 ** (-1 / a_)
    gg = G0 + np.linspace(0, 2, 2001)
    m_old = m00 - k0 * gg - kap0 * (gg - G0) ** (1 / a_)
    new_at = lambda g_: m01 - k1 * g_ - kap1 * (g_ - G1) ** (1 / a_)
    ok = True
    for g_, mo in zip(gg, m_old):
        mn = new_at(g_) if g_ >= G1 else new_at(G1)
        ok &= mn >= mo - 1e-12
    for X_ in RNG.uniform(0, 3, 5):
        ok &= closed_form(m01, G1, k1, X_, l1, a_)[2] >= closed_form(m00, G0, k0, X_, l0, a_)[2] - 1e-12
    bad += (not ok)
check("10b up/out: lambda, G up, k down, m0 - kG up => old frontier weakly dominated; R_X* up for all X",
      bad == 0, f"violations={bad}")

bad = 0
for _ in range(1000):
    a_ = RNG.uniform(0.15, 0.85)
    m00, k0, G0, l0 = RNG.uniform(0, 0.8), RNG.uniform(0, 1.5), RNG.uniform(0, 0.3), RNG.uniform(0.1, 2)
    dm, dk = RNG.uniform(0.001, 0.3), RNG.uniform(0.001, 0.5)
    gg = G0 + np.linspace(0, 2, 2001)
    diff = (m00 + dm - (k0 + dk) * gg) - (m00 - k0 * gg)
    cut = dm / dk
    bad += not (np.all(diff[gg < cut - 1e-9] > 0) and np.all(diff[gg > cut + 1e-9] < 0))
check("10c rotation: new frontier above old iff g < dm0/dk (1000 draws)", bad == 0, f"violations={bad}")

# ==============================================================================================
header("11. Taxes (Remark rem:taxes) and full-automation ceiling (Corollary cor:ceiling)")
# ==============================================================================================
tau, psi, omt = sp.symbols("tau psi omega_tau", positive=True)  # omega_tau = 1 - tau > 0
m_tax = omt * (m0 - kappa * Dl**beta) - (1 - psi * tau) * k * (G + Dl)
lam_tau = omt ** (-al) * lam
m_relabel = omt * m0 - (1 - psi * tau) * k * (G + Dl) - (lam_tau * h) ** (-beta) * Dl**beta
check("11a taxed frontier = untaxed form with m0->(1-tau)m0, k->(1-psi tau)k, lambda->(1-tau)^(-alpha) lambda",
      log_equal((lam_tau * h) ** (-beta), omt * kappa) and is_zero(sp.expand(m_tax - m_relabel).subs(
          (lam_tau * h) ** (-beta), omt * kappa)))

bad = 0
for _ in range(300):
    a_ = RNG.uniform(0.2, 0.8)
    lam_, h_ = RNG.uniform(0.2, 1.5), RNG.uniform(0.1, 1)
    G_, k_ = RNG.uniform(0, 0.3), RNG.uniform(0, 1.0)
    X_ = k_ + RNG.uniform(0.2, 2.5)
    m0_, tau_, psi_ = RNG.uniform(0, 0.8), RNG.uniform(0, 0.4), RNG.uniform(0, 1)
    ell_t = (1 - tau_) ** (-a_) * lam_ * h_
    Rcf = closed_form((1 - tau_) * m0_, G_, (1 - psi_ * tau_) * k_, X_, ell_t, a_)[2]
    obj = lambda sg: -(X_ * (G_ + lam_ * h_ * sg**a_) + (1 - tau_) * (m0_ - sg)
                       - (1 - psi_ * tau_) * k_ * (G_ + lam_ * h_ * sg**a_))
    res = minimize_scalar(obj, bounds=(0, 1e4), method="bounded", options={"xatol": 1e-12})
    grid = np.concatenate([np.linspace(0, 50, 200001)])
    best = max(-obj(grid).max(), -res.fun)
    bad += abs(best - Rcf) > 1e-6 * (1 + abs(Rcf))
check("11b taxed maximal score equals relabeled closed form (300 draws)", bad == 0, f"violations={bad}")


def ceiling(cc, f, amin, tau_, G_, k_, X_=1.0, psi_=0.0):
    return (1 - tau_) * (1 - cc - f - amin) + (X_ - (1 - psi_ * tau_) * k_) * G_


# a_min recalibrated (Referee 2): 0.015 favorable, 0.03 central, 0.06 conservative
cases = {"favorable": (0.15, 0.02, 0.015, 0.15), "central": (0.20, 0.025, 0.03, 0.18),
         "conservative": (0.25, 0.03, 0.06, 0.21), "high compute": (0.40, 0.025, 0.03, 0.18)}
cols = [(0.05, 0.0), (0.15, 0.0), (0.30, 0.0), (0.15, 0.5), (0.05, 1.5), (0.30, 1.5)]
print("     Full-automation ceiling R_max = (1-tau)(1-c_c-f-a_min) + (1-k)G   [psi = 0]; in percent")
print("     case          base  " + "  ".join(f"G={G_:.2f},k={k_:.1f}" for G_, k_ in cols))
for name, (cc, f, amin, tau_) in cases.items():
    base = (1 - tau_) * (1 - cc - f - amin)
    vals = [100 * ceiling(cc, f, amin, tau_, G_, k_) for G_, k_ in cols]
    print(f"     {name:12s} {100 * base:5.1f}  " + "  ".join(f"{v:12.1f}" for v in vals))
print("     LaTeX rows:")
for name, (cc, f, amin, tau_) in cases.items():
    base = (1 - tau_) * (1 - cc - f - amin)
    vals = [100 * ceiling(cc, f, amin, tau_, G_, k_) for G_, k_ in cols]
    print(f"     {name.capitalize()} & {cc:.2f} & {f:.3g} & {amin:.3g} & {tau_:.2f} & {100 * base:.1f} & "
          + " & ".join(f"{v:.1f}" for v in vals) + r" \\")
grid_vals = [ceiling(cc, f, amin, tau_, G_, k_)
             for cc in [0.15, 0.25] for f in [0.02, 0.03] for amin in [0.015, 0.06]
             for tau_ in [0.15, 0.21] for G_ in [0.05, 0.30] for k_ in [0.0, 1.5]]
print(f"     range over the corner grid: min={100 * min(grid_vals):.1f}, max={100 * max(grid_vals):.1f}")
print(f"     full-expensing adjustment tau k G at (tau,k,G)=(0.21,1.5,0.30): {100 * 0.21 * 1.5 * 0.30:.2f} points")
thr = {}
for name, (cc, f, amin, tau_) in cases.items():
    base = (1 - tau_) * (1 - cc - f - amin)
    thr[name] = 1 - base
    red0 = ceiling(cc, f, amin, tau_, 0.30, 0.0) - ceiling(cc, f, amin, tau_, 0.30, 1.5)
    red1 = ceiling(cc, f, amin, tau_, 0.30, 0.0, psi_=1) - ceiling(cc, f, amin, tau_, 0.30, 1.5, psi_=1)
    print(f"     {name:12s}: margin term={base:.5f}; R_max(k=0) at G=5/15/30%: "
          f"{100 * ceiling(cc, f, amin, tau_, 0.05, 0):.1f}/{100 * ceiling(cc, f, amin, tau_, 0.15, 0):.1f}/"
          f"{100 * ceiling(cc, f, amin, tau_, 0.30, 0):.1f}; k=1.5 reduction at G=30%: {100 * red0:.2f} "
          f"(expensing {100 * red1:.2f}); G for R_max=100 (k=0): {100 * thr[name]:.2f}%")
table_expected = {
    "favorable": [69.3, 74.3, 84.3, 99.3, 76.8, 66.8, 54.3],
    "central": [61.1, 66.1, 76.1, 91.1, 68.6, 58.6, 46.1],
    "conservative": [52.1, 57.1, 67.1, 82.1, 59.6, 49.6, 37.1],
    "high compute": [44.7, 49.7, 59.7, 74.7, 52.2, 42.2, 29.7],
}
ok = True
for name, (cc, f, amin, tau_) in cases.items():
    base = (1 - tau_) * (1 - cc - f - amin)
    vals = [round(100 * base, 1)] + [round(100 * ceiling(cc, f, amin, tau_, G_, k_), 1) for G_, k_ in cols]
    ok &= all(abs(v - e) < 1e-9 for v, e in zip(vals, table_expected[name]))
check("11c accountability-only ceiling (c_mnt = c_sec = c_err = c_anc = 0, a_min 6% conservative), the previous Table tab:ceiling quoted for comparison: rows equal computed values", ok)
check("11d ceiling identity: R_max(psi=1) - R_max(psi=0) = tau k G",
      abs(ceiling(0.2, 0.025, 0.03, 0.18, 0.2, 1.0, psi_=1) - ceiling(0.2, 0.025, 0.03, 0.18, 0.2, 1.0) - 0.18 * 1.0 * 0.2) < 1e-15)
check("11e accountability-only thresholds for R_max = 100 at k = 0: 30.7%, 38.9%, 47.9% (a_min 6%); grid range 37.1 to 99.3",
      abs(100 * thr["favorable"] - 30.725) < 1e-9 and abs(100 * thr["central"] - 38.91) < 1e-9
      and abs(100 * thr["conservative"] - 47.86) < 1e-9
      and abs(100 * min(grid_vals) - 37.14) < 1e-9 and abs(100 * max(grid_vals) - 99.275) < 1e-9)
check("11h accountability-only high-compute case (c_c = 0.40): margin term 44.69 points; R_max reaches 100 at k = 0 only if G > 55.31%",
      abs(100 * thr["high compute"] - 55.31) < 1e-9)
check("11f k = 1.5 at G = 30%: reduction 45 points; with expensing (1-tau) 45 = 38.25, 36.9, 35.55",
      all(abs(100 * ((1 - tau_) * 1.5 * 0.30) - e) < 1e-9 for tau_, e in [(0.15, 38.25), (0.18, 36.9), (0.21, 35.55)]))
check("11g pull adjustment (1-tau)^(-0.3): 1.050 at tau=0.15, 1.073 at tau=0.21 (5% to 7%)",
      abs(0.85 ** -0.3 - 1.04996) < 1e-4 and abs(0.79 ** -0.3 - 1.07328) < 1e-4)

# ==============================================================================================
header("12. Parameter values used in the figures")
# ==============================================================================================
m0_, G_, k_, a_, ell = 0.45, 0.10, 0.10, 0.3, 0.6
for X_ in [1.0, 2.0]:
    D_, sg, Rv = closed_form(m0_, G_, k_, X_, ell, a_)
    print(f"     Fig. 1, X={X_:.0f}: g*={G_ + D_:.4f}, sigma*={sg:.4f}, m*={m0_ - k_ * (G_ + D_) - sg:.4f}, R*={Rv:.4f}")
m0_, G_, lam_, a_ = 0.50, 0.20, 1.2, 0.3
for k_ in [0.0, 0.3, 0.6]:
    print(f"     Fig. 2, k={k_}: R*(s->0)={closed_form(m0_, G_, k_, 1.0, lam_, a_)[2]:.4f}, "
          f"limit m0+(1-k)G={m0_ + (1 - k_) * G_:.4f}")

# ==============================================================================================
header("13. Heterogeneous firms (Propositions prop:industry, prop:industry-full; Remark rem:segments)")
# ==============================================================================================


def firm_choice(m0_, k_, ell, X_, a_, G_, sbar_cap=np.inf):
    """Rule-of-X choice of a firm with a financing cap; returns (g, m, R)."""
    y_ = X_ - k_
    if y_ <= 0:
        return G_, m0_ - k_ * G_, m0_ + y_ * G_
    sg = min((a_ * ell * y_) ** (1 / (1 - a_)), sbar_cap)
    g_ = G_ + ell * sg**a_
    m_ = m0_ - k_ * g_ - sg
    return g_, m_, X_ * g_ + m_


# (i) possibility envelope strictly decreasing for finite sets of firms
bad = 0
for _ in range(300):
    n = int(RNG.integers(2, 12))
    a_, G_, X_ = RNG.uniform(0.2, 0.45), RNG.uniform(0, 0.3), RNG.uniform(0.5, 3)
    m0s, ells, ks = RNG.uniform(-0.2, 0.8, n), RNG.uniform(0.05, 2, n), RNG.uniform(0, 1.5, n)
    sbar_cap = RNG.uniform(0.1, 1.5)
    Dmax = ells * sbar_cap**a_
    gg = G_ + np.linspace(0, Dmax.max(), 3001)
    Phi = np.full_like(gg, -np.inf)
    for i in range(n):
        mask = gg <= G_ + Dmax[i] + 1e-15
        Phi[mask] = np.maximum(Phi[mask], m0s[i] - ks[i] * gg[mask] - ells[i] ** (-1 / a_) * (gg[mask] - G_) ** (1 / a_))
    bad += not (np.all(np.isfinite(Phi)) and np.all(np.diff(Phi) < 0))
check("13a (i) possibility envelope Phi strictly decreasing for finite heterogeneous sets (300 draws)", bad == 0,
      f"violations={bad}")

# (ii) two-type example in the text
a_, X_, k_, G_ = 0.3, 1.0, 0.0, 0.1
lo = firm_choice(0.30, k_, 0.3, X_, a_, G_)
hi = firm_choice(0.50, k_, 0.8, X_, a_, G_)
slope = (hi[1] - lo[1]) / (hi[0] - lo[0])
Dl_, Dh_ = lo[0] - G_, hi[0] - G_
fr_slope = lambda ell, D_: -k_ - (1 / a_) * ell ** (-1 / a_) * D_ ** (1 / a_ - 1)
print(f"     two-type example: low (g,m)=({lo[0]:.4f},{lo[1]:.4f}), high (g,m)=({hi[0]:.4f},{hi[1]:.4f}), "
      f"cross-sectional slope={slope:.4f}; own frontier slopes {fr_slope(0.3, Dl_):.6f}, {fr_slope(0.8, Dh_):.6f}")
check("13b two-type example: chosen points (0.21,0.27), (0.53,0.37), slope ~ +0.31, own slopes = -X",
      abs(lo[0] - 0.2069) < 1e-3 and abs(lo[1] - 0.2679) < 1e-3 and abs(hi[0] - 0.5340) < 1e-3
      and abs(hi[1] - 0.3698) < 1e-3 and abs(slope - 0.3115) < 1e-3
      and abs(fr_slope(0.3, Dl_) + X_) < 1e-10 and abs(fr_slope(0.8, Dh_) + X_) < 1e-10
      and (0.50 - 0.30) >= (k_ + a_ * (X_ - k_)) * (Dh_ - Dl_))

# (ii) continuum with quality condition: locus, Phi, Psi, quantile frontiers
bad = 0
for _ in range(100):
    a_, G_, k_ = RNG.uniform(0.2, 0.45), RNG.uniform(0, 0.3), RNG.uniform(0, 0.5)
    X_ = k_ + RNG.uniform(0.2, 2.0)
    y_ = X_ - k_
    c_req = k_ + a_ * y_
    slack = RNG.uniform(0.001, 0.5)
    om = np.linspace(0, 1, 801)
    ell = RNG.uniform(0.05, 0.5) + RNG.uniform(0.1, 1.5) * om
    D_ = ell ** (1 / (1 - a_)) * (a_ * y_) ** (a_ / (1 - a_))
    m0w = RNG.uniform(0, 0.5) + (c_req + slack) * D_  # strict quality condition
    sbar_cap = (a_ * ell[-1] * y_) ** (1 / (1 - a_)) * 1.5
    ch = np.array([firm_choice(m0w[i], k_, ell[i], X_, a_, G_, sbar_cap) for i in range(len(om))])
    gc, mc, Rc = ch[:, 0], ch[:, 1], ch[:, 2]
    ok = np.all(np.diff(gc) > 0) and np.all(np.diff(mc) > 0)
    # eq. (locus)
    ok &= np.allclose(np.diff(mc), np.diff(m0w) - c_req * np.diff(D_), atol=1e-12)
    # Psi flat = m^c of top firm
    for gq in np.linspace(G_, gc[-1], 50):
        ok &= abs(mc[gc >= gq - 1e-15].max() - mc[-1]) < 1e-14
    # quantile frontiers strictly increasing on [g_lo, g_hi) (uniform distribution of omega)
    for chi in [0.25, 0.5, 0.95]:
        gq = np.linspace(gc[0], gc[-40], 60)
        qs = [np.quantile(mc[gc >= v], chi) for v in gq]
        ok &= np.all(np.diff(qs) > 0)
    # Phi = top firm's frontier (strictly decreasing)
    Dmax = ell * sbar_cap**a_
    gg = G_ + np.linspace(0, Dmax[-1], 801)
    Phi = np.full_like(gg, -np.inf)
    for i in range(0, len(om), 20):
        mask = gg <= G_ + Dmax[i] + 1e-15
        Phi[mask] = np.maximum(Phi[mask], m0w[i] - k_ * gg[mask] - ell[i] ** (-1 / a_) * (gg[mask] - G_) ** (1 / a_))
    top = m0w[-1] - k_ * gg - ell[-1] ** (-1 / a_) * (gg - G_) ** (1 / a_)
    ok &= np.allclose(Phi, top, atol=1e-14) and np.all(np.diff(Phi) < 0)
    # (iii) scores: sup over Phi = sup over Psi = max_i R_i* = R of top firm, attained at top g
    Rphi = (X_ * gg + Phi).max()
    gpsi = np.linspace(G_, gc[-1], 4001)
    Rpsi = X_ * gpsi + np.array([mc[gc >= v - 1e-15].max() for v in gpsi])
    ok &= abs(Rphi - Rc.max()) < 1e-5 and abs(Rpsi.max() - Rc.max()) < 1e-12 and np.argmax(Rpsi) == len(gpsi) - 1
    ok &= np.argmax(Rc) == len(om) - 1
    bad += (not ok)
check("13c (ii)-(iii) continuum with quality condition: locus increasing, Phi = top frontier, Psi flat, "
      "quantile frontiers increasing, max score = best firm's R* at top g (100 draws)", bad == 0, f"violations={bad}")

# (iv) non-identification: locus slope xi, own slope -X, curvature, alpha-invariance of the segment
bad = 0
for _ in range(200):
    a_, G_, k_ = RNG.uniform(0.15, 0.85), RNG.uniform(0, 0.3), RNG.uniform(0, 0.5)
    X_ = k_ + RNG.uniform(0.2, 2.0)
    y_ = X_ - k_
    xi, mu = RNG.uniform(-1.5, 1.5), RNG.uniform(0, 0.5)
    Dlo, Dhi = RNG.uniform(0.01, 0.2), RNG.uniform(0.25, 0.8)
    ok = True
    for aa, XX in [(a_, X_), (0.2, X_), (0.45, X_), (a_, k_ + 0.5 * (X_ - k_)), (0.3, k_ + 2.0 * (X_ - k_))]:
        y_ = XX - k_
        ell_of_D = lambda D_: D_ ** (1 - aa) * (aa * y_) ** (-aa)
        Ds = np.linspace(Dlo, Dhi, 200)
        ells = ell_of_D(Ds)
        m0s = mu + (xi + k_ + aa * y_) * Ds
        ch = np.array([firm_choice(m0s[i], k_, ells[i], XX, aa, G_) for i in range(len(Ds))])
        ok &= np.allclose(ch[:, 0], G_ + Ds, atol=1e-12)
        ok &= np.allclose(ch[:, 1], mu - k_ * G_ + xi * Ds, atol=1e-12)
        kap_ = ells ** (-1 / aa)
        slope_own = -k_ - (1 / aa) * kap_ * Ds ** (1 / aa - 1)
        curv_own = -(1 / aa) * (1 / aa - 1) * kap_ * Ds ** (1 / aa - 2)
        ok &= np.allclose(slope_own, -XX, atol=1e-10)
        ok &= np.allclose(curv_own, -(1 - aa) * y_ / (aa * Ds), rtol=1e-10)
        # Psi slope = min(xi, 0) on (g_lo, g_hi)
        gq = G_ + np.linspace(Dlo + 0.01, Dhi - 0.01, 50)
        psi = np.array([ch[ch[:, 0] >= v, 1].max() for v in gq])
        sl = np.polyfit(gq, psi, 1)[0]
        ok &= abs(sl - min(xi, 0)) < 2e-2
        ok &= aa * y_ * Dhi <= y_ * Dhi  # cap condition sigma* <= (X-k)(g_hi - G)
    bad += (not ok)
check("13d (iv) non-identification: locus slope xi, Psi slope min(xi,0), own slope -X, curvature "
      "-(1-alpha)(X-k)/(alpha Delta*), same segment for several (alpha, X) (200 draws)", bad == 0, f"violations={bad}")

# (v) within-firm co-movement: exact small-noise slope vs formula
ap, ellb, m0b, y_s, k_s, G_s, af_s = sp.symbols("alpha ellbar m0bar y k G a_f", positive=True)  # y = X - k > 0
eps_s, z1, z2, z3 = sp.symbols("varepsilon z1 z2 z3", real=True)
Dfun = lambda L_: L_ ** (1 / (1 - ap)) * (ap * y_s) ** (ap / (1 - ap))
sfun = lambda L_: (ap * L_ * y_s) ** (1 / (1 - ap))
ell_t = ellb + eps_s * z2
ge = G_s + Dfun(ell_t)
g_t = ge + eps_s * z3
m_t = (m0b + eps_s * z1) + af_s - (af_s + sfun(ell_t)) * (1 + ge) / (1 + g_t) - k_s * g_t
dm = sp.diff(m_t, eps_s).subs(eps_s, 0)
dg = sp.diff(g_t, eps_s).subs(eps_s, 0)
Dp = sp.diff(Dfun(ellb), ellb)
Lop = (af_s + sfun(ellb)) / (1 + G_s + Dfun(ellb)) - k_s
target_dm = z1 - (k_s + ap * y_s) * Dp * z2 + Lop * z3
diff_13e = sp.expand(dm - target_dm)
check("13e (v) first-order margin response dm = z1 - [k + alpha(X-k)] Delta*' z2 + L z3",
      all(is_zero(sp.powsimp(sp.expand_power_base(diff_13e.coeff(zz), force=True), force=True)) for zz in (z1, z2, z3))
      and is_zero(sp.simplify(dg - (Dp * z2 + z3))))

bad = 0
for _ in range(100):
    a_ = RNG.uniform(0.15, 0.8)
    k_, G_ = RNG.uniform(0, 0.5), RNG.uniform(0, 0.3)
    X_ = k_ + RNG.uniform(0.2, 2)
    y_ = X_ - k_
    ellb_, m0b_, af_ = RNG.uniform(0.2, 1.5), RNG.uniform(0.1, 0.6), RNG.uniform(0, 0.4)
    rho12 = RNG.uniform(-0.9, 0.9)
    sd2, sd3 = RNG.uniform(0.1, 1), RNG.uniform(0, 1)
    # discrete mean-zero support: (z1,z2) on 4 points with correlation rho12, z3 = +/- sd3 independent
    pts12 = [(1, 1), (1, -1), (-1, 1), (-1, -1)]
    w12 = [(1 + rho12) / 4, (1 - rho12) / 4, (1 - rho12) / 4, (1 + rho12) / 4]
    Dfn = lambda L_: L_ ** (1 / (1 - a_)) * (a_ * y_) ** (a_ / (1 - a_))
    sfn = lambda L_: (a_ * L_ * y_) ** (1 / (1 - a_))
    def slope_eps(e):
        G_list, M_list, W_list = [], [], []
        for (u1, u2), w in zip(pts12, w12):
            for u3 in (-1, 1):
                z1_, z2_, z3_ = u1, sd2 * u2, sd3 * u3
                ell_ = ellb_ + e * z2_
                ge_ = G_ + Dfn(ell_)
                g_ = ge_ + e * z3_
                m_ = m0b_ + e * z1_ + af_ - (af_ + sfn(ell_)) * (1 + ge_) / (1 + g_) - k_ * g_
                G_list.append(g_); M_list.append(m_); W_list.append(w / 2)
        G_a, M_a, W_a = np.array(G_list), np.array(M_list), np.array(W_list)
        gm, mm = np.sum(W_a * G_a), np.sum(W_a * M_a)
        return np.sum(W_a * (G_a - gm) * (M_a - mm)) / np.sum(W_a * (G_a - gm) ** 2)
    Dp_ = (1 / (1 - a_)) * Dfn(ellb_) / ellb_
    V_l, V_e, C_l = Dp_**2 * sd2**2, sd3**2, Dp_ * rho12 * sd2
    L_ = (af_ + sfn(ellb_)) / (1 + G_ + Dfn(ellb_)) - k_
    bW = (C_l - (k_ + a_ * y_) * V_l + L_ * V_e) / (V_l + V_e)
    errs = [abs(slope_eps(e) - bW) for e in (1e-2, 1e-3, 1e-4)]
    bad += not (errs[2] < 1e-3 * (1 + abs(bW)) and errs[2] <= errs[0] + 1e-12)
check("13f (v) population slope of m on g converges to b_W as epsilon -> 0 (100 draws)", bad == 0,
      f"violations={bad}")
Lex = (0.3 + 0.3 * 7 * 0.1) / (1 + 0.1 + 0.1)
share0 = 2.1 / (2.1 + Lex)
check("13g (v) appendix example: X=7, alpha=0.3, k=0, G=0.1, Delta*=0.1, a_f=0.3: L=0.425, zero slope needs "
      "surprise share 2.1/2.525 = 0.83", abs(Lex - 0.425) < 1e-12 and abs(share0 - 0.8317) < 1e-4
      and abs(share0 * Lex - (1 - share0) * 2.1) < 1e-12, f"L={Lex:.4f}, share={share0:.4f}")

# Remark (segment-specific G): envelope can rise
a_ = 0.3
ell1 = 0.5
m1_at_01 = 0.2 - ell1 ** (-1 / a_) * 0.1 ** (1 / a_)
check("13h segment-specific G example: Phi(0.1) = m1*(0.1) < 0.2 < 0.5 = Phi(0.3)",
      m1_at_01 < 0.2 and ell1 * 1.0**a_ >= 0.1, f"m1*(0.1)={m1_at_01:.4f}")

# ==============================================================================================
header("14. Pass-through cases (Lemma lem:prices(a))")
# ==============================================================================================
u_s, rb_s, A_s, n_s, e_s = sp.symbols("u rb A n epsilon", positive=True)
p_cournot = (A_s + n_s * (u_s + rb_s)) / (n_s + 1)
phi_c = sp.simplify(sp.diff(p_cournot, u_s) * u_s / p_cournot)
check("14a Cournot linear demand: phi = n/(n+1) * u/p", is_zero(phi_c - n_s / (n_s + 1) * u_s / p_cournot))
p_mono = e_s / (e_s - 1) * (u_s + rb_s)
check("14b constant-elasticity monopoly: phi = u/(u + r b)",
      is_zero(sp.simplify(sp.diff(p_mono, u_s) * u_s / p_mono) - u_s / (u_s + rb_s)))
p_pc = u_s + rb_s
check("14c perfect competition: phi = u/(u + r b)", is_zero(sp.diff(p_pc, u_s) * u_s / p_pc - u_s / (u_s + rb_s)))

# ==============================================================================================
header("15. Dynamic optimality: the firm's growth weight is the marginal q of revenue (Proposition prop:dynamic)")
# ==============================================================================================
Ms, vs, vps, rs_, sigs, Dls = sp.symbols("M v vprime r sigma Delta", positive=True)
ss_ = sp.symbols("s", positive=True)
flow = (m0 - sigs - k * (G + Dls)) * ss_ * Ms          # FCF m S with S = s M
V_s, V_M = Ms * vps, vs                                # V = M v(s): V_s = M v'(s), V_M = v(s)
hjb_resid = rs_ * Ms * vs - (flow + V_s * ss_ * Dls + V_M * G * Ms)
target = Ms * ((rs_ - G) * vs - ss_ * (m0 - sigs - k * G + (vps - k) * Dls))
check("15a HJB: r V = flow + V_s sdot + V_M Mdot with V = M v(s) reduces to (r-G) v = s[m0 - sigma - kG + (v'-k) Delta]",
      is_zero(sp.expand(hjb_resid - target)))
Xs = sp.symbols("X_s", positive=True)
R_on_frontier = Xs * (G + Dls) + m0 - sigs - k * (G + Dls)
check("15b HJB maximand = R_X(g,m) - X G at X = v'(s)",
      is_zero(sp.expand((m0 - sigs - k * G + (Xs - k) * Dls) - (R_on_frontier - Xs * G))))
qs_, yq = sp.symbols("q y_q", positive=True)  # yq = q - k > 0
Dq = lam ** (1 / (1 - al)) * (al * yq) ** (al / (1 - al))
sq = al * yq * Dq
gordon_resid = (rs_ - G - Dq) * (k + yq) - (m0 - k * (G + Dq) - sq)
root_cond = (rs_ - G) * (k + yq) - (m0 - k * G + (1 - al) * yq * Dq)
check("15c Gordon identity: at a root of (eq:gordon), (r - G - Delta0) v0 = m0 - k g0 - sigma0",
      is_zero(sp.expand(gordon_resid - root_cond)))
Pi_q = Calpha * (lam * yq) ** (1 / (1 - al))
check("15d f'(q) = (r-G) - Delta*(lambda, q): d/dq of C_alpha [lambda (q-k)]^(1/(1-alpha)) = Delta*(lambda, q)",
      log_equal(sp.diff(Pi_q, yq), Dq))


def smallest_root(m0_, k_, G_, r_, lam_, a_, qmax=2000.0):
    Ca = (1 - a_) * a_ ** (a_ / (1 - a_))
    f = lambda q: (r_ - G_) * q - (m0_ - k_ * G_) - Ca * (lam_ * max(q - k_, 0.0)) ** (1 / (1 - a_))
    grid = np.concatenate([np.linspace(0, 50, 50001), np.linspace(50, qmax, 20001)[1:]])
    vals = np.array([f(q) for q in grid])
    idx = np.where(vals >= 0)[0]
    if len(idx) == 0:
        return None, f
    i = idx[0]
    from scipy.optimize import brentq
    return brentq(f, grid[i - 1], grid[i], xtol=1e-14), f


bad, n_roots = 0, 0
for _ in range(500):
    a_ = RNG.uniform(0.2, 0.5)
    r_, G_ = RNG.uniform(0.06, 0.15), RNG.uniform(0.0, 0.05)
    k_ = RNG.uniform(0, 0.5)
    m0_ = k_ * G_ + RNG.uniform(0.05, 0.6)
    lam_ = RNG.uniform(0.01, 0.2)
    v0, f = smallest_root(m0_, k_, G_, r_, lam_, a_)
    if v0 is None:
        continue
    eps = 1e-7
    fp = (f(v0 + eps) - f(v0 - eps)) / (2 * eps)
    if fp <= 1e-9:
        continue  # not a simple root
    n_roots += 1
    D0, s0_, R0 = closed_form(m0_, G_, k_, v0, lam_, a_)
    g0 = G_ + D0
    mo = m0_ - k_ * g0 - s0_
    bad += not (g0 < r_ and abs(v0 - mo / (r_ - g0)) < 1e-8 * (1 + v0) and mo > 0 and v0 > 0
                and abs(fp - ((r_ - G_) - D0)) < 1e-5)
check("15e smallest simple roots: g0 < r, v0 = m0/(r - g0) (Gordon), m0 > 0, f'(v0) = r - G - Delta0",
      bad == 0 and n_roots > 100, f"simple roots={n_roots}, violations={bad}")

# worked example: r = 0.10, G = 0.04, k = 0, alpha = 0.3, m0 = 0.35
r_, G_, k_, a_, m0_ = 0.10, 0.04, 0.0, 0.3, 0.35
Ca = (1 - a_) * a_ ** (a_ / (1 - a_))
lam_for = lambda v0: (((r_ - G_) * v0 - (m0_ - k_ * G_)) / Ca) ** (1 - a_) / (v0 - k_)
ex = {}
for v0t in [10.0, 15.0]:
    lam_ = lam_for(v0t)
    v0, f = smallest_root(m0_, k_, G_, r_, lam_, a_)
    D0, s0_, _ = closed_form(m0_, G_, k_, v0, lam_, a_)
    ex[v0t] = (lam_, v0, G_ + D0, s0_, m0_ - k_ * (G_ + D0) - s0_)
    print(f"     worked example v0={v0t:.0f}: lambda={lam_:.4f}, smallest root={v0:.6f}, g0={G_ + D0:.4f}, "
          f"sigma0={s0_:.4f}, m0_circ={ex[v0t][4]:.4f}, sigma/Delta={s0_ / D0:.3f}")
check("15f worked example: lambda ~ 0.070 (v0 = 10: g 7.6%, spend 10.7%, margin 24.3%) and ~ 0.081 (v0 = 15: "
      "g 9.2%, spend 23.6%, margin 11.4%); no-growth multiple m0/(r-G) = 5.83",
      abs(ex[10.0][0] - 0.0698) < 5e-4 and abs(ex[10.0][1] - 10) < 1e-8 and abs(ex[10.0][2] - 0.0757) < 5e-4
      and abs(ex[10.0][3] - 0.1071) < 5e-4 and abs(ex[10.0][4] - 0.2429) < 5e-4
      and abs(ex[15.0][0] - 0.0808) < 5e-4 and abs(ex[15.0][1] - 15) < 1e-8 and abs(ex[15.0][2] - 0.0924) < 5e-4
      and abs(ex[15.0][3] - 0.2357) < 5e-4 and abs(ex[15.0][4] - 0.1143) < 5e-4
      and abs(m0_ / (r_ - G_) - 5.8333) < 1e-3)


def solve_hjb(m0_, k_, G_, r_, lam_, a_, sbar_, N=4000, smin=1e-9):
    """Upwind backward sweep for the saturated HJB (share only rises, so the scheme is causal in s)."""
    half = N // 2
    u = np.concatenate([np.geomspace(smin, 0.5, half, endpoint=False), 1 - np.geomspace(0.5, 1e-9, N - half)])
    s = sbar_ * u
    v = np.zeros(N)
    sig = np.zeros(N)
    v[-1] = s[-1] * (m0_ - k_ * G_) / (r_ - G_)
    grid = np.concatenate([[0.0], np.geomspace(1e-10, 50, 240)])
    for i in range(N - 2, -1, -1):
        ell_i = lam_ * (1 - s[i] / sbar_)
        ds = s[i + 1] - s[i]

        def val(sg):
            D_ = ell_i * sg**a_
            ai = s[i] * D_ / ds
            return (s[i] * (m0_ - sg - k_ * (G_ + D_)) + ai * v[i + 1]) / ((r_ - G_) + ai)

        vals = np.array([val(x) for x in grid])
        j = int(np.argmax(vals))
        lo, hi = grid[max(j - 1, 0)], grid[min(j + 1, len(grid) - 1)]
        res = minimize_scalar(lambda x: -val(x), bounds=(lo, hi), method="bounded", options={"xatol": 1e-13})
        if -res.fun >= vals[j]:
            v[i], sig[i] = -res.fun, res.x
        else:
            v[i], sig[i] = vals[j], grid[j]
    return s, v, sig


lam10 = ex[10.0][0]
sbar_ = 0.5
s_h, v_h, sig_h = solve_hjb(m0_, k_, G_, r_, lam10, a_, sbar_, N=4000)
s_h2, v_h2, _ = solve_hjb(m0_, k_, G_, r_, lam10, a_, sbar_, N=2000)
vp_h = np.gradient(v_h, s_h)
at = lambda arr, sv: np.interp(sv, s_h, arr)
rows = []
for frac in [0.01, 0.1, 0.5]:
    sv = frac * sbar_
    rows.append((frac, at(vp_h, sv), at(v_h, sv) / sv))
print("     saturated HJB (v0=10, sbar=0.5): " + "; ".join(
    f"s/sbar={fr:.2f}: v'={vp:.3f}, v/s={avg:.3f}" for fr, vp, avg in rows))
check("15g saturated HJB: growth weight v'(s) = 9.1, 7.2, 5.4 and v(s)/s = 9.4, 8.1, 6.5 at 1%, 10%, 50% of cap",
      all(abs(round(vp, 1) - e) < 1e-9 for (_, vp, _), e in zip(rows, [9.1, 7.2, 5.4]))
      and all(abs(round(avg, 1) - e) < 1e-9 for (_, _, avg), e in zip(rows, [9.4, 8.1, 6.5])))
conv = np.max(np.abs(np.interp(s_h2, s_h, v_h) - v_h2) / s_h2)
check("15h grid convergence: N=2000 vs N=4000 differ by < 0.02 in v(s)/s", conv < 0.02, f"max diff={conv:.4f}")
check("15i bounds: (m0-kG)s/(r-G) <= v(s) <= v0 s on the whole grid (Proposition prop:dynamic(a),(d))",
      np.all(v_h <= 10.0 * s_h * (1 + 1e-9)) and np.all(v_h >= (m0_ - k_ * G_) * s_h / (r_ - G_) * (1 - 1e-9)))
small = s_h < 1e-6
check("15j small share: v(s)/s -> v0 and v'(s) -> v0 (within 0.01 for s < 1e-6)",
      np.all(np.abs(v_h[small] / s_h[small] - 10) < 0.01) and np.all(np.abs(vp_h[small][2:] - 10) < 0.01),
      f"v/s at smallest s = {v_h[0] / s_h[0]:.5f}, v' = {vp_h[2]:.5f}")
# HJB identity R*_{X(s)} = (r-G) v/s + G X(s) along the numerical solution
idx = (s_h > 1e-5) & (s_h < 0.45)
Xd = vp_h[idx]
Rstar = np.array([closed_form(m0_, G_, k_, Xv, lam10 * (1 - sv / sbar_), a_)[2] for Xv, sv in zip(Xd, s_h[idx])])
resid = np.max(np.abs(Rstar - ((r_ - G_) * v_h[idx] / s_h[idx] + G_ * Xd)))
check("15k HJB identity R*_{v'(s)}(s) = (r-G) v(s)/s + G v'(s) on the numerical solution", resid < 5e-3,
      f"max residual={resid:.2e}")
# simulate the closed-loop feedback policy and compare discounted payoff with v(s0)
from scipy.integrate import solve_ivp
for s0v in [0.005, 0.05]:
    sig_of_s = lambda sv: max(np.interp(sv, s_h, sig_h), 0.0)

    def rhs(t_, z):
        sv = min(max(z[0], 1e-12), sbar_ * (1 - 1e-12))
        sg = sig_of_s(sv)
        D_ = lam10 * (1 - sv / sbar_) * sg**a_
        mt = m0_ - sg - k_ * (G_ + D_)
        return [sv * D_, np.exp(-(r_ - G_) * t_) * sv * mt]

    sol = solve_ivp(rhs, (0, 600), [s0v, 0.0], rtol=1e-9, atol=1e-12, max_step=0.5)
    payoff = sol.y[1, -1]
    check(f"15l closed-loop simulation from s0={s0v}: discounted payoff matches v(s0) within 0.5%",
          abs(payoff - at(v_h, s0v)) / at(v_h, s0v) < 5e-3, f"payoff={payoff:.6f}, v(s0)={at(v_h, s0v):.6f}")
# lower bound of Proposition prop:dynamic(d) with the constant policy sigma0
D0 = ex[10.0][2] - G_
mo = ex[10.0][4]
lbs = []
for s0v in [1e-2, 1e-3, 1e-4, 1e-6]:
    u0 = s0v / sbar_
    integrand = lambda tt: np.exp(-(r_ - G_ - D0) * tt) / (1 + u0 * (np.exp(D0 * tt) - 1))
    tt = np.linspace(0, 3000, 600001)
    lbs.append(mo * np.trapezoid(integrand(tt), tt))
print("     constant-policy lower bound v(s0)/s0 >= " + ", ".join(f"{lb:.4f}" for lb in lbs) + " (s0 = 1e-2 ... 1e-6)")
check("15m constant-policy lower bound increases to v0 as s0 -> 0 and lies below the HJB value",
      all(np.diff(lbs) > 0) and abs(lbs[-1] - 10) < 0.01
      and all(lb <= at(v_h, sv) / sv + 1e-6 for lb, sv in zip(lbs, [1e-2, 1e-3, 1e-4, 1e-6])))
# implication: spend ratio 3.3 => X - k = 3.3/alpha in [7.3, 13.2]
check("15n spend ratio 3.3 implies X - k = 3.3/alpha = 7.33 to 13.2 for alpha in [0.25, 0.45]",
      abs(3.3 / 0.45 - 7.333) < 1e-3 and abs(3.3 / 0.25 - 13.2) < 1e-12)

# ==============================================================================================
header("16. Screening weight (Lemma lem:valuation2): Gordon limit and coincidence with the revenue multiple")
# ==============================================================================================
bad = 0
for _ in range(200):
    m_, g_, r_ = RNG.uniform(0.05, 0.4), RNG.uniform(0.0, 0.08), RNG.uniform(0.09, 0.15)
    T = 3000
    Xs_ = X_two_stage(m_, 0.0, 1.0, g_, r_, 0.0, T) if False else None
    eta = (1 + g_) / (1 + r_)
    tgrid = np.arange(1, T + 1)
    w_ = eta**tgrid
    Xs_ = m_ * np.sum(tgrid * w_) / ((1 + g_) * np.sum(w_))
    lim = m_ * (1 + r_) / ((1 + g_) * (r_ - g_))
    VS = m_ * np.sum(w_)
    bad += not (abs(Xs_ - lim) < 1e-6 * lim and abs(lim / (m_ * (1 + g_) / (r_ - g_)) - (1 + r_) / (1 + g_) ** 2) < 1e-12
                and abs(VS - m_ * (1 + g_) / (r_ - g_)) < 1e-6 * VS)
check("16a (d) T -> oo: X_scr -> m(1+r)/[(1+g)(r-g)] = (V/S0)(1+r)/(1+g)^2 (200 draws)", bad == 0, f"violations={bad}")

# ==============================================================================================
header("17. What the results assume (Remark rem:assumptions)")
# ==============================================================================================
# (a) fixed cost: R*(s) rises with s at small shares
a_, lam_, G_, k_, X_, gam_, av_, Xi_, M_, sbar_ = 0.3, 0.8, 0.1, 0.0, 1.0, 0.8, 0.1, 0.02, 1.0, 0.5
Rfix = lambda sv: closed_form(gam_ - av_ - Xi_ / (sv * M_), G_, k_, X_, lam_ * (1 - sv / sbar_), a_)[2]
svals = np.linspace(0.01, 0.05, 50)
deriv_num = np.array([(Rfix(sv + 1e-7) - Rfix(sv - 1e-7)) / 2e-7 for sv in svals])
deriv_cf = [Xi_ / (sv**2 * M_) - (X_ - k_) * closed_form(0, G_, k_, X_, lam_ * (1 - sv / sbar_), a_)[0] / (sbar_ - sv)
            for sv in svals]
check("17a (a) fixed cost: dR*/ds = Xi/(s^2 M) - (X-k) Delta*/(sbar - s) > 0 at small s",
      np.allclose(deriv_num, deriv_cf, rtol=1e-5) and np.all(np.array(deriv_cf) > 0))
# (b) firm-specific zero-spend growth: budget with drift
bad = 0
for _ in range(1000):
    m0_, k_ = RNG.uniform(0, 0.8), RNG.uniform(0, 1)
    X_ = k_ + RNG.uniform(0.1, 3)
    y_ = X_ - k_
    G_, Gi = RNG.uniform(0, 0.3), RNG.uniform(-0.1, 0.4)
    T, n = RNG.uniform(1, 30), 2000
    dt = T / n
    gpath = Gi + RNG.exponential(RNG.uniform(0.01, 1.0), n)
    mpath = m0_ - k_ * gpath - RNG.exponential(0.2, n)
    lhs = np.sum(np.maximum(X_ * gpath + mpath - (m0_ + y_ * Gi), 0)) * dt
    log_share = np.sum(gpath - G_) * dt
    bad += not (lhs <= y_ * (log_share + (G_ - Gi) * T) + 1e-9)
check("17b (b) G_i != G: integral (R - R_inf,i)^+ <= (X-k)[ln(s_T/s0) + (G - G_i) T] (1000 paths)", bad == 0,
      f"violations={bad}")
# (c) k < 0: closed forms hold; frontier rises until Delta_0; depreciation
bad = 0
for _ in range(300):
    a_, ell = RNG.uniform(0.2, 0.6), RNG.uniform(0.2, 1.5)
    k_ = -RNG.uniform(0.05, 0.6)
    X_, G_, m0_ = RNG.uniform(0, 3), RNG.uniform(0, 0.3), RNG.uniform(0, 0.8)
    b_ = 1 / a_
    kap = ell ** (-b_)
    Dcf, scf, Rcf = closed_form(m0_, G_, k_, X_, ell, a_)
    grid = np.linspace(0, 6, 600001)
    vals = m0_ + (X_ - k_) * G_ + (X_ - k_) * grid - kap * grid**b_
    D0 = (-k_ / (b_ * kap)) ** (1 / (b_ - 1))
    mstar = m0_ - k_ * (G_ + grid) - kap * grid**b_
    ok = abs(vals.max() - Rcf) < 1e-6 * (1 + abs(Rcf)) and abs(grid[np.argmax(vals)] - Dcf) < 1e-4 * (1 + Dcf)
    ok &= abs(grid[np.argmax(mstar)] - D0) < 1e-4 * (1 + D0)
    bad += (not ok)
check("17c (c) k < 0: Rule-of-X closed forms hold; frontier peaks at Delta_0 = [-k/(beta kappa)]^(1/(beta-1))",
      bad == 0, f"violations={bad}")
bad = 0
for _ in range(200):
    a_, ell = RNG.uniform(0.2, 0.6), RNG.uniform(0.2, 1.5)
    k_, X_, G_, m0_, dl = RNG.uniform(0, 1), RNG.uniform(1.2, 3), RNG.uniform(0, 0.3), RNG.uniform(0, 0.8), RNG.uniform(0.2, 0.33)
    Rk = lambda kk: closed_form(m0_ - dl * kk, G_, kk, X_, ell, a_)[2]
    e = 1e-6
    fd = (Rk(k_ + e) - Rk(k_ - e)) / (2 * e)
    gst = G_ + closed_form(m0_, G_, k_, X_, ell, a_)[0]
    bad += abs(fd + (gst + dl)) > 1e-5 * (1 + gst)
check("17d (c) depreciation: dR*/dk = -(g* + delta) (200 draws); hurdles 3.5 and 7.5 points at delta = 0.25",
      bad == 0 and abs((0.10 + 0.25) * 0.10 - 0.035) < 1e-15 and abs((0.50 + 0.25) * 0.10 - 0.075) < 1e-15,
      f"violations={bad}")
# (d) network effects: budget holds for non-monotone headroom
bad = 0
for _ in range(200):
    a_, lam_, sbar_ = RNG.uniform(0.2, 0.6), RNG.uniform(0.2, 3), RNG.uniform(0.2, 0.9)
    cnet = RNG.uniform(0, 8)
    hnet = lambda sv: (1 - sv / sbar_) * (1 + cnet * sv / sbar_)  # rises then falls when cnet > 1
    m0_, k_ = RNG.uniform(0, 0.8), RNG.uniform(0, 1)
    X_ = k_ + RNG.uniform(0.1, 3)
    y_ = X_ - k_
    G_ = RNG.uniform(0, 0.3)
    s0v = sbar_ * RNG.uniform(1e-3, 0.5)
    sgv = np.exp(RNG.normal(-1, 1))

    def rhs(t_, z):
        sv = min(max(z[0], 1e-12), sbar_)
        D_ = lam_ * hnet(sv) * sgv**a_
        R_ = X_ * (G_ + D_) + m0_ - sgv - k_ * (G_ + D_)
        return [sv * D_, max(R_ - (m0_ + y_ * G_), 0.0)]

    sol = solve_ivp(rhs, (0, RNG.uniform(1, 20)), [s0v, 0.0], rtol=1e-9, atol=1e-12)
    bad += not (sol.y[1, -1] <= y_ * math.log(sol.y[0, -1] / s0v) * (1 + 1e-6) + 1e-9
                and sol.y[0, -1] <= sbar_ * (1 + 1e-6))  # tolerance for ODE overshoot at the cap
check("17e (d) network effects: score budget holds with non-monotone headroom (200 ODE paths)", bad == 0,
      f"violations={bad}")

# ==============================================================================================
header("18. Automation priorities (Corollary cor:priorities)")
# ==============================================================================================
bad = 0
for _ in range(300):
    a_, lam_, h_ = RNG.uniform(0.2, 0.6), RNG.uniform(0.2, 1.5), RNG.uniform(0.1, 1)
    k_, G_, m0_ = RNG.uniform(0, 0.5), RNG.uniform(0, 0.3), RNG.uniform(0, 0.8)
    X_ = k_ + RNG.uniform(0.2, 8)
    x = RNG.uniform(0.01, 0.5)
    D_, sg, R0 = closed_form(m0_, G_, k_, X_, lam_ * h_, a_)
    R1 = closed_form(m0_, G_, k_, X_, lam_ * (1 + x) * h_, a_)[2]
    Pi_ = (1 - a_) * (X_ - k_) * D_
    ok = abs((R1 - R0) - Pi_ * ((1 + x) ** (1 / (1 - a_)) - 1)) < 1e-10 * (1 + R0)        # exact (ii)
    e = 1e-6
    Rp = closed_form(m0_, G_, k_, X_, lam_ * (1 + e) * h_, a_)[2]
    ok &= abs((Rp - R0) / e - sg / a_) < 1e-4 * (1 + sg / a_)                                 # first order (ii)
    ok &= abs((Rp - R0) / e - (X_ - k_) * D_) < 1e-4 * (1 + (X_ - k_) * D_)
    da = RNG.uniform(0, 0.1)
    ok &= abs(closed_form(m0_ + da, G_, k_, X_, lam_ * h_, a_)[2] - R0 - da) < 1e-12               # (i)
    dG = RNG.uniform(0, 0.1)
    ok &= abs(closed_form(m0_, G_ + dG, k_, X_, lam_ * h_, a_)[2] - R0 - (X_ - k_) * dG) < 1e-12  # (iii)
    bad += (not ok)
check("18a (i)-(iii): exact gains da, Pi[(1+x)^(1/(1-alpha)) - 1], (X-k) dG; first order x sigma*/alpha (300 draws)",
      bad == 0, f"violations={bad}")
check("18b (ii) ratio 1/alpha in [2.2, 4] for alpha in [0.25, 0.45]", abs(1 / 0.45 - 2.222) < 1e-3 and 1 / 0.25 == 4)
# (iv) long-run competitive score depends on u only through b/chat
A_, B_, b_, r_, G_, X_ = 2.0, 1.0, 0.8, 0.10, 0.05, 1.0
lim_u = lambda uu: X_ * G_ + (r_ - G_) * b_ / (uu + r_ * b_)
check("18c (iv) competitive limit XG + (r-G) b/chat rises as u falls when b > 0 and is constant when b = 0",
      lim_u(0.4) > lim_u(0.6) and abs((X_ * G_ + (r_ - G_) * 0.0 / (0.4)) - (X_ * G_ + (r_ - G_) * 0.0 / 0.6)) == 0)

# ==============================================================================================
header("19. Industry subsection opening: common frontier with high opportunity")
# ==============================================================================================
chord = lambda a_, ell: -((0.6 / ell) ** (1 / a_)) / 0.6
steep = lambda a_, ell: (1 / a_) * (0.6 / ell) ** (1 / a_ - 1) / ell
print(f"     chord slope over Delta in [0,0.6]: alpha=0.25, ell=0.86: {chord(0.25, 0.86):.4f}; "
      f"alpha=0.45, ell=1.14: {chord(0.45, 1.14):.4f}; steepest slopes {steep(0.25, 0.86):.3f}, {steep(0.45, 1.14):.3f}")
check("19a common frontier m0 - (Delta/ell)^beta: average slope about -0.4 over [0, 0.6] (fall of about 24 points) "
      "at ell = 0.86 (alpha 0.25) and 1.14 (alpha 0.45); steepest slopes 1.58 and 0.89",
      abs(chord(0.25, 0.86) + 0.395) < 2e-3 and abs(chord(0.45, 1.14) + 0.400) < 2e-3
      and abs(0.6 * chord(0.25, 0.86) + 0.237) < 2e-3 and abs(0.6 * chord(0.45, 1.14) + 0.240) < 2e-3
      and abs(steep(0.25, 0.86) - 1.58) < 5e-3 and abs(steep(0.45, 1.14) - 0.89) < 5e-3)

# ==============================================================================================
header("20. Full-cost ceiling (Definition def:fullcost, Corollary cor:ceiling, Tables tab:ceiling and tab:fullcost)")
# ==============================================================================================
# Inputs duplicate code/calibrate_horizons.py (FC); check 20k confirms that its JSON reproduces them.
S_REF = 1e9
WAGE_GOV = 88400 * (1 + 0.4287)
FC = {
    'c_c': (0.15, 0.20, 0.25), 'f': (0.02, 0.025, 0.03), 'tau': (0.15, 0.18, 0.21), 'a_min': (0.015, 0.03, 0.046),
    's0': (0.0069, 0.0069, 0.0069), 'L0': (4.0, 2.0, 1.0), 'Me': (1.0, 2.0, 3.0), 'sec_it': (0.119, 0.099, 0.086),
    'phi_pqc': (0.0075, 0.015, 0.03),
    'aic_fixed': (12e3 + 10e3 + 2.5e3 + (5e3 + 13e3) / 3 + 0.10 * WAGE_GOV,
                  30e3 + 35e3 + 6e3 + (13.5e3 + 30e3) / 3 + 0.25 * WAGE_GOV,
                  150e3 + 60e3 + 9e3 + (20e3 + 50e3) / 3 + 1.00 * WAGE_GOV),
    'aic_pp': (0.5, 1.0, 2.0), 'delta_M': (0.10, 0.17, 0.40), 'kappa_rv': (0.05, 0.10, 0.20), 'T_up': (1.75, 1.22, 0.99),
    'B': (0.012, 0.024, 0.048),
    'A_auto': (0.30, 0.30, 0.30), 'u_rev': (0.0345 * 0.15 + 0.015 * 0.40, 0.0345 * 0.35 + 0.05 * 0.60, 0.0345 * 0.35 + 0.05 * 0.60),
    'ell_e': (0.25, 0.5, 1.0), 'mu_m': (0.0005, 0.001, 0.002), 'd_m': (0.95, 0.60, 0.42), 'ell_m': (10.0, 10.0, 10.0),
    'p_tail': (2.3, 1.5, 1.15), 'Zcap': (100.0, 100.0, 100.0), 'nu_cm': (0.5, 2.0, 6.0), 'XY': (1.0, 1.0, 1.0),
    's_fin': (0.015, 0.03, 0.06), 'anc_fixed': (62.5e3, 125e3, 250e3),
}
CASES = ['favorable', 'central', 'conservative', 'high compute']


def fullcost(case, cc=None, tau_=None, amin_=None):
    i = {'favorable': 0, 'central': 1, 'conservative': 2, 'high compute': 1}[case]
    v = {kk: val[i] for kk, val in FC.items()}
    if case == 'high compute':
        v['c_c'] = 0.40
    if cc is not None:
        v['c_c'] = cc
    if tau_ is not None:
        v['tau'] = tau_
    if amin_ is not None:
        v['a_min'] = amin_
    risk = v['s0'] / v['L0'] * (1 + v['L0'] + math.log(v['Me']))
    pqc = v['phi_pqc'] * v['s0'] / v['sec_it']
    aic = (v['aic_fixed'] + v['aic_pp'] * 48 * (30e3 + 10e3 / 1.22)) / S_REF
    c_sec = risk + pqc + aic
    c_mnt = (v['delta_M'] + v['kappa_rv'] / v['T_up']) * v['B']
    Emin = 1 + (1 - v['Zcap'] ** (1 - v['p_tail'])) / (v['p_tail'] - 1)
    c_err_e = v['A_auto'] * v['u_rev'] * v['ell_e']
    c_err_m = v['A_auto'] * v['mu_m'] * (1 - v['d_m']) * v['ell_m'] * Emin
    c_err_cm = v['nu_cm'] / 365 * v['A_auto'] * (1 + v['XY'])
    c_err = c_err_e + c_err_m + c_err_cm
    c_anc = v['s_fin'] * v['c_c'] + v['anc_fixed'] / S_REF
    c_full = c_mnt + c_sec + c_err + c_anc
    base = (1 - v['tau']) * (1 - v['c_c'] - v['f'] - v['a_min'] - c_full)
    base_acc = (1 - v['tau']) * (1 - v['c_c'] - v['f'] - v['a_min'])
    return dict(v=v, risk=risk, pqc=pqc, aic=aic, c_sec=c_sec, c_mnt=c_mnt, c_err=c_err, c_err_e=c_err_e, c_err_m=c_err_m,
                c_err_cm=c_err_cm, c_anc=c_anc, c_full=c_full,
                base=base, base_acc=base_acc, G100=1 - base, G100_acc=1 - base_acc)


FCR = {c: fullcost(c) for c in CASES}
print("     Full-cost floors, percent of revenue (Appendix Table tab:fullcost):")
for c in CASES:
    r_ = FCR[c]
    print(f"     {c:12s} risk {100 * r_['risk']:.3f} pqc {100 * r_['pqc']:.3f} aic {100 * r_['aic']:.3f} | c_sec "
          f"{100 * r_['c_sec']:.2f} c_mnt {100 * r_['c_mnt']:.2f} c_err {100 * r_['c_err']:.2f} c_anc {100 * r_['c_anc']:.2f}"
          f" c_full {100 * r_['c_full']:.2f} | base {100 * r_['base']:.2f} (acc. only {100 * r_['base_acc']:.2f}) | "
          f"G* {100 * r_['G100']:.2f}% (acc. only {100 * r_['G100_acc']:.2f}%)")
# values printed in Appendix Table tab:fullcost (percent of revenue, two decimals)
tab_fc_expected = {
    'favorable': dict(risk=0.86, pqc=0.04, aic=0.10, c_sec=1.00, c_mnt=0.15, c_err_e=0.08, c_err_m=0.01, c_err_cm=0.08,
                      c_err=0.18, c_anc=0.23, c_full=1.57),
    'central': dict(risk=1.27, pqc=0.10, aic=0.20, c_sec=1.57, c_mnt=0.60, c_err_e=0.63, c_err_m=0.34, c_err_cm=0.33,
                    c_err=1.30, c_anc=0.61, c_full=4.09),
    'conservative': dict(risk=2.14, pqc=0.24, aic=0.40, c_sec=2.78, c_mnt=2.89, c_err_e=1.26, c_err_m=1.51, c_err_cm=0.99,
                         c_err=3.75, c_anc=1.52, c_full=10.95),
    'high compute': dict(risk=1.27, pqc=0.10, aic=0.20, c_sec=1.57, c_mnt=0.60, c_err_e=0.63, c_err_m=0.34, c_err_cm=0.33,
                         c_err=1.30, c_anc=1.21, c_full=4.69),
}
ok = all(abs(round(100 * FCR[c][kk], 2) - e) < 1e-9 for c in CASES for kk, e in tab_fc_expected[c].items())
check("20a Appendix Table tab:fullcost: risk, PQC, AI compliance, c_sec, c_mnt, the three parts of c_err, c_err, c_anc, "
      "c_full as printed", ok)
# risk cost from Proposition tasks-security(b) by direct minimization of C + exp(-C/C_s) C_inc
ok = True
for c in ['favorable', 'central', 'conservative']:
    v = FCR[c]['v']
    Cs = v['s0'] / v['L0']
    Cinc0 = Cs * math.exp(v['L0'])                              # today: optimal spend C_s ln(C_inc/C_s) = s0
    spend0 = minimize_scalar(lambda C: C + math.exp(-C / Cs) * Cinc0, bounds=(0, 1), method='bounded',
                             options={'xatol': 1e-14}).x
    res = minimize_scalar(lambda C: C + math.exp(-C / Cs) * Cinc0 * v['Me'], bounds=(0, 1), method='bounded',
                          options={'xatol': 1e-14})
    ok &= abs(spend0 - v['s0']) < 1e-8 and abs(res.fun - FCR[c]['risk']) < 1e-9 and Cinc0 >= Cs
    ok &= spend0 <= Cinc0 / math.e + 1e-12                       # Gordon-Loeb bound (1/e of expected loss)
check("20b c_sec risk cost: optimal spend today equals s0 = 0.69% and full-automation risk cost "
      "C_s(1 + L0 + ln M_e) equals the minimum of C + exp(-C/C_s) M_e C_inc; spend <= C_inc/e", ok)
# c_err parts: Prop tasks-halluc(a) review-proof rate; Prop tasks-autonomy(a) capped Pareto mean; Prop ext-commonmode(a)
cm = 2.0 * (1 / 365) * (0.3 + 1.0 * 0.3 ** 2 / (2 * 0.15))
Zc, pt = 100.0, 1.5
Emc = 1 + (1 - Zc ** (1 - pt)) / (pt - 1)
zs = (1 - RNG.uniform(size=2000000)) ** (-1 / pt)
check("20c c_err parts: review-proof rate e_o(1-d_o) + e_h(1-d_h) = 0.0421 at central rates; capped Pareto mean "
      "E min(Z, 100) = 2.8 at tail index 1.5 (Monte Carlo); common mode nu T_con [X + H X^2/(2Y_f)]/S = 0.33% at "
      "2 day-equivalent events, X = 0.3, Y_f = 0.15, H = 1",
      abs(0.0345 * 0.35 + 0.05 * 0.60 - 0.042075) < 1e-12 and abs(Emc - 2.8) < 1e-12
      and abs(np.minimum(zs, Zc).mean() - Emc) < 0.01 and abs(cm - FCR['central']['c_err_cm']) < 1e-15
      and round(100 * cm, 2) == 0.33)
cols = [(0.05, 0.0), (0.15, 0.0), (0.30, 0.0), (0.15, 0.5), (0.05, 1.5), (0.30, 1.5)]


def Rmax_full(case, G_, k_, X_=1.0, psi_=0.0, dK=0.0):
    r_ = FCR[case]
    v = r_['v']
    return (1 - v['tau']) * (1 - v['c_c'] - v['f'] - v['a_min'] - r_['c_full'] - dK * k_) + (X_ - (1 - psi_ * v['tau']) * k_) * G_


print("     LaTeX rows for Table tab:ceiling:")
rows_ok = True
tab_ceil_expected = {
    'favorable': [67.9, 72.9, 82.9, 97.9, 75.4, 65.4, 52.9, 32.1],
    'central': [57.7, 62.7, 72.7, 87.7, 65.2, 55.2, 42.7, 42.3],
    'conservative': [44.6, 49.6, 59.6, 74.6, 52.1, 42.1, 29.6, 55.4],
    'high compute': [40.8, 45.8, 55.8, 70.8, 48.3, 38.3, 25.8, 59.2],
}
for c in CASES:
    r_ = FCR[c]
    v = r_['v']
    vals = [round(100 * r_['base'], 1)] + [round(100 * Rmax_full(c, G_, k_), 1) for G_, k_ in cols] + [round(100 * r_['G100'], 1)]
    print(f"     {c.capitalize()} & {v['c_c']:.2f} & {v['f']:.3g} & {v['a_min']:.3g} & {100 * r_['c_full']:.1f} & {v['tau']:.2f} & "
          + " & ".join(f"{x:.1f}" for x in vals[:-1]) + f" & {vals[-1]:.1f}" + r" \\")
    rows_ok &= all(abs(x - e) < 1e-9 for x, e in zip(vals, tab_ceil_expected[c]))
check("20d Table tab:ceiling rows (as printed in model.tex): base, six (G,k) cells and the 100-point threshold", rows_ok)
grid_full = []
for i in [0, 2]:
    for G_ in [0.05, 0.30]:
        for k_ in [0.0, 1.5]:
            c = ['favorable', 'central', 'conservative'][i]
            grid_full.append(Rmax_full(c, G_, k_))
print(f"     full-cost corner grid (favorable/conservative cases): min {100 * min(grid_full):.1f}, max {100 * max(grid_full):.1f}")
close = lambda x, e, tol=0.05: abs(x - e) <= tol + 1e-9
check("20e thresholds G* = 1 - margin term at k = 0: 32.1, 42.3, 55.4, 59.2% (accountability only 30.7, 38.9, 46.75, "
      "55.3%); ceiling range over the cases' grid 29.6 to 97.9 (high compute 25.8 to 70.8)",
      all(close(100 * FCR[c]['G100'], e) for c, e in zip(CASES, [32.06, 42.26, 55.41, 59.15], ))
      and all(close(100 * FCR[c]['G100_acc'], e) for c, e in zip(CASES, [30.725, 38.91, 46.754, 55.31]))
      and close(100 * min(grid_full), 29.6) and close(100 * max(grid_full), 97.94)
      and close(100 * Rmax_full('high compute', 0.30, 1.5), 25.85) and close(100 * Rmax_full('high compute', 0.30, 0.0), 70.85))
# general form: symbolic reduction and adjustments
tau_s, cc_s, f_s, am_s, cf_s, dK_s, k_s, G_s, X_s, psi_s, ch_s, a_s = sp.symbols(
    "tau c_c f a_min c_full delta_K k G X psi c_h a", real=True)
Rinf_s = (1 - tau_s) * (1 - ch_s - cc_s - f_s - a_s) + (X_s - (1 - psi_s * tau_s) * k_s) * G_s
Rmax_s = (1 - tau_s) * (1 - cc_s - f_s - am_s - cf_s - dK_s * k_s) + (X_s - (1 - psi_s * tau_s) * k_s) * G_s
ok = is_zero(Rinf_s.subs({ch_s: 0, a_s: am_s + cf_s + dK_s * k_s}) - Rmax_s)
ok &= is_zero(sp.diff(Rinf_s, ch_s) + (1 - tau_s)) and is_zero(sp.diff(Rinf_s, a_s) + (1 - tau_s))
ok &= is_zero(Rmax_s.subs({X_s: 1, psi_s: 0, dK_s: 0}) - ((1 - tau_s) * (1 - cc_s - f_s - am_s - cf_s) + (1 - k_s) * G_s))
ok &= is_zero(Rmax_s.subs({psi_s: 1}) - Rmax_s.subs({psi_s: 0}) - tau_s * k_s * G_s)
ok &= is_zero(Rmax_s.subs({dK_s: 0}) - Rmax_s - (1 - tau_s) * dK_s * k_s)
check("20f Cor ceiling: R_inf <= R_max with equality at c_h = 0, a = a_min + c_full + delta_K k; eq. (Rmax) at X=1, "
      "psi=0, delta_K=0; expensing adds tau k G; replacement subtracts (1-tau) delta_K k", ok)
print(f"     replacement at delta_K = 0.25, k = 0.5, central: {100 * 0.82 * 0.25 * 0.5:.2f} points")
check("20g replacement of k = 0.5 at delta_K = 0.25 lowers the central ceiling by (1-tau) delta_K k = 10.25 points",
      abs(Rmax_full('central', 0.15, 0.5) - Rmax_full('central', 0.15, 0.5, dK=0.25) - 0.1025) < 1e-12)
# compute share, tax and a_min sensitivities (assumptions memo items 1-3)
gc = lambda cc: fullcost('central', cc=cc)
sens = {cc: (gc(cc)['G100'], gc(cc)['G100_acc']) for cc in [0.01, 0.55]}
slope = (gc(0.30)['G100'] - gc(0.10)['G100']) / 0.20
print(f"     central G* at c_c = 0.01 / 0.55: {100 * sens[0.01][0]:.2f} / {100 * sens[0.55][0]:.2f}% (acc. only "
      f"{100 * sens[0.01][1]:.2f} / {100 * sens[0.55][1]:.2f}%); slope {slope:.4f}")
check("20h c_c over its scenario bounds [0.01, 0.55]: central G* 26.2 to 71.8% (accountability only 23.3 to 67.6%); "
      "dG*/dc_c = (1 - tau)(1 + s_fin) = 0.8446",
      close(100 * sens[0.01][0], 26.21) and close(100 * sens[0.55][0], 71.82) and close(100 * sens[0.01][1], 23.33)
      and close(100 * sens[0.55][1], 67.61) and abs(slope - 0.82 * 1.03) < 1e-12)
t9 = fullcost('central', tau_=0.09)
am = [fullcost('central', amin_=x) for x in [0.005, 0.046]]
check("20i tau = 9% (GAO-23-105384 average effective rate): central G* 35.9% (accountability only 32.2%); a_min over "
      "its band [0.005, 0.046]: accountability-only central G* 36.9 to 40.2% (full cost 40.2 to 43.6%)",
      close(100 * t9['G100'], 35.92) and close(100 * t9['G100_acc'], 32.2)
      and close(100 * am[0]['G100_acc'], 36.86) and close(100 * am[1]['G100_acc'], 40.22)
      and close(100 * am[0]['G100'], 40.21) and close(100 * am[1]['G100'], 43.57))
cen = FCR['central']
G_of_cerr = lambda ce: 1 - 0.82 * (1 - 0.20 - 0.025 - 0.03 - (cen['c_full'] - cen['c_err'] + ce))
hi_err = 0.30 * (0.18 * 0.55 + 0.20 * 0.80) * 1.0
check("20m c_err across its range: central G* 41.3% at the favorable c_err (0.18 points), 44.3% at the conservative "
      "(3.75), and 47.6% with today's highest measured error rates and losses equal to the unit's cost (7.77 points)",
      close(100 * G_of_cerr(FCR['favorable']['c_err']), 41.35) and close(100 * G_of_cerr(FCR['conservative']['c_err']), 44.28)
      and close(100 * hi_err, 7.77) and close(100 * G_of_cerr(hi_err), 47.57))
# product mix: c_c as a revenue-weighted blend (Prop prod-aggregate(a)); high compute = AI share 1
w_ = 0.5
blend = fullcost('central', cc=(1 - w_) * 0.20 + w_ * 0.40)
check("20j product mix: with AI products at c_c = 0.40 and the rest at 0.20, an AI revenue share of one half puts G* "
      "midway between the central and high-compute thresholds (linear in the share); 1 - 0.59 - 0.025 = 0.385 ~ 0.40",
      abs(blend['G100'] - 0.5 * (FCR['central']['G100'] + FCR['high compute']['G100'])) < 1e-12
      and abs((1 - 0.59 - 0.025) - 0.385) < 1e-12)
# owning the compute (Remark rem:owncompute): saturated cash score own - API = (1-tau) ups TCO - s_srv L_srv TCO G
ok = True
for _ in range(500):
    TCO, ups, G_ = RNG.uniform(0.02, 0.4), RNG.uniform(0, 1.5), RNG.uniform(0, 0.4)
    tau_, ssrv, L = RNG.uniform(0.1, 0.3), RNG.uniform(0.3, 0.8), RNG.uniform(3, 7)
    api = (1 - tau_) * (1 - (1 + ups) * TCO)
    kc = ssrv * L * TCO
    own = (1 - tau_) * (1 - (1 - ssrv) * TCO - (1 / L) * kc) - kc * G_
    ok &= abs((own - api) - ((1 - tau_) * ups * TCO - ssrv * L * TCO * G_)) < 1e-12
thr_own = [3.3 * G_ / 0.82 for G_ in [0.05, 0.15]]
print(f"     owning pays on the cash ceiling iff markup > 3.3 G/(1 - tau): {100 * thr_own[0]:.1f}% at G = 5%, "
      f"{100 * thr_own[1]:.1f}% at G = 15%")
check("20k Remark rem:owncompute: owning raises the cash ceiling iff (1-tau) markup > s_srv L_srv G; thresholds 20.1% "
      "and 60.4% at G = 5% and 15% (s_srv L_srv = 0.6 x 5.5 = 3.3, tau = 0.18)",
      ok and round(100 * thr_own[0], 1) == 20.1 and round(100 * thr_own[1], 1) == 60.4 and abs(0.6 * 5.5 - 3.3) < 1e-12)
import json as _json
import os as _os
_cal = _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), 'notes', 'calibration_results.json')
ok = False
if _os.path.exists(_cal):
    J = _json.load(open(_cal))
    if 'ceiling' in J:
        ok = all(abs(J['ceiling'][c][kk] - FCR[c][kk]) < 1e-12 for c in CASES for kk in ['c_full', 'base', 'G100'])
check("20l code/calibrate_horizons.py uses the same full-cost floors (notes/calibration_results.json, block 'ceiling')", ok)

# ==============================================================================================
header("21. Attainable frontier (Assumption ass:program, Definition def:attainable, Proposition prop:attainable)")
# ==============================================================================================


def single_wave_ok(mask, use, cap):
    idx = [i for i in range(use.shape[0]) if mask >> i & 1]
    return all(use[idx, r].sum() <= cap[r] + 1e-12 for r in range(use.shape[1]))


def min_waves(Nn, use, cap):
    """mw[Z] = least number of capacity-feasible waves that partition Z (inf if some process fits no wave)."""
    full = 1 << Nn
    feas = [single_wave_ok(m, use, cap) for m in range(full)]
    mw = [math.inf] * full
    mw[0] = 0
    for Z in range(1, full):
        low = Z & -Z
        S_ = Z
        best = math.inf
        while S_:
            if (S_ & low) and feas[S_]:
                best = min(best, 1 + mw[Z ^ S_])
            S_ = (S_ - 1) & Z
        mw[Z] = best
    return mw


def theta_Z(Z, th0, dth):
    th = th0.copy()
    for i in range(dth.shape[0]):
        if Z >> i & 1:
            th = th + dth[i]
    return th


def Rstar_theta(th, X_, a_, hh):
    m0_, k_, lnlam, G_ = th
    return closed_form(m0_, G_, k_, X_, math.exp(lnlam) * hh, a_)[2]


def n_waves(t, Temb, T):
    return 0 if t < Temb else math.floor((t - Temb) / T + 1e-12) + 1


bad = dict(mono_t=0, mono_cap=0, mono_use=0, base=0, conv=0, conv1=0, speed=0, ident=0, knap=0, union=0)
for trial in range(150):
    Nn, nr = 6, 3
    use = RNG.uniform(0, 1, size=(Nn, nr))
    cap = RNG.uniform(0.8, 2.5, size=nr)
    th0 = np.array([RNG.uniform(0.1, 0.5), RNG.uniform(0, 0.6), math.log(RNG.uniform(0.2, 1.2)), RNG.uniform(0, 0.2)])
    dth = np.column_stack([RNG.uniform(-0.02, 0.05, Nn), RNG.uniform(-0.05, 0.1, Nn), RNG.uniform(-0.1, 0.2, Nn),
                           RNG.uniform(-0.01, 0.02, Nn)])
    X_, a_, hh = RNG.uniform(0.5, 3), RNG.uniform(0.25, 0.45), RNG.uniform(0.3, 1.0)
    T, Temb = 0.5, RNG.uniform(0.5, 2.0)
    mw = min_waves(Nn, use, cap)
    full = 1 << Nn
    RZ = [Rstar_theta(theta_Z(Z, th0, dth), X_, a_, hh) for Z in range(full)]
    Ratt = lambda n, mw_=mw: max(RZ[Z] for Z in range(full) if mw_[Z] <= n)
    seq = [Ratt(n_waves(t, Temb, T)) for t in np.linspace(0, 6, 25)]
    bad['mono_t'] += any(seq[i + 1] < seq[i] - 1e-14 for i in range(len(seq) - 1))
    bad['base'] += abs(Ratt(n_waves(0.99 * Temb, Temb, T)) - RZ[0]) > 1e-14
    mw_big = min_waves(Nn, use, cap * 1.5)
    mw_small_use = min_waves(Nn, use * 0.7, cap)
    for n in range(0, 5):
        bad['mono_cap'] += Ratt(n, mw_big) < Ratt(n) - 1e-14 or any(mw_big[Z] > mw[Z] for Z in range(full))
        bad['mono_use'] += Ratt(n, mw_small_use) < Ratt(n) - 1e-14
    nbar = mw[full - 1]
    if nbar < math.inf:
        bad['conv'] += any(mw[Z] > nbar for Z in range(full)) or abs(Ratt(nbar) - max(RZ)) > 1e-14
        bad['conv'] += (all(use[i, r] <= cap[r] for i in range(Nn) for r in range(nr)) and nbar > Nn)
    cap_tot = use.sum(axis=0) + 1e-9
    mw_tot = min_waves(Nn, use, cap_tot)
    bad['conv1'] += mw_tot[full - 1] != 1 or abs(Ratt(n_waves(Temb, Temb, T), mw_tot) - max(RZ)) > 1e-14
    for n in range(1, 5):
        for Z in range(full):
            if mw[Z] <= n:
                idx = [i for i in range(Nn) if Z >> i & 1]
                bad['speed'] += any(use[idx, r].sum() > n * cap[r] + 1e-12 for r in range(nr))
    # identical uses: at most n * n_cap processes
    cu = RNG.uniform(0.2, 1.0, size=nr)
    use_id = np.tile(cu, (Nn, 1))
    mw_id = min_waves(Nn, use_id, cap)
    ncap = min(math.floor(cap[r] / cu[r] + 1e-12) for r in range(nr))
    for n in range(1, 5):
        bad['ident'] += any(bin(Z).count('1') > n * ncap for Z in range(full) if mw_id[Z] <= n)
        if ncap >= 1:
            bad['ident'] += any(mw_id[Z] > n for Z in range(full) if bin(Z).count('1') <= n * ncap)
    # (d) score-additive increments: R*(theta_Z) = R*(theta_0) + sum dR_p, bounded by the fractional knapsack
    dthA = dth.copy()
    dthA[:, 1] = 0.0
    dthA[:, 2] = 0.0
    XA = max(X_, th0[1] + 0.1)
    RA = [Rstar_theta(theta_Z(Z, th0, dthA), XA, a_, hh) for Z in range(full)]
    dR = dthA[:, 0] + (XA - th0[1]) * dthA[:, 3]
    bad['knap'] += any(abs(RA[Z] - RA[0] - sum(dR[i] for i in range(Nn) if Z >> i & 1)) > 1e-12 for Z in range(full))
    for n in range(1, 4):
        att = max(RA[Z] for Z in range(full) if mw[Z] <= n) - RA[0]
        for r in range(nr):
            order = sorted([i for i in range(Nn) if dR[i] > 0], key=lambda i: -dR[i] / max(use[i, r], 1e-15))
            Cc, val = n * cap[r], 0.0
            for i in order:
                take = min(1.0, Cc / use[i, r]) if use[i, r] > 0 else 1.0
                val += take * dR[i]
                Cc -= take * use[i, r]
                if Cc <= 1e-15:
                    break
            bad['knap'] += att > val + 1e-12
    # sup of R_X over the union of feasible sets equals the max over Z of R*(theta_Z): grid check on one instance
    if trial < 20:
        n = 2
        gs = np.linspace(0, 1.5, 3001)
        best_union = -math.inf
        for Z in range(full):
            if mw[Z] <= n:
                m0_, k_, lnlam, G_ = theta_Z(Z, th0, dth)
                kap_ = (math.exp(lnlam) * hh) ** (-1 / a_)
                gg = G_ + gs
                best_union = max(best_union, float(np.max(X_ * gg + m0_ - k_ * gg - kap_ * gs ** (1 / a_))))
        bad['union'] += best_union > Ratt(n) + 1e-12 or best_union < Ratt(n) - 2e-4
check("21a (a) A_t and R^att_X(t) nondecreasing in t (150 random programs, 6 processes, 3 resources)", bad['mono_t'] == 0,
      f"violations={bad['mono_t']}")
check("21b (a) nondecreasing in capacities and nonincreasing in uses; R^att = R*(theta_0) for t < T_emb",
      bad['mono_cap'] == 0 and bad['mono_use'] == 0 and bad['base'] == 0,
      f"violations={bad['mono_cap'] + bad['mono_use'] + bad['base']}")
check("21c (a) sup of R_X over the union of feasible sets = max over packable Z of R*(theta_Z) (grid, 20 programs)",
      bad['union'] == 0, f"violations={bad['union']}")
check("21d (b) A_t = A_inf once n(t) >= nbar; nbar <= N if each process fits a wave; capacities >= total use give "
      "nbar = 1 and A_t = A_inf at T_emb", bad['conv'] == 0 and bad['conv1'] == 0,
      f"violations={bad['conv'] + bad['conv1']}")
check("21e (c) every packable Z uses at most n(t) Gamma_i of each resource; identical uses: |Z| <= n n_cap and every "
      "set of at most n n_cap processes is packable", bad['speed'] == 0 and bad['ident'] == 0,
      f"violations={bad['speed'] + bad['ident']}")
check("21f (d) m0 and G increments: R* additive (Delta R_p = dm0 + (X-k) dG); R^att - R*(theta_0) <= fractional "
      "knapsack value V(n Gamma_i) for every resource", bad['knap'] == 0, f"violations={bad['knap']}")
# concavity of the knapsack value function in capacity
bad_c = 0
for _ in range(300):
    vals_ = RNG.uniform(0, 1, 8)
    cs = RNG.uniform(0.05, 1, 8)
    order = np.argsort(-vals_ / cs)

    def Vk(C):
        out_, rem = 0.0, C
        for i in order:
            take = min(1.0, rem / cs[i])
            out_ += take * vals_[i]
            rem -= take * cs[i]
            if rem <= 0:
                break
        return out_
    grid = np.linspace(0, cs.sum() * 1.2, 400)
    vv = np.array([Vk(C) for C in grid])
    bad_c += np.any(np.diff(vv, 2) > 1e-12) or np.any(np.diff(vv) < -1e-12)
check("21g (d) the fractional knapsack value V(C) is nondecreasing, concave and piecewise linear in capacity",
      bad_c == 0, f"violations={bad_c}")
# X-improving: directional derivative of R* along a process increment
bad = 0
for _ in range(300):
    th = np.array([RNG.uniform(0.1, 0.5), RNG.uniform(0, 0.8), math.log(RNG.uniform(0.2, 1.2)), RNG.uniform(0, 0.2)])
    dv = RNG.uniform(-0.05, 0.05, 4)
    X_, a_, hh = RNG.uniform(0.5, 3), RNG.uniform(0.25, 0.45), RNG.uniform(0.3, 1)
    D_ = closed_form(th[0], th[3], th[1], X_, math.exp(th[2]) * hh, a_)[0]
    gst = th[3] + D_
    yv = X_ - th[1]
    pred = dv[0] - gst * dv[1] + (yv * (D_ * dv[2] + dv[3]) if yv > 0 else yv * dv[3])
    eps = 1e-6
    fd = (Rstar_theta(th + eps * dv, X_, a_, hh) - Rstar_theta(th - eps * dv, X_, a_, hh)) / (2 * eps)
    bad += abs(fd - pred) > 1e-6
check("21h Definition attainable(c): grad R*_X . dtheta = dm0 - g* dk + (X-k)(Delta* d ln lambda + dG) (finite differences)",
      bad == 0, f"violations={bad}")

# ==============================================================================================
header("22. Expected frontier (Proposition prop:expected, Lemma lem:expected-frontier)")
# ==============================================================================================


def simulate_program(Nn, ncap, nwaves, varpi, pdis, plan='greedy', revert_low=False, rng=None, bdist=None):
    """Identical processes; returns list of embedded b's after nwaves waves (all waves embedded by t).
    Each attempt embeds with prob varpi*(1-pdis); plan 'greedy' fills each wave with available processes,
    'random' attempts a random number up to ncap; revert_low reverts embedded processes with b < 0.5 (allowed)."""
    status = np.zeros(Nn)          # 0 available, 1 embedded
    bvals = np.zeros(Nn)
    attempts = 0
    for w in range(nwaves):
        avail = np.where(status == 0)[0]
        k_ = len(avail) if plan == 'greedy' else rng.integers(0, len(avail) + 1)
        k_ = min(k_, ncap)
        chosen = rng.choice(avail, size=k_, replace=False) if k_ > 0 else []
        for i in chosen:
            attempts += 1
            if rng.random() < varpi and rng.random() >= pdis:
                status[i] = 1
                bvals[i] = bdist(rng)
        if revert_low:
            low = np.where((status == 1) & (bvals < 0.5))[0]
            status[low] = 0
    return bvals[status == 1], attempts


rng2 = np.random.default_rng(7)
bdist = lambda r: r.beta(4, 1)            # mean 0.8
bbar_ = 0.8
ok = True
for (Nn, ncap, nwv, varpi, pdis) in [(200, 5, 10, 0.54, 0.37), (200, 8, 12, 0.8, 0.07), (40, 4, 15, 0.6, 0.2)]:
    q_ = varpi * (1 - pdis)
    R = 4000
    emb_g = np.array([len(simulate_program(Nn, ncap, nwv, varpi, pdis, 'greedy', rng=rng2, bdist=bdist)[0]) for _ in range(R)])
    sumb_rl = np.array([simulate_program(Nn, ncap, nwv, varpi, pdis, 'greedy', True, rng=rng2, bdist=bdist)[0].sum()
                        for _ in range(R)])
    emb_r = np.array([len(simulate_program(Nn, ncap, nwv, varpi, pdis, 'random', rng=rng2, bdist=bdist)[0]) for _ in range(R)])
    bound = min(Nn, q_ * ncap * nwv)
    se = lambda x: x.std() / math.sqrt(len(x))
    if Nn >= ncap * nwv:
        ok &= abs(emb_g.mean() - q_ * ncap * nwv) < 4 * se(emb_g) + 1e-9
    ok &= emb_g.mean() <= bound + 4 * se(emb_g) and emb_r.mean() <= bound + 4 * se(emb_r)
    ok &= sumb_rl.mean() <= min(Nn, bbar_ * q_ * ncap * nwv) + 4 * se(sumb_rl)
    print(f"     N={Nn}, n_cap={ncap}, waves={nwv}, q={q_:.3f}: greedy E[#embedded]={emb_g.mean():.2f} "
          f"(q n_cap n = {q_ * ncap * nwv:.2f}), random plan {emb_r.mean():.2f}, E[sum b] with selective reversion "
          f"{sumb_rl.mean():.2f} <= b q n_cap n = {bbar_ * q_ * ncap * nwv:.2f}")
check("22a (c) E[#embedded] <= min{N, q n_cap n(t_R)}, with equality for the greedy plan when N >= n_cap n; "
      "E[sum b] <= min{N, bbar q n_cap n} even with selective reversion (Monte Carlo, 4 sigma)", ok)
# garbling: a high-varpi world that abandons successes with prob varpi/varpi' reproduces the low-varpi law
ok = True
R = 20000
lo = np.array([len(simulate_program(30, 4, 6, 0.5, 0.2, 'greedy', rng=rng2, bdist=bdist)[0]) for _ in range(R)])


def simulate_garbled(Nn, ncap, nwv, v_hi, v_lo, pdis, rng):
    status = np.zeros(Nn)
    for w in range(nwv):
        avail = np.where(status == 0)[0][:ncap]
        for i in avail:
            if rng.random() < v_hi and rng.random() < v_lo / v_hi and rng.random() >= pdis:
                status[i] = 1
    return int(status.sum())


hi_g = np.array([simulate_garbled(30, 4, 6, 0.8, 0.5, 0.2, rng2) for _ in range(R)])
hi = np.array([len(simulate_program(30, 4, 6, 0.8, 0.2, 'greedy', rng=rng2, bdist=bdist)[0]) for _ in range(R)])
ok &= abs(lo.mean() - hi_g.mean()) < 4 * math.sqrt(lo.var() / R + hi_g.var() / R)
ok &= abs(lo.var() - hi_g.var()) < 0.08 * lo.var() and hi.mean() > lo.mean()
check("22b (b) garbling: abandoning successes with probability varpi/varpi' reproduces the low-success law "
      "(mean and variance); higher varpi raises the expected embedded count", ok,
      f"lo {lo.mean():.3f}, garbled {hi_g.mean():.3f}, hi {hi.mean():.3f}")
# disruption hazard: superposed Poisson thinning reproduces the higher hazard
ok = True
nuD1, nuD2, Te = 0.2, 0.5, 2.0
U = rng2.exponential(1 / nuD1, 200000)
extra = rng2.exponential(1 / (nuD2 - nuD1), 200000)
ok &= abs(np.mean(np.minimum(U, extra) > Te) - math.exp(-nuD2 * Te)) < 0.005
ok &= math.exp(-nuD2 * Te) < math.exp(-nuD1 * Te)
check("22c (b) disruption: superposing an independent rate nu' - nu on rate nu gives survival exp(-nu' T_emb); "
      "q = varpi exp(-nu_D T_emb) falls with nu_D = nu_L(1 - kappa_keep) + nu_V", ok)
# (d) long run: retry plan embeds everything; mean of sum b -> N bbar
ok = True
emb_long = np.array([simulate_program(30, 4, 200, 0.5, 0.3, 'greedy', rng=rng2, bdist=bdist)[0] for _ in range(3000)],
                    dtype=object)
cnt = np.array([len(x) for x in emb_long])
sb = np.array([x.sum() for x in emb_long])
ok &= cnt.min() == 30 and abs(sb.mean() - 30 * bbar_) < 4 * sb.std() / math.sqrt(len(sb))
check("22d (d) with retries every process is embedded (200 waves); E[sum b] -> N bbar, shortfall (1 - bbar) N Delta R",
      ok, f"min embedded {cnt.min()}, mean sum b {sb.mean():.3f} vs {30 * bbar_:.1f}")
# (a) bound under X-improving increments with partial realization
bad = 0
for _ in range(200):
    Nn = 5
    use = RNG.uniform(0, 1, size=(Nn, 2))
    cap = RNG.uniform(0.8, 2.0, size=2)
    th0 = np.array([RNG.uniform(0.1, 0.5), RNG.uniform(0.2, 0.6), math.log(RNG.uniform(0.2, 1.2)), RNG.uniform(0, 0.2)])
    X_, a_, hh = RNG.uniform(1.0, 3), RNG.uniform(0.25, 0.45), RNG.uniform(0.3, 1)
    dth = np.column_stack([RNG.uniform(0, 0.05, Nn), RNG.uniform(-0.05, 0, Nn), RNG.uniform(0, 0.2, Nn), RNG.uniform(0, 0.02, Nn)])
    mw = min_waves(Nn, use, cap)
    full = 1 << Nn
    n = 2
    Ratt = max(Rstar_theta(theta_Z(Z, th0, dth), X_, a_, hh) for Z in range(full) if mw[Z] <= n)
    for _ in range(20):
        Z = int(RNG.integers(0, full))
        if mw[Z] > n:
            continue
        bvec = RNG.uniform(0, 1, Nn)
        th = th0 + sum(bvec[i] * dth[i] for i in range(Nn) if Z >> i & 1) if Z else th0
        bad += Rstar_theta(th, X_, a_, hh) > Ratt + 1e-12
check("22e (a) with X-improving increments, any packable realized set with partial shares b <= 1 scores at most "
      "R^att_X (200 programs)", bad == 0, f"violations={bad}")
# Lemma lem:expected-frontier
ok = True
for _ in range(200):
    a_, hh, G_ = RNG.uniform(0.25, 0.45), RNG.uniform(0.3, 1), RNG.uniform(0, 0.2)
    lam_ = RNG.uniform(0.2, 1.2)
    kap_ = (lam_ * hh) ** (-1 / a_)
    m0s = RNG.uniform(0.1, 0.6, 50)
    ks = RNG.uniform(0, 1, 50)
    gg = np.linspace(G_, G_ + 1.0, 201)
    frontiers = np.array([m0_ - k_ * gg - kap_ * (gg - G_) ** (1 / a_) for m0_, k_ in zip(m0s, ks)])
    mbar = frontiers.mean(axis=0)
    ok &= np.max(np.abs(mbar - (m0s.mean() - ks.mean() * gg - kap_ * (gg - G_) ** (1 / a_)))) < 1e-12 * (1 + np.abs(frontiers).max())
    ok &= np.all(np.diff(mbar, 2) <= 1e-9 * (1 + np.abs(mbar).max()))
    X_ = RNG.uniform(0, 3)
    ER = np.mean([closed_form(m0_, G_, k_, X_, lam_ * hh, a_)[2] for m0_, k_ in zip(m0s, ks)])
    ok &= ER >= np.max(X_ * gg + mbar) - 1e-9 * (1 + abs(ER))
check("22f Lemma expected-frontier: mbar_t concave; with m0 and k increments it equals the frontier at E theta_t; "
      "E R*_X >= sup_g [X g + mbar_t(g)] (Jensen)", ok)
# illustrative pace numbers quoted in Section horizons (central and fast execution)
q_c = 0.54 * math.exp(-(0.204 * 0.4 + 0.15) * 2.0)
q_f = 0.80 * math.exp(-(0.15 * 0.15 + 0.05) * 1.0)
rate_c, rate_f = q_c * 0.10 / (1 + 0.46 * 0.25), q_f * 0.20 / (1 + 0.30 * 0.08)
tbe = (2.0 + 2.0 / (0.85 * q_c)) * (1 + 0.46 * 0.25)
print(f"     central q = {q_c:.4f}, effective rate {rate_c:.4f}/yr; fast q = {q_f:.4f}, rate {rate_f:.4f}/yr; "
      f"central break-even of embedded gains and in-flight dip at {tbe:.2f} years")
check("22g pace numbers: q = 0.34 (central) and 0.74 (fast); effective rates 3.0% and 14.5% of the program a year; "
      "central gains first exceed the dip after about ten years (9.95)",
      round(q_c, 2) == 0.34 and round(q_f, 2) == 0.74 and round(100 * rate_c, 1) == 3.0 and round(100 * rate_f, 1) == 14.5
      and abs(tbe - 9.95) < 0.01)

# ==============================================================================================
header("23. Beyond software: economic profit, ROIC and value (Proposition prop:general)")
# ==============================================================================================
g_s, m_s, r_s, kk_s, XX_s = sp.symbols("g m r k X", real=True)
e_s = m_s + kk_s * (g_s - r_s)
ok = is_zero(XX_s * g_s + m_s - ((XX_s - kk_s) * g_s + e_s + r_s * kk_s))
ROIC = (m_s + kk_s * g_s) / kk_s
ok &= is_zero(XX_s * g_s + m_s - kk_s * (ROIC + (XX_s / kk_s - 1) * g_s))
VS = m_s / (r_s - g_s)
ok &= is_zero(VS - (kk_s + e_s / (r_s - g_s)))
ok &= is_zero(VS / kk_s - (ROIC - g_s) / (r_s - g_s)) and is_zero((ROIC - g_s) / (r_s - g_s) - (1 + (ROIC - r_s) / (r_s - g_s)))
ok &= is_zero(m_s / VS + g_s - r_s)
check("23a identities: R_X = (X-k)g + e + rk = k[ROIC + (X/k - 1)g]; V/S = k + e/(r-g); V/IC = (ROIC-g)/(r-g) "
      "= 1 + (ROIC-r)/(r-g); FCF yield + g = r", ok)
# frontier in (g, e): slope 0 at G, concave, strictly decreasing for g > G; shear preserves dominance
ok = True
for _ in range(300):
    m0_, k_, G_, a_, ell, r_ = RNG.uniform(0.1, 0.6), RNG.uniform(0, 2), RNG.uniform(0, 0.2), RNG.uniform(0.25, 0.45), RNG.uniform(0.2, 1.5), RNG.uniform(0.05, 0.15)
    kap_ = ell ** (-1 / a_)
    gg = np.linspace(G_, G_ + 0.8, 4001)
    estar = m0_ - r_ * k_ - kap_ * (gg - G_) ** (1 / a_)
    ok &= abs((estar[1] - estar[0]) / (gg[1] - gg[0])) < 1e-3 and np.all(np.diff(estar) <= 0) and np.all(np.diff(estar, 2) <= 1e-12)
    mstar = m0_ - k_ * gg - kap_ * (gg - G_) ** (1 / a_)
    ok &= np.max(np.abs(estar - (mstar + k_ * (gg - r_)))) < 1e-12
check("23b (a) e*(g) = m0 - rk - kappa (g-G)^beta = m*(g) + k(g - r): slope 0 at G, decreasing and concave", ok)
# (c) tangency at the small-share point of Prop dynamic(d) with k > 0
ok = True
nt = 0
for _ in range(200):
    a_, G_, r_ = RNG.uniform(0.25, 0.45), RNG.uniform(0.0, 0.05), RNG.uniform(0.08, 0.14)
    k_, m0_, lam_ = RNG.uniform(0.05, 0.8), RNG.uniform(0.2, 0.5), RNG.uniform(0.02, 0.15)
    v0, f_ = smallest_root(m0_, k_, G_, r_, lam_, a_, qmax=200.0)
    if v0 is None or v0 <= k_:
        continue
    D0, s0_, _ = closed_form(m0_, G_, k_, v0, lam_, a_)
    g0 = G_ + D0
    if g0 >= r_:
        continue
    nt += 1
    kap_ = lam_ ** (-1 / a_)
    e_at = m0_ - r_ * k_ - kap_ * D0 ** (1 / a_)
    de = -(1 / a_) * kap_ * D0 ** (1 / a_ - 1)
    ok &= abs(-de - (v0 - k_)) < 1e-8 and abs(e_at - (v0 - k_) * (r_ - g0)) < 1e-8
check("23c (c) at the small-share point (g0, m0) of Prop dynamic(d), -e*'(g0) = v0 - k and e*(g0) = (v0 - k)(r - g0): "
      "the iso-value line through (r, 0) is tangent to the economic-margin frontier", ok and nt > 50, f"cases={nt}")
# (d) Rule of 40 bias example
r_, g_, k1, k2 = 0.10, 0.15, 0.0, 1.5
e_ = 0.20
R1 = lambda k_, g__: (1 - k_) * g__ + e_ + r_ * k_
check("23d (d) same g = 15% and economic margin: k = 1.5 changes R_1 by (r - g) dk = -7.5 points; at k = 1.5 a point "
      "of growth lowers R_1 by half a point", abs(R1(k2, g_) - R1(k1, g_) + 0.075) < 1e-12
      and abs(R1(k2, g_ + 0.01) - R1(k2, g_) + 0.005) < 1e-12)

# ==============================================================================================
header("24. Ownership regimes (Remark rem:regimes)")
# ==============================================================================================
bad = 0
for _ in range(500):
    pts = RNG.uniform(0, 1, size=(30, 2))
    X1, X2 = sorted(RNG.uniform(0, 3, 2))
    i1 = np.argmax(X1 * pts[:, 0] + pts[:, 1])
    i2 = np.argmax(X2 * pts[:, 0] + pts[:, 1])
    bad += pts[i2, 0] < pts[i1, 0] - 1e-15
    if pts[i2, 0] > pts[i1, 0] and X1 > 0:
        bad += pts[i2, 1] >= pts[i1, 1]
check("24a (i) on any common attainable set, a higher weight picks a point with weakly more growth, and less margin "
      "when growth is strictly higher (500 random finite sets)", bad == 0, f"violations={bad}")
bad = 0
for _ in range(100):
    use = RNG.uniform(0, 1, size=(6, 2))
    cap = RNG.uniform(0.8, 2.0, size=2)
    mw = min_waves(6, use, cap)
    sub = int(RNG.integers(0, 64))
    for n in range(4):
        bad += any(mw[Z] > n for Z in range(64) if (Z & ~sub) == 0 and mw[Z] <= n and False)
        famP = {Z for Z in range(64) if mw[Z] <= n}
        famS = {Z for Z in range(64) if mw[Z] <= n and (Z & ~sub) == 0}
        bad += not famS.issubset(famP)
check("24b (ii) a program P' subset of P has a packable family contained in that of P, so A'_t is contained in A_t",
      bad == 0, f"violations={bad}")

# ==============================================================================================
header("25. Tax deductions for capital and the accountability floor (Remark rem:taxes, Corollary cor:ceiling; "
       "Part II prop:acct-tax, prop:acct-amin)")
# ==============================================================================================
def psi_T(T, r=0.10):
    return (1 + (1 + r) ** (-T)) / (2 * T) + (1 - (1 + r) ** (-(T - 1))) / (r * T)


# brute-force PV of the statutory schedule: 1/(2T) in year 1, 1/T in years 2..T, 1/(2T) in year T+1, discounted at
# the end of each year after the first (deduction in year 1 undiscounted), as in prop:acct-tax(a)
def psi_sched(T, r=0.10):
    sched = [1 / (2 * T)] + [1 / T] * (T - 1) + [1 / (2 * T)]
    return sum(x * (1 + r) ** (-i) for i, x in enumerate(sched))


ok = all(abs(psi_T(T) - psi_sched(T)) < 1e-12 for T in [2, 5, 10, 15, 30])
check("25a psi_T closed form = PV of the midpoint schedule; psi_5 = 0.796 (2022-2024 domestic), psi_15 = 0.532 "
      "(foreign, 26 U.S.C. 174); domestic development and 100%-allowance equipment have psi = 1",
      ok and round(psi_T(5), 3) == 0.796 and round(psi_T(15), 3) == 0.532, f"psi5={psi_T(5):.4f} psi15={psi_T(15):.4f}")
loss = {nm: [(1 - ps * t) * 1.5 * 0.30 for t in (0.15, 0.18, 0.21)] for nm, ps in
        [('none', 0.0), ('foreign', psi_T(15)), ('domestic', 1.0)]}
check("25b capital term of R_max at k = 1.5, G = 0.30: 45 points with psi = 0, 36 to 38 with psi = 1, 40 to 41 with "
      "psi_15 (tau 15 to 21%)",
      all(abs(100 * x - 45) < 1e-9 for x in loss['none'])
      and [int(np.floor(100 * x + 0.5)) for x in (min(loss['domestic']), max(loss['domestic']))] == [36, 38]
      and [int(np.floor(100 * x + 0.5)) for x in (min(loss['foreign']), max(loss['foreign']))] == [40, 41])
ok = False
if _os.path.exists(_cal):
    J = _json.load(open(_cal))
    if 'psi_sensitivity' in J and 'upper_bound' in J:
        P_ = J['psi_sensitivity']
        ok = all(abs(P_['k05_upper_bound']['none'][h][i] - J['upper_bound'][h]['0.5']['R'][i]) < 1e-12
                 for h in ['2028', '2031', '2036'] for i in (0, 1))
        ok &= all(P_['k05_upper_bound']['domestic'][h][1] >= P_['k05_upper_bound']['none'][h][1] for h in ['2028', '2031', '2036'])
        ok &= all(P_['anchor_m0_ub']['domestic'][i] <= P_['anchor_m0_ub']['none'][i] for i in range(3))
        ok &= abs(P_['psi']['foreign_15y'] - psi_T(15)) < 1e-12
check("25c calibration: psi = 0 reproduces the k = 0.5 column of tab:calib; deductions raise it and lower the anchor "
      "intercepts (notes/calibration_results.json, block 'psi_sensitivity')", ok)


# prop:acct-amin, illustrative example of sec:acct-amin: $1B revenue, 24 opportunities for a $10M misstatement
def amin_design(nh, na, N=24, L=10e6, ph=0.05, ch=5e5, pch=0.002, pa=0.02, ca=5e4, pca=0.005, itgc=3.5e5):
    P = 1.0
    if nh:
        P *= pch + (1 - pch) * ph ** nh
    if na:
        P *= pca + (1 - pca) * pa ** na
    return (itgc if na else 0.0) + nh * ch + na * ca + N * L * P


best_h = min(amin_design(n, 0) for n in range(7))
best_a = min(amin_design(0, n) for n in range(1, 7))
best = min(amin_design(i, j) for i in range(7) for j in range(7))
best_2N = min(amin_design(i, j, N=48) for i in range(7) for j in range(7))
best_cm = min(amin_design(i, j, pca=0.01) for i in range(7) for j in range(7))
direct = 343 / 1e6 + 1.04e6 / 1e9                     # audit fees per $ of revenue + SOX 404 median at $1B (register)
cm_floor = 24 / 1e9 * 10e6 * 0.005                     # o L_mm p_cm per $ of revenue, prop:acct-amin(e)
check("25d prop:acct-amin example: best human, all-AI and mixed designs cost 0.20, 0.17 and 0.10% of revenue; with "
      "twice the opportunities or a 1% common-mode rate the best design stays near 0.11%; plus direct audit and 404 "
      "costs (0.14%) the floor stays below the 0.5% lower end of the a_min band",
      round(best_h / 1e9 * 100, 2) == 0.20 and round(best_a / 1e9 * 100, 2) == 0.17 and round(best / 1e9 * 100, 2) == 0.10
      and max(best_2N, best_cm) / 1e9 < 0.0012 and round(100 * direct, 2) == 0.14
      and direct + max(best, best_2N, best_cm) / 1e9 < 0.005,
      f"human={best_h:.0f} ai={best_a:.0f} mixed={best:.0f} 2N={best_2N:.0f} cm1%={best_cm:.0f} direct={100 * direct:.3f}%")
check("25e common-mode misstatement floor at scale o L_mm p_cm = 0.12% of revenue for an all-AI design on one provider "
      "(does not fall with scale; counted in a_min, not in c_err)", abs(100 * cm_floor - 0.12) < 1e-12)


# ==============================================================================================
header("26. Paper 1 self-contained results: Lemma lem:fullcost and Proposition prop:amin")
# ==============================================================================================
import json as _json26
import os as _os26
from scipy import integrate as _integ26

_cal26 = _json26.load(open(_os26.path.join(_os26.path.dirname(_os26.path.dirname(_os26.path.abspath(__file__))),
                                           'notes', 'calibration_results.json')))
# (a) maintenance: payments C at T, 2T, ... have PV C/(e^{rT}-1), the PV of the flow rC/(e^{rT}-1)
ok = True
for _ in range(200):
    r_, T_, C_ = RNG.uniform(0.01, 0.3), RNG.uniform(0.5, 3.0), RNG.uniform(0.1, 5.0)
    pv_pay = sum(C_ * math.exp(-r_ * T_ * j) for j in range(1, 4000))
    pv_flow = (r_ * C_ / (math.exp(r_ * T_) - 1)) / r_
    ok &= abs(pv_pay - pv_flow) < 1e-8 * max(1.0, pv_flow)
mnt_ok = all(abs(_cal26['ceiling'][c]['c_mnt'] - v) < 1e-12 for c, v in
             [('favorable', (0.10 + 0.05 / 1.75) * 0.012), ('central', (0.17 + 0.10 / 1.22) * 0.024),
              ('conservative', (0.40 + 0.20 / 0.99) * 0.048)])
check("26a lem:fullcost(a) revalidation every T_up years has annual equivalent r/(e^{rT_up}-1) under discounting "
      "(200 draws), and c_mnt = (delta_M + rho_rv/T_up) c_bld reproduces Table tab:fullcost", ok and mnt_ok)

# (b) security: closed form of min_c {c + exp(-c/c_eff) c_inc}, residual c_eff, Gordon-Loeb bound c* <= c_inc/e
ok = True
for _ in range(300):
    ce, ci = RNG.uniform(0.001, 1.0), RNG.uniform(0.0005, 5.0)
    res = minimize_scalar(lambda c: c + math.exp(-c / ce) * ci, bounds=(0, 50), method='bounded',
                          options={'xatol': 1e-12})
    closed = ci if ci <= ce else ce * (1 + math.log(ci / ce))
    cstar = ce * max(math.log(ci / ce), 0.0)
    ok &= abs(res.fun - closed) < 1e-7 and cstar <= ci / math.e + 1e-15
    if ci > ce:
        ok &= abs(math.exp(-cstar / ce) * ci - ce) < 1e-12
check("26b lem:fullcost(b) risk cost = c_inc if c_inc <= c_eff, else c_eff[1 + ln(c_inc/c_eff)]; optimal spend "
      "c_eff ln(c_inc/c_eff)^+ <= c_inc/e and leaves residual c_eff (300 draws, numerical minimization)", ok)

# (b) calibration identity: today's optimal spend s0 = c_eff L, exposure x xi -> risk = (s0/L)(1 + L + ln xi)
ok = True
for _ in range(200):
    s0, L, xi = RNG.uniform(0.001, 0.02), RNG.uniform(0.2, 5.0), RNG.uniform(1.0, 5.0)
    ce = s0 / L
    ci0 = ce * math.exp(L)
    ok &= abs(ce * math.log(ci0 / ce) - s0) < 1e-12
    ok &= abs(ce * (1 + math.log(xi * ci0 / ce)) - (s0 / L) * (1 + L + math.log(xi))) < 1e-12
risk_ok = all(abs(_cal26['ceiling'][c]['risk'] - 0.0069 / L * (1 + L + math.log(M))) < 1e-12
              for c, L, M in [('favorable', 4.0, 1.0), ('central', 2.0, 2.0), ('conservative', 1.0, 3.0)])
check("26c lem:fullcost(b) calibration identity c_risk = (c_sp0/L_sec)(1 + L_sec + ln xi_exp), and it reproduces the "
      "risk costs 0.86, 1.27 and 2.14 points of Table tab:fullcost", ok and risk_ok,
      f"{[round(100 * _cal26['ceiling'][c]['risk'], 2) for c in ['favorable', 'central', 'conservative']]}")

# (c) review-proof bound: any reviewed subset gives expected undetected errors >= n u_bar, equality if all reviewed
ok = True
for _ in range(300):
    n_ = int(RNG.integers(5, 60))
    eo, eh = RNG.uniform(0, 0.1, n_), RNG.uniform(0, 0.1, n_)
    do_, dh_ = RNG.uniform(0, 1), RNG.uniform(0, 1)
    rev = RNG.random(n_) < RNG.uniform(0, 1)
    und = np.where(rev, eo * (1 - do_) + eh * (1 - dh_), eo + eh).sum()
    floor_ = (eo * (1 - do_) + eh * (1 - dh_)).sum()
    ok &= und >= floor_ - 1e-15
ub_c = 0.0345 * 0.35 + 0.05 * 0.60
ok &= abs(_cal26['ceiling']['central']['c_err_e'] - 0.30 * ub_c * 0.5) < 1e-12
check("26d lem:fullcost(c) whatever units are reviewed, expected undetected errors >= review-proof rate u_bar per "
      "unit (300 draws); W_A u_bar L_err reproduces the central errors-and-hallucination term (0.63 points)", ok)

# (d) capped Pareto: E min{Y, Ybar} = 1 + (1 - Ybar^{1-p})/(p-1), 1 + ln Ybar at p = 1, p/(p-1) uncapped
ok = True
for p_ in list(RNG.uniform(0.3, 3.0, 60)) + [1.0]:
    Yb = float(RNG.uniform(1.5, 300.0))
    num_ = 1 + _integ26.quad(lambda y: y ** (-p_), 1, Yb)[0]
    closed = 1 + math.log(Yb) if abs(p_ - 1) < 1e-12 else 1 + (1 - Yb ** (1 - p_)) / (p_ - 1)
    ok &= abs(num_ - closed) < 1e-8 * closed
for p_ in [1.15, 1.5, 2.3]:
    ok &= abs((1 + (1 - 1e80 ** (1 - p_)) / (p_ - 1)) - p_ / (p_ - 1)) < 1e-3
Emin = 1 + (1 - 100 ** (1 - 1.5)) / 0.5
ok &= abs(_cal26['ceiling']['central']['c_err_m'] - 0.30 * 0.001 * 0.4 * 10 * Emin) < 1e-12
check("26e lem:fullcost(d) E min{Y, Ybar} for a Pareto multiple capped by least privilege (61 tail indices, numerical "
      "integration), uncapped limit p/(p-1), and the central misbehavior term (0.34 points)", ok)

# (e) common mode: sum over providers = nu T [W + H W^2/(2Y)], largest at one provider
ok = True
for _ in range(300):
    Mn = int(RNG.integers(1, 8))
    w = RNG.dirichlet(np.ones(Mn))
    W, Y, nu_, T_ = RNG.uniform(0.01, 1), RNG.uniform(0.01, 1), RNG.uniform(0.1, 10), RNG.uniform(0.001, 0.1)
    direct = sum(nu_ * T_ * (wm * W + (wm * W) ** 2 / (2 * Y)) for wm in w)
    H = float((w ** 2).sum())
    ok &= abs(direct - nu_ * T_ * (W + H * W ** 2 / (2 * Y))) < 1e-12 and H <= 1 + 1e-12
    ok &= direct <= nu_ * T_ * (W + W ** 2 / (2 * Y)) + 1e-15
ok &= abs(_cal26['ceiling']['central']['c_err_cm'] - 2.0 / 365 * 0.30 * 2) < 1e-12
check("26f lem:fullcost(e) common-mode cost nu_cm T_con [W_cm + H_cm W_cm^2/(2 Y_fb)], largest with one provider "
      "(300 draws); reproduces the central common-mode term (0.33 points)", ok)

# prop:amin(a): P_mm by simulation of layered failures; strictly decreasing in depth to p_cm; lower bound
ok = True
for _ in range(40):
    nt = int(RNG.integers(1, 4))
    pc, pi_, nl = RNG.uniform(0.001, 0.2, nt), RNG.uniform(0.01, 0.5, nt), RNG.integers(0, 4, nt)
    if nl.sum() == 0:
        nl[0] = 1
    P_closed = float(np.prod([pc[j] + (1 - pc[j]) * pi_[j] ** nl[j] if nl[j] > 0 else 1.0 for j in range(nt)]))
    sims = 200000
    miss = np.ones(sims, dtype=bool)
    for j in range(nt):
        if nl[j] == 0:
            continue
        cm = RNG.random(sims) < pc[j]
        ind = np.all(RNG.random((sims, nl[j])) < pi_[j], axis=1)
        miss &= cm | ind
    se = math.sqrt(P_closed * (1 - P_closed) / sims)
    ok &= abs(miss.mean() - P_closed) < 5 * se + 1e-4
    ok &= P_closed >= float(np.prod([pc[j] for j in range(nt) if nl[j] > 0])) - 1e-15
for pc_, p_ in [(0.005, 0.02), (0.002, 0.05)]:
    seq = [pc_ + (1 - pc_) * p_ ** n for n in range(1, 12)]
    ok &= all(a_ > b_ for a_, b_ in zip(seq, seq[1:])) and abs(seq[-1] - pc_) < 1e-12
check("27a prop:amin(a) P_mm = prod_j [p_cm_j + (1 - p_cm_j) p_j^n_j] (40 random designs, Monte Carlo), strictly "
      "decreasing in depth to p_cm_j, and at least the product of the common-mode probabilities", ok)

# prop:amin(b),(c): all-AI lower bound; minimized floor nonincreasing in S and tending to o L_mm prod p_cm
def _floor(S, o=24e-9, L=10e6, types=((0.05, 5e5, 0.002), (0.02, 5e4, 0.005)), C_fix=1.38e6, itgc=3.5e5, nmax=12):
    best = float('inf')
    for nh in range(nmax):
        for na in range(nmax):
            P = 1.0
            for (p_, c_, pc_), n_ in zip(types, (nh, na)):
                if n_:
                    P *= pc_ + (1 - pc_) * p_ ** n_
            cost = C_fix + (itgc if na else 0.0) + nh * types[0][1] + na * types[1][1] + o * S * L * P
            best = min(best, cost / S)
    return best
Ss = [1e8, 1e9, 1e10, 1e11, 1e12, 1e14]
fl = [_floor(S) for S in Ss]
lim = 24e-9 * 10e6 * 0.002 * 0.005
ok = all(a_ >= b_ - 1e-15 for a_, b_ in zip(fl, fl[1:])) and fl[-1] >= lim and fl[-1] - lim < 2e-6
ai_only = min((3.5e5 + n * 5e4 + 24 * 10e6 * (0.005 + 0.995 * 0.02 ** n)) for n in range(1, 30))
ok &= ai_only > 3.5e5 + 24 * 10e6 * 0.005
check("27b prop:amin(b),(c) an all-AI design on one provider stays above [C_itgc + N L p_cm]/S; the minimized floor "
      "falls with revenue toward o L_mm prod_j p_cm_j (example parameters, revenue $0.1bn to $100tn)", ok,
      f"floors {[round(100 * x, 4) for x in fl]}% limit {100 * lim:.5f}%")

# ITGC lines per in-scope AI application (companion paper; Paper 1 Section sec:horizons-ceiling)
C_INV26 = 30e3 + 120e3 + 100e3 / 1.22 + 55e3 + 4 * 15e3        # access, change, retest, operations, interfaces
C_TML26 = 161e3                                                # close-window cost with a manual fallback
FLOOR026 = (343.0 * 1000 + 1.04e6) / 1e9 + amin_design(1, 2) / 1e9
n9 = 1 + math.ceil((0.005 - FLOOR026) / (C_INV26 / 1e9))
n6 = 1 + math.ceil((0.005 - FLOOR026 - C_TML26 / 1e9) / ((C_INV26 + C_TML26) / 1e9))
check("27c a_min band: one ITGC line is about 0.035% of revenue at $1bn (0.05% with a close fallback); the bottom-up "
      "floor of about 0.24% reaches the band's lower end of 0.5% at about 9 in-scope AI applications (6 with fallbacks)",
      round(100 * C_INV26 / 1e9, 3) == 0.035 and round(100 * (C_INV26 + C_TML26) / 1e9, 2) == 0.05
      and round(100 * FLOOR026, 2) == 0.24 and n9 == 9 and n6 == 6,
      f"line {100 * C_INV26 / 1e9:.4f}% floor {100 * FLOOR026:.3f}% n={n9}, {n6}")

# ----------------------------------------------------------------------------------------------
n_fail = sum(1 for _, ok in RESULTS if not ok)
print("\n" + "=" * 78)
print(f"SUMMARY: {len(RESULTS) - n_fail}/{len(RESULTS)} checks passed" + ("" if n_fail == 0 else f"; {n_fail} FAILED"))
print("=" * 78)
sys.exit(0 if n_fail == 0 else 1)
