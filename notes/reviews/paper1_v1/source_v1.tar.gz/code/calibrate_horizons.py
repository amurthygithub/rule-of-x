"""Calibrate the maximal Rule-of-40 score by horizon (fourth revision: full cost, capacity, risk and transition dips).

Model: R* = R_inf + Pi with R_inf = m0 + (1-k) G (durable part) and Pi the transient growth surplus, X = 1,
free-cash-flow-after-SBC basis (Proposition score, Remark taxes). A firm still transforming at the horizon scores
lower by the in-flight dip d (Propositions tasks-scorepath and ext-waves(f)), which is reported separately.

Anchor (fifth revision: estimand E2, the organic frontier, read from notes/calibration_anchor_E2.json; the observed-score
anchor E1 below is kept as the comparison). The data identify neither alpha nor lambda*h (Section 5), and a single
cross-firm intercept is infeasible for firms whose margins exceed it. We therefore invert the model firm by firm for the
top tail of 2023-25: firm-years at or above the 95th percentile of the cash-basis score, excluding acquisition-affected
firm-years (purchased growth is not the growth the model describes). On the after-tax cash basis, m = m0 - (1-tau) sigma
- k g (Remark taxes with psi = 0: growth spend is deductible, growth capital is not), so m0 = m + (1-tau) sigma + k g.
Growth spend sigma is bounded: the selling-and-marketing share is an upper bound (all S&M buys growth) and zero a lower
bound (none does). A firm-year that does not report S&M is treated as having none. Then R_inf = m0 + (1-k) G and
Pi = R - R_inf.

Horizons (new in this revision). The margin intercept is no longer a scenario range. It moves from the anchor toward the
full-cost margin term of Corollary ceiling (Table tab:ceiling, Appendix tab:fullcost) at the pace that the attainable and
expected frontiers allow (Propositions attainable and expected):
  m0(h) = m0_A + s(h) [m0_F - m0_A],
  s(h)  = bbar * min{1, q rho T_par n(t_R)},  t_R = (h - 2025)/(1 + nu_R T_frz),
  n(t)  = floor((t - T_emb)/T_par) + 1 for t >= T_emb (waves embedded by t),
  q     = varpi exp(-nu_D T_emb),  nu_D = nu_L (1 - kappa_keep) + nu_V,
  rho   = min{change capacity, decision capacity, security-review capacity}, as shares of the program a year.
The high end of each range pairs the anchor's upper quartile with the favorable full-cost term and the fast pace; the
low end pairs the lower quartile with the central full-cost term and the central pace (an exceptional firm executes at
least as well as a typical one). The dip of a firm still transforming at h is d = a_r T_pb [m0_F - m0_A], with attempt
rate a_r = rho/(1 + nu_R T_frz) and one-time plus parallel-run costs of T_pb years of the savings attempted, as long as
the program has not been completed (expected embedded share below one).
  Pi scales the 2025 interquartile range by mu^(1/(1-alpha)) (demand pull relative to 2025) and by (1-k)^(1/(1-alpha)).
The lower-bound case shifts every m0 down by the anchor's median difference between the two bounds and scales the
lower-bound Pi, as in the third revision. Regime variants: a public firm that holds to a guided dip (Proposition
reg-dip), and a sponsor's faster decisions where decision bandwidth binds (Proposition reg-speed(c)).
The third-revision ranges (fixed m0 scenarios 40-62, 45-65, 50-69) are recomputed and stored under 'previous' so the
memo can report old and new numbers side by side.

Tax deductions for capital (Remark taxes; Part II Proposition acct-tax). The table keeps psi = 0 (capital not
deductible), which suits working capital and is a lower bound. Under current U.S. law domestic research and experimental
expenditure, including software development, is deducted when incurred (26 U.S.C. 174A, tax years beginning after
31 Dec 2024) and equipment acquired after 19 Jan 2025 takes the 100% allowance (IRS Notice 2026-11), so psi = 1; foreign
research is amortized over 15 years from the midpoint (26 U.S.C. 174), psi_15 = 0.532 at r = 0.10; the 2022-2024
five-year regime had psi_5 = 0.796. Block 'psi_sensitivity' reports the anchor intercepts, the k = 0.5 column and the
capital term of the ceiling under each.
"""
import json
import math
import os
import numpy as np
import pandas as pd

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # replication-package root
TAU = 0.18                                          # central cash tax rate, Table ceiling


def psi_T(T, r=0.10):
    """PV per dollar of deductions taken ratably over T years from the midpoint of the first year (Prop. acct-tax(a))."""
    return (1 + (1 + r) ** (-T)) / (2 * T) + (1 - (1 + r) ** (-(T - 1))) / (r * T)


PSI = {'none': 0.0, 'foreign_15y': psi_T(15), 'prior_5y': psi_T(5), 'domestic': 1.0}
ALPHAS = [0.25, 0.45]
H0 = 2025                                           # end of the anchor period; the program starts after it

# ----------------------------------------------------------------------------------------------
# Full-cost margin terms (Corollary ceiling, Definition fullcost). The inputs duplicate those of
# code/verify_theory.py section 20, which checks that this script's JSON reproduces them.
# ----------------------------------------------------------------------------------------------
S_REF = 1e9                                         # reference revenue for fixed and per-process costs, $
WAGE_GOV = 88400 * (1 + 0.4287)                     # compliance officer (SOC 13-1041) mean wage, OEWS May 2025, loaded (ECEC)
FC = {  # favorable, central, conservative; the high-compute case uses central values with c_c = 0.40
    # Rules (Appendix Table tab:fullcost): factors with a sourced or precedent range (classes a to c in
    # notes/assumptions_register.md) take its low end, central value and high end; scenario (class d) composites take a
    # central value from the stated structure, halved and doubled.
    'c_c': (0.15, 0.20, 0.25), 'f': (0.02, 0.025, 0.03), 'tau': (0.15, 0.18, 0.21),
    'a_min': (0.015, 0.03, 0.046),                  # register band [0.005, 0.046] (b); the third revision used 6%
    # c_sec: risk cost of Proposition tasks-security(b) scaled from today's spend, plus PQC and AI compliance
    's0': (0.0069, 0.0069, 0.0069),                 # security spend, share of revenue (IANS 2025; a, flagged)
    'L0': (4.0, 2.0, 1.0),                          # ln(C_inc/C_s): controls remove 98, 86, 63% of expected loss (d)
    'Me': (1.0, 2.0, 3.0),                          # exposure multiplier at full automation (params autonomy multipliers, d)
    'sec_it': (0.119, 0.099, 0.086),                # security share of IT spend (IANS 2024, 2026, 2020; a)
    'phi_pqc': (0.0075, 0.015, 0.03),               # PQC migration a year, share of IT spend (d)
    'aic_fixed': (12e3 + 10e3 + 2.5e3 + (5e3 + 13e3) / 3 + 0.10 * WAGE_GOV,
                  30e3 + 35e3 + 6e3 + (13.5e3 + 30e3) / 3 + 0.25 * WAGE_GOV,
                  150e3 + 60e3 + 9e3 + (20e3 + 50e3) / 3 + 1.00 * WAGE_GOV),   # SOC 2, ISO 42001, NIST AI RMF ($/yr)
    'aic_pp': (0.5, 1.0, 2.0),                      # factor on 48 processes x ($30k red team + $10k PIA / T_up) (d)
    # c_mnt: (delta_M + kappa_reval / T_up) x build stock per revenue
    'delta_M': (0.10, 0.17, 0.40),                  # register: 0.17 [0.10, 0.40] (b)
    'kappa_rv': (0.05, 0.10, 0.20),                 # d
    'T_up': (1.75, 1.22, 0.99),                     # c: median GA model life from 2025; 0.99 = shortest observed
    'B': (0.012, 0.024, 0.048),                     # 48 processes x $0.5M (b) at $1B revenue (d)
    # c_err = errors and hallucination + misbehavior (Proposition tasks-cerr) + common-mode (Proposition ext-commonmode(a));
    # rates from data/tasks/params_reliability.yaml (a, b), loss severities and exposure scenario (d)
    'A_auto': (0.30, 0.30, 0.30),                   # in-house cost of the automated work, share of revenue (d)
    'u_rev': (0.0345 * 0.15 + 0.015 * 0.40,         # review-proof rate e_o(1 - d_o) + e_h(1 - d_h): low rates, high catch
              0.0345 * 0.35 + 0.05 * 0.60,          # central rates (omission 0.0345, hallucination 0.05; catch 0.65, 0.40)
              0.0345 * 0.35 + 0.05 * 0.60),         # held at central: worse rates fail the scope test (Prop tasks-halluc(b))
    'ell_e': (0.25, 0.5, 1.0),                      # loss per undetected error, multiple of the unit's in-house cost (d)
    'mu_m': (0.0005, 0.001, 0.002),                 # consequential misbehavior per task (d; file range 5e-5 to 1e-2)
    'd_m': (0.95, 0.60, 0.42),                      # monitor recall (a)
    'ell_m': (10.0, 10.0, 10.0),                    # loss scale per event, multiple of the unit's in-house cost (d)
    'p_tail': (2.3, 1.5, 1.15), 'Zcap': (100.0, 100.0, 100.0),   # Pareto tail index (b); least-privilege cap (d)
    'nu_cm': (0.5, 2.0, 6.0),                       # provider day-equivalent incidents a year (b)
    'XY': (1.0, 1.0, 1.0),                          # exposure X = A_auto, X/(2 Y_f) = 1, single provider H = 1 (d)
    # c_anc: management of AI spend (FinOps, which for API spend also covers vendor management) and fixed costs
    's_fin': (0.015, 0.03, 0.06),                   # d
    'anc_fixed': (62.5e3, 125e3, 250e3),            # incident-response retainer and legal review of 5 AI vendors (d)
}


def fullcost(case):
    i = {'favorable': 0, 'central': 1, 'conservative': 2, 'high compute': 1}[case]
    v = {k: val[i] for k, val in FC.items()}
    if case == 'high compute':
        v['c_c'] = 0.40
    risk = v['s0'] / v['L0'] * (1 + v['L0'] + math.log(v['Me']))
    pqc = v['phi_pqc'] * v['s0'] / v['sec_it']
    aic = (v['aic_fixed'] + v['aic_pp'] * 48 * (30e3 + 10e3 / 1.22)) / S_REF
    c_sec = risk + pqc + aic
    c_mnt = (v['delta_M'] + v['kappa_rv'] / v['T_up']) * v['B']
    Emin = 1 + (1 - v['Zcap'] ** (1 - v['p_tail'])) / (v['p_tail'] - 1)
    c_err_e = v['A_auto'] * v['u_rev'] * v['ell_e']
    c_err_m = v['A_auto'] * v['mu_m'] * (1 - v['d_m']) * v['ell_m'] * Emin
    c_err_cm = v['nu_cm'] / 365 * v['A_auto'] * (1 + v['XY'])
    c_err = c_err_e + c_err_m + c_err_cm
    c_anc = v['s_fin'] * v['c_c'] + v['anc_fixed'] / S_REF
    c_full = c_mnt + c_sec + c_err + c_anc
    base = (1 - v['tau']) * (1 - v['c_c'] - v['f'] - v['a_min'] - c_full)
    base_acc = (1 - v['tau']) * (1 - v['c_c'] - v['f'] - v['a_min'])
    return dict(c_c=v['c_c'], f=v['f'], a_min=v['a_min'], tau=v['tau'], risk=risk, pqc=pqc, aic=aic, c_sec=c_sec,
                c_mnt=c_mnt, c_err=c_err, c_err_e=c_err_e, c_err_m=c_err_m, c_err_cm=c_err_cm, c_anc=c_anc,
                c_full=c_full, base=base, base_acc=base_acc, G100=1 - base, G100_acc=1 - base_acc)


CEIL = {c: fullcost(c) for c in ['favorable', 'central', 'conservative', 'high compute']}
M0_FAV = CEIL['favorable']['base']                  # favorable full-cost margin term
M0_CEN = CEIL['central']['base']                    # central full-cost margin term
M0_CAP_OLD = (1 - 0.15) * (1 - 0.15 - 0.02 - 0.015) # third revision: favorable accountability-only margin term

# ----------------------------------------------------------------------------------------------
# Pace and risk (Assumption program, Definition attainable(b), Proposition expected(c)). Classes from
# notes/assumptions_register.md:
#   change capacity kappa_abs 0.10 [0.05, 0.20] (b: JOLTS layoffs, restructuring filings);
#   varpi, the probability that an attempted automation works: 0.54 (S&P Global survey: 46% of AI proofs of concept
#     scrapped; Gartner 48%, secondary), 0.80 (BCG: 80% of transformations met targets when six factors were present),
#     0.30 (BCG overall); all class a, flagged as self-reported surveys;
#   bbar, benefit realized on success: 0.85 [0.5, 1] (d);
#   nu_L sponsor hazard 0.204 [0.15, 0.30] (Korn Ferry C-suite tenure; practitioner data);
#   kappa_keep 0.60 [0.30, 0.85] (d), nu_V 0.15 [0.05, 0.30] (d), nu_R 0.46 [0.30, 0.60] (b, flagged),
#   T_frz 0.25 [0.08, 1.0] (b, flagged); T_par 0.17 [0.08, 0.42] (b: AI shadow mode up to about five months);
#   concurrent initiatives Phi 5 [3, 10] and decision units e 1 [0.5, 2] (d); load breakpoints 0.70 and 0.78 for
#   latency factors 1.0 and 0.5 (Proposition reg-speed(c)); security reviews 10 [5, 20] per reviewer-quarter (d), two
#   reviewers; T_emb = T_pb, the payback date including the parallel run (Proposition ext-shocks), 2 [1, 3] years (d).
# Every pace statement is therefore conditional on scenario (class d) values.
# ----------------------------------------------------------------------------------------------
N_PROC = 48
PACE = {
    'fast':    dict(kappa_abs=0.20, varpi=0.80, bbar=1.00, nuL=0.15, kkeep=0.85, nuV=0.05, nuR=0.30, Tfrz=0.08,
                    Tpar=0.08, Temb=1.0, Tpb=1.0, Phi=10, e=0.5, kap=0.70, sec=20 * 4 * 2),
    'central': dict(kappa_abs=0.10, varpi=0.54, bbar=0.85, nuL=0.204, kkeep=0.60, nuV=0.15, nuR=0.46, Tfrz=0.25,
                    Tpar=0.17, Temb=2.0, Tpb=2.0, Phi=5, e=1.0, kap=0.70, sec=10 * 4 * 2),
    'slow':    dict(kappa_abs=0.05, varpi=0.30, bbar=0.50, nuL=0.30, kkeep=0.30, nuV=0.30, nuR=0.60, Tfrz=1.00,
                    Tpar=0.42, Temb=3.0, Tpb=3.0, Phi=3, e=2.0, kap=0.70, sec=5 * 4 * 2),
}
YEARS = [2028, 2031, 2036]


def rates(p, kap=None):
    kap = p['kap'] if kap is None else kap
    rho_chg = p['kappa_abs']
    rho_dec = kap * p['Phi'] / (N_PROC * p['e'] * p['Tpar'])
    rho_sec = p['sec'] / N_PROC
    rho = min(rho_chg, rho_dec, rho_sec)
    binding = ['change', 'decision', 'security'][int(np.argmin([rho_chg, rho_dec, rho_sec]))]
    nuD = p['nuL'] * (1 - p['kkeep']) + p['nuV']
    q = p['varpi'] * math.exp(-nuD * p['Temb'])
    slow = 1 + p['nuR'] * p['Tfrz']
    return dict(rho=rho, binding=binding, rho_chg=rho_chg, rho_dec=rho_dec, rho_sec=rho_sec, nuD=nuD, q=q,
                clock=slow, eff_rate=q * rho / slow, attempt_rate=rho / slow)


def pace(p, dM, kap=None):
    """Waves of Assumption program: expected embedded share s (Proposition expected(c), greedy plan) and the in-flight
    dip by horizon. Waves of length T_par in program time t_R = t/(1 + nu_R T_frz); n(t_R) waves embedded by t."""
    out = rates(p, kap)
    for h in YEARS:
        tR = (h - H0) / out['clock']
        n = 0 if tR < p['Temb'] else math.floor((tR - p['Temb']) / p['Tpar'] + 1e-12) + 1
        raw = out['q'] * out['rho'] * p['Tpar'] * n
        done = raw >= 1
        out[h] = dict(n=n, s=p['bbar'] * min(1.0, raw), running=not done,
                      dip=0.0 if done else out['attempt_rate'] * p['Tpb'] * dM)
    # Derived dates quoted in Paper 1 (read by code/paper1_macros.py). With the greedy plan each embedded wave adds
    # step = q rho T_par to the expected embedded share (before bbar). complete_year: the calendar date at which the
    # program is embedded in expectation; cross_years: years after H0 at which the embedded gain bbar E dM first
    # exceeds the in-flight dip a_r T_pb dM (None if it never does while the program runs).
    step = out['q'] * out['rho'] * p['Tpar']
    n_full = math.ceil(1 / step - 1e-9)
    out['complete_year'] = H0 + out['clock'] * (p['Temb'] + (n_full - 1) * p['Tpar'])
    n_cross = math.floor(out['attempt_rate'] * p['Tpb'] / (p['bbar'] * step)) + 1
    out['cross_years'] = (out['clock'] * (p['Temb'] + (n_cross - 1) * p['Tpar'])
                          if n_cross < n_full else None)
    out['params'] = dict(p, dM=dM, n_proc=N_PROC)
    return out


def pace_fluid(p, dM, kap=None, dip_budget=None, dt=1 / 365):
    """Fluid version in program time, optionally with a dip budget (a public firm that holds to a guided dip,
    Proposition reg-dip): the calendar flow change bbar E dM - a T_pb dM/clock may not fall below -dip_budget, so the
    attempt rate a <= clock (dip_budget + bbar E dM)/(T_pb dM), and a <= rho; E(t) = q x (share attempted by t - T_emb)."""
    out = rates(p, kap)
    rho, q, clock = out['rho'], out['q'], out['clock']
    nT = int(round(((max(YEARS) - H0) / clock) / dt)) + 2
    lag = int(round(p['Temb'] / dt))
    cum = np.zeros(nT + 1)            # cumulative share attempted
    a_hist = np.zeros(nT + 1)
    for i in range(nT):
        E = min(1.0, q * (cum[i - lag] if i >= lag else 0.0))
        if q * cum[i] >= 1.0:          # enough attempts made: the program winds down
            a = 0.0
        else:
            a = rho if dip_budget is None else min(rho, clock * (dip_budget + p['bbar'] * E * dM) / (p['Tpb'] * dM))
        a_hist[i] = a
        cum[i + 1] = cum[i] + a * dt
    for h in YEARS:
        i = int(round(((h - H0) / clock) / dt))
        E = min(1.0, q * (cum[i - lag] if i >= lag else 0.0))
        out[h] = dict(s=p['bbar'] * E, attempt_rate=a_hist[i], dip=a_hist[i] / clock * p['Tpb'] * dM,
                      running=a_hist[i] > 0)
    out['a0_share'] = a_hist[0] / rho                  # initial attempt rate as a share of the unconstrained one
    return out


# ----------------------------------------------------------------------------------------------
# Anchor (unchanged)
# ----------------------------------------------------------------------------------------------
d = pd.read_csv(f'{BASE}/data/panel.csv')
d = d[d.period == '2023-25'].copy()
d['R'] = d.g + d.m_fcf_sbc
G25 = float(d.g.median())
p95 = float(d.R.quantile(.95))
tail = d[d.R >= p95].copy()
m_p95_all = float(d.m_fcf_sbc.quantile(.95))
top = tail[tail.acq_flag == 0].copy()
top['sig_ub'] = (top.sm / top.rev).fillna(0.0)
top['kg'] = top.capex_int.fillna(0.0)
top['k'] = np.where(top.g > 0, top.kg / top.g, 0.0)
top['m0_ub'] = top.m_fcf_sbc + (1 - TAU) * top.sig_ub + top.kg
top['m0_lb'] = top.m_fcf_sbc + top.kg
for b in ['ub', 'lb']:
    top['Rinf_' + b] = top['m0_' + b] + (1 - top.k) * G25
    top['Pi_' + b] = top.R - top['Rinf_' + b]
q3 = lambda s: [float(s.quantile(.25)), float(s.quantile(.5)), float(s.quantile(.75))]
anchor = dict(n_tail=int(len(tail)), n_tail_m_above_p95=int((tail.m_fcf_sbc > m_p95_all).sum()), m_p95_all=m_p95_all,
              n=int(len(top)), n_acq_excluded=int(len(tail) - len(top)), n_sm_missing=int(top.sm.isna().sum()),
              p95=p95, G=G25, tau=TAU, R=q3(top.R), m=q3(top.m_fcf_sbc), sig_ub=q3(top.sig_ub),
              **{f'{v}_{b}': q3(top[f'{v}_{b}']) for v in ['m0', 'Rinf', 'Pi'] for b in ['ub', 'lb']},
              shift=float(top.m0_ub.median() - top.m0_lb.median()),
              firms=sorted(top.name.unique().tolist()))

# Estimand of the anchor (Paper 1, Section data-estimands). The model-facing calibration uses E2, the organic frontier:
# cut-off, G and the top tail are taken from the E2 sample of code/estimate_organic.py, which removes acquired growth
# (pro forma where disclosed, otherwise excluding acquisition-affected firm-years). notes/calibration_anchor_E2.json
# holds the E2 anchor and an E1 block in the same format; the E1 block must reproduce the observed-score anchor computed
# above from data/panel.csv, which is kept as the reported comparison ('anchor_E1').
anchor_E1 = anchor
_af = json.load(open(f'{BASE}/notes/calibration_anchor_E2.json'))
for _k in ['n_tail', 'n_tail_m_above_p95', 'n', 'n_acq_excluded', 'n_sm_missing', 'p95', 'G', 'tau', 'R', 'm', 'sig_ub',
           'm0_ub', 'm0_lb', 'Rinf_ub', 'Rinf_lb', 'Pi_ub', 'Pi_lb', 'shift', 'firms']:
    _a, _b = anchor_E1[_k], _af['E1'][_k]
    assert (_a == _b) if isinstance(_a, (str, int, list)) and not (isinstance(_a, list) and _a and isinstance(_a[0], float)) \
        else np.allclose(_a, _b, rtol=0, atol=1e-12), f'E1 block of calibration_anchor_E2.json differs from the panel anchor: {_k}'
anchor = {k: v for k, v in _af['E2'].items() if k != 'firm_years'}
top = pd.DataFrame(_af['E2']['firm_years'])           # E2 anchor firm-years (used for the tax-deduction sensitivity)
G25 = anchor['G']

HZ = {
    '2028': dict(G=(0.10, 0.20), mu=(1.0, 2.0)),
    '2031': dict(G=(0.08, 0.20), mu=(0.75, 1.5)),
    '2036': dict(G=(0.05, 0.30), mu=(0.5, 1.25)),
}
HZ_OLD_M0 = {'2028': (0.40, 0.62), '2031': (0.45, 0.65), '2036': (0.50, M0_CAP_OLD)}


def Pi_scaled(Pi0, mu, alpha, k):
    return Pi0 * mu ** (1 / (1 - alpha)) * (1 - k) ** (1 / (1 - alpha))


Pi_ub = (max(anchor['Pi_ub'][0], 0.0), anchor['Pi_ub'][2])
Pi_lb = (max(anchor['Pi_lb'][0], 0.0), anchor['Pi_lb'][2])
m0A = (anchor['m0_ub'][0], anchor['m0_ub'][2])      # anchor interquartile ends, upper-bound case
dM_lo, dM_hi = M0_CEN - m0A[0], M0_FAV - m0A[1]
PL = pace(PACE['central'], dM_lo)
PH = pace(PACE['fast'], dM_hi)


def horizon(h, Pi_25, m0_pair, dip_pair, shift=0.0, psi=0.0):
    p = HZ[h]
    rec = {}
    for k_pre in [0.0, 0.5]:
        k = (1 - psi * TAU) * k_pre                  # after-tax capital intensity (Remark taxes)
        m0 = (m0_pair[0] - shift, m0_pair[1] - shift)
        Rinf = (m0[0] + (1 - k) * p['G'][0], m0[1] + (1 - k) * p['G'][1])
        Pi = (min(Pi_scaled(Pi_25[0], p['mu'][0], a, k) for a in ALPHAS),
              max(Pi_scaled(Pi_25[1], p['mu'][1], a, k) for a in ALPHAS))
        R = (Rinf[0] + Pi[0], Rinf[1] + Pi[1])
        rec[str(k_pre)] = dict(m0=m0, Rinf=Rinf, Pi=Pi, R=R, dip=dip_pair,
                           R_net=(R[0] - dip_pair[0], R[1] - dip_pair[1]))
    return rec


out = dict(anchor=anchor, anchor_E1=anchor_E1, anchor_estimand='E2 (organic frontier); anchor_E1 is the observed-score comparison', ceiling=CEIL, pace={'central': PL, 'fast': PH}, upper_bound={}, lower_bound={},
           previous={'upper_bound': {}, 'lower_bound': {}})
for h in HZ:
    yi = int(h)
    s_pair = (PL[yi]['s'], PH[yi]['s'])
    m0_pair = (m0A[0] + s_pair[0] * dM_lo, m0A[1] + s_pair[1] * dM_hi)
    dip_pair = (PL[yi]['dip'], PH[yi]['dip'])
    for b, Pi25, sh in [('upper_bound', Pi_ub, 0.0), ('lower_bound', Pi_lb, anchor['shift'])]:
        out[b][h] = horizon(h, Pi25, m0_pair, dip_pair, shift=sh)
        out[b][h]['s'] = s_pair
        out['previous'][b][h] = horizon(h, Pi25, HZ_OLD_M0[h], (0.0, 0.0), shift=sh)

# Regime and pace variants (low end of the range: central pace from the lower anchor quartile)
var = {}
var['central_fluid'] = pace_fluid(PACE['central'], dM_lo)
var['public_guided_dip_1pt'] = pace_fluid(PACE['central'], dM_lo, dip_budget=0.01)
var['public_guided_dip_2pt'] = pace_fluid(PACE['central'], dM_lo, dip_budget=0.02)
var['sponsor_latency_0.5'] = pace(PACE['central'], dM_lo, kap=0.78)
var['slow_public'] = pace(PACE['slow'], dM_lo, kap=0.70)
var['slow_sponsor_latency_0.5'] = pace(PACE['slow'], dM_lo, kap=0.78)
for name, v in var.items():
    v['m0'] = {h: m0A[0] + v[h]['s'] * dM_lo for h in YEARS}
out['variants'] = var
# compute-share sensitivity (Corollary ceiling): central case over the scenario bounds of c_c, and tau at 9%
def G100_central(cc, tau=None):
    v = {k: val[1] for k, val in FC.items()}
    tau = v['tau'] if tau is None else tau
    c = fullcost('central')
    c_anc = v['s_fin'] * cc + v['anc_fixed'] / S_REF
    full = c['c_full'] - c['c_anc'] + c_anc
    return 1 - (1 - tau) * (1 - cc - v['f'] - v['a_min'] - full), 1 - (1 - tau) * (1 - cc - v['f'] - v['a_min'])
out['cc_sensitivity'] = {f'{cc:.2f}': G100_central(cc) for cc in [0.01, 0.15, 0.20, 0.25, 0.40, 0.55]}
out['tau_sensitivity'] = {f'{t:.2f}': G100_central(0.20, t) for t in [0.09, 0.15, 0.18, 0.21]}
out['cerr_sensitivity'] = {}
for nm, ce in [('favorable', fullcost('favorable')['c_err']), ('central', fullcost('central')['c_err']),
               ('conservative', fullcost('conservative')['c_err']),
               ('high rates, unit loss', 0.30 * (0.18 * 0.55 + 0.20 * 0.80) * 1.0)]:
    c = fullcost('central')
    v = {k: val[1] for k, val in FC.items()}
    out['cerr_sensitivity'][nm] = (ce, 1 - (1 - v['tau']) * (1 - v['c_c'] - v['f'] - v['a_min'] - c['c_full'] + c['c_err'] - ce))
out['amin_sensitivity'] = {}
for am in [0.005, 0.03, 0.046]:
    v = {k: val[1] for k, val in FC.items()}
    c = fullcost('central')
    out['amin_sensitivity'][f'{am:.3f}'] = (1 - (1 - v['tau']) * (1 - v['c_c'] - v['f'] - am - c['c_full']),
                                            1 - (1 - v['tau']) * (1 - v['c_c'] - v['f'] - am))

# Tax deductions for capital: anchor intercepts, k = 0.5 column and the ceiling's capital term under each psi
psi_out = {'psi': PSI, 'anchor_m0_ub': {}, 'anchor_m0_lb': {}, 'k05_upper_bound': {}, 'ceiling_k15_G30_loss': {}}
for nm, ps in PSI.items():
    psi_out['anchor_m0_ub'][nm] = q3(top.m_fcf_sbc + (1 - TAU) * top.sig_ub + (1 - ps * TAU) * top.kg)
    psi_out['anchor_m0_lb'][nm] = q3(top.m_fcf_sbc + (1 - ps * TAU) * top.kg)
    psi_out['k05_upper_bound'][nm] = {}
    for h in HZ:
        yi = int(h)
        s_pair = (PL[yi]['s'], PH[yi]['s'])
        m0_pair = (m0A[0] + s_pair[0] * dM_lo, m0A[1] + s_pair[1] * dM_hi)
        psi_out['k05_upper_bound'][nm][h] = horizon(h, Pi_ub, m0_pair, (PL[yi]['dip'], PH[yi]['dip']), psi=ps)['0.5']['R']
    psi_out['ceiling_k15_G30_loss'][nm] = {f'{t:.2f}': (1 - ps * t) * 1.5 * 0.30 for t in FC['tau']}
psi_out['anchor_tau_kg'] = q3(TAU * top.kg)
out['psi_sensitivity'] = psi_out

C = lambda a: (1 - a) * a ** (a / (1 - a))
out['Lambda_rule1000'] = {a: ((10 - (0.5 + 0.2)) / C(a)) ** (1 - a) for a in [0.2, 0.25, 0.3, 0.45]}
out['lam_for_Pi'] = {b: {a: (P[1] / C(a)) ** (1 - a) for a in ALPHAS} for b, P in [('ub', Pi_ub), ('lb', Pi_lb)]}
out['rule1000_multiple'] = {b: {a: out['Lambda_rule1000'][a] / out['lam_for_Pi'][b][a] for a in ALPHAS} for b in ['ub', 'lb']}


def rng(t):
    a, b = int(np.floor(100 * t[0] + 0.5)), int(np.floor(100 * t[1] + 0.5))
    if a == b:
        return f"{a}"
    return f"${a}$ to {b}" if a < 0 else f"{a}--{b}"


def rng0(t):
    a, b = int(np.floor(100 * t[0] + 0.5)), int(np.floor(100 * t[1] + 0.5))
    return f"{a}" if a == b else f"{a}--{b}"


iq = lambda v: rng((v[0], v[2]))


def dipr(dp):
    lo, hi = sorted(dp)
    f1 = lambda x: f"{100 * x:.1f}".replace('.0', '') if abs(100 * x) < 1e-9 else f"{100 * x:.1f}"
    return f"{f1(lo)}" if abs(lo - hi) < 5e-4 else f"{f1(lo)}--{f1(hi)}"
A = anchor
rows = [f"2025 (anchor) & 0 & {iq(A['m0_ub'])} & {rng((G25, G25))} & 1 & {iq(A['Rinf_ub'])} & {iq(A['Pi_ub'])} & "
        f"{iq(A['R'])} & -- & -- \\\\"]
for h, p in HZ.items():
    rec = out['upper_bound'][h]
    mu = p['mu']
    mus = f"{mu[0]:g}" if mu[0] == mu[1] else f"{mu[0]:g}--{mu[1]:g}"
    rows.append(f"{h} & {rng0(rec['s'])} & {rng(rec['0.0']['m0'])} & {rng(p['G'])} & {mus} & {rng(rec['0.0']['Rinf'])} & "
                f"{rng(rec['0.0']['Pi'])} & {rng(rec['0.0']['R'])} & {rng(rec['0.5']['R'])} & "
                f"{dipr(rec['0.0']['dip'])} \\\\")

tab = r"""\begin{table}[t]\centering\small
\caption{Calibrated maximal Rule-of-40 score by horizon for an exceptional firm, at full cost and attainable pace (free-cash-flow-after-SBC basis, $X=1$)}\label{tab:calib}
\resizebox{\textwidth}{!}{\begin{tabular}{lrrrrrrrrr}\toprule
 & \multicolumn{4}{c}{Program and scenario} & \multicolumn{2}{c}{Components, $k=0$} & \multicolumn{2}{c}{Maximal score $R^*$} & \\\cmidrule(lr){2-5}\cmidrule(lr){6-7}\cmidrule(lr){8-9}
Horizon & Embedded $\mathcal E$ & $m_0$ & $G$ & Pull $\mu$ & Durable $R_\infty$ & Transient $\Pi$ & $k=0$ & $k=0.5$ & Dip\\\midrule
""" + '\n'.join(rows) + r"""
\bottomrule\end{tabular}}
\par\vspace{2pt}\footnotesize\raggedright Notes: Percentage points except $\mu$, rounded half up; $\mathcal E$ is the expected share of the automation program embedded by the horizon. $R^*=R_\infty+\Pi$ with $R_\infty=m_0+(1-k)G$ (Proposition~\ref{prop:optimum}); a firm still transforming at the horizon scores lower by the dip of the transitions in flight (Section~\ref{sec:model-attainable}; the path of the dip is derived in \citealp{murthy2026transformation}). The 2025 row inverts the model for the """ + f"{A['n']}" + r""" firm-years of the organic frontier (E2) at or above the 95th percentile of its 2023--25 cash-basis score. On the after-tax cash basis $m_0=m+(1-\tau)\sigma+kg$, with capital treated as not deductible ($\psi=0$, Remark~\ref{rem:taxes}), $\tau=""" + f"{TAU:g}" + r"""$ and the selling-and-marketing share as an upper bound on $\sigma$; $\Pi=R-R_\infty$. Its entries are interquartile ranges of the firm-level values, and its $R^*$ entry is the interquartile range of observed scores. Later rows are scenario bounds under our scenario assumptions (the intercept path, $G$, $\mu$, $k$ and the execution parameters are scenario values), not forecasts; each range pairs the low and high ends of all assumptions. The intercept moves from the anchor's quartiles toward the central and favorable full-cost margin terms of Table~\ref{tab:ceiling} (""" + f"{int(np.floor(100 * M0_CEN + 0.5))} and {int(np.floor(100 * M0_FAV + 0.5))}" + r"""), $m_0=m_{0A}+\mathcal E\,(m_{0F}-m_{0A})$, with $\mathcal E$ from Proposition~\ref{prop:expected}(c) at central and fast execution (Section~\ref{sec:horizons}); $\Pi$ scales the 2025 range, floored at zero, by $\mu^{1/(1-\alpha)}$ for demand pull $\mu$ times its 2025 level and by $(1-k)^{1/(1-\alpha)}$ for capital intensity, with $\alpha\in[0.25,0.45]$.
\end{table}"""
open(f'{BASE}/sections/tables/tab_calib.tex', 'w').write(tab)


def _clean(o):
    if isinstance(o, dict):
        return {str(k): _clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_clean(v) for v in o]
    if isinstance(o, (np.floating, np.integer, np.bool_)):
        return o.item()
    return o


json.dump(_clean(out), open(f'{BASE}/notes/calibration_results.json', 'w'), indent=1)
print(json.dumps({k: v for k, v in anchor.items() if k != 'firms'}, indent=0))
print(anchor['firms'])
print('\n'.join(rows))
for c, v in CEIL.items():
    print(f"ceiling {c:12s}: c_full={100 * v['c_full']:.2f} (mnt {100 * v['c_mnt']:.2f}, sec {100 * v['c_sec']:.2f}, "
          f"err {100 * v['c_err']:.2f}, anc {100 * v['c_anc']:.2f}); margin term {100 * v['base']:.2f} "
          f"(accountability only {100 * v['base_acc']:.2f}); G for 100: {100 * v['G100']:.2f}% ({100 * v['G100_acc']:.2f}%)")
for nm, P in [('central', PL), ('fast', PH)]:
    print(nm, {k: (round(v, 4) if isinstance(v, float) else v) for k, v in P.items() if not isinstance(k, int)},
          {h: {kk: round(vv, 4) for kk, vv in P[h].items() if not isinstance(vv, bool)} for h in YEARS})
for b in ['upper_bound', 'lower_bound']:
    print(b, 'NEW', {h: (rng(v['0.0']['R']), rng(v['0.0']['Rinf']), rng(v['0.0']['Pi']), rng(v['0.5']['R']),
                         rng(v['0.0']['R_net'])) for h, v in out[b].items()})
    print(b, 'OLD', {h: (rng(v['0.0']['R']), rng(v['0.0']['Rinf']), rng(v['0.0']['Pi']), rng(v['0.5']['R']))
                     for h, v in out['previous'][b].items()})
for name, v in var.items():
    print(name, {h: (round(v[h]['s'], 4), round(100 * v['m0'][h], 2), round(100 * v[h]['dip'], 2)) for h in YEARS},
          'binding', v['binding'], 'rho', round(v['rho'], 4))
print('c_c sensitivity (G* full cost, accountability only):', {k: tuple(round(100 * x, 2) for x in v) for k, v in out['cc_sensitivity'].items()})
print('tau sensitivity:', {k: tuple(round(100 * x, 2) for x in v) for k, v in out['tau_sensitivity'].items()})
print('c_err sensitivity (c_err, central G*):', {k: tuple(round(100 * x, 2) for x in v) for k, v in out['cerr_sensitivity'].items()})
print('psi:', {k: round(v, 4) for k, v in PSI.items()})
print('psi anchor m0_ub quartiles:', {k: [round(100 * x, 2) for x in v] for k, v in psi_out['anchor_m0_ub'].items()},
      'tau kg quartiles', [round(100 * x, 2) for x in psi_out['anchor_tau_kg']])
print('psi k=0.5 column (upper bound):', {k: {h: rng(r) for h, r in v.items()} for k, v in psi_out['k05_upper_bound'].items()})
print('psi ceiling loss at k=1.5, G=0.30:', {k: {t: round(100 * x, 2) for t, x in v.items()} for k, v in psi_out['ceiling_k15_G30_loss'].items()})
print('a_min sensitivity:', {k: tuple(round(100 * x, 2) for x in v) for k, v in out['amin_sensitivity'].items()})
print(out['Lambda_rule1000'], out['lam_for_Pi'], out['rule1000_multiple'])
