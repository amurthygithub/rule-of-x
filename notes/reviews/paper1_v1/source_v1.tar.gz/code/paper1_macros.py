#!/usr/bin/env python3
"""Generate the numbers quoted in Paper 1 ("The Efficient Frontier of Growth and Profitability").

Reads (never writes) the outputs of the analysis scripts:
  notes/calibration_results.json   code/calibrate_horizons.py   (ceiling, thresholds, pace, horizons, anchor)
  notes/paper_stats.json           code/paper_stats.py          (statistics quoted only in the text)
  notes/empirics_revised.json      code/estimate_revised.py     (slopes, top quantiles, spend ratio, capital split)
  notes/gap_decomposition.json     code/decompose_gap.py        (margin-gap decomposition)
  notes/empirics_organic.json      code/estimate_organic.py     (estimands E1, observed scores, and E2, organic frontier)
  data/panel.csv, data/panel_broad.csv                          (sample counts)
and writes
  paper1/macros.tex          one \\newcommand per quoted number (rounded half up as stated per macro)
  paper1/abstract_plain.txt  the abstract of sections/abstract.tex with the macros expanded, as plain text for the
                             arXiv abstract field (fails if it exceeds 1,920 characters)

Every number in the abstract, introduction, horizons section and conclusion of Paper 1 is a macro defined here,
except model inputs stated as assumptions (for example a 20% compute share) and counts of theoretical objects.
A few model examples (the duration bound of Corollary cor:transient and the free-entry score of Proposition
prop:entry) are evaluated here from their closed forms at the example inputs stated in the text.

Run from anywhere:  python3 code/paper1_macros.py
"""
import json
import math
import os
import re
import sys

import pandas as pd

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_DIR = os.path.join(BASE, 'paper1')
CAL = json.load(open(os.path.join(BASE, 'notes', 'calibration_results.json')))
STATS = json.load(open(os.path.join(BASE, 'notes', 'paper_stats.json')))
EMP = json.load(open(os.path.join(BASE, 'notes', 'empirics_revised.json')))
GAP = json.load(open(os.path.join(BASE, 'notes', 'gap_decomposition.json')))
ORG = json.load(open(os.path.join(BASE, 'notes', 'empirics_organic.json')))
MAX_ABSTRACT = 1920

M = {}          # macro name -> LaTeX string
PLAIN = {}      # macro name -> plain-text string (for the arXiv abstract)


def half_up(x, nd=0):
    q = 10 ** nd
    return math.floor(x * q + 0.5) / q


def fmt(x, nd=0, pct=True):
    """x is a fraction if pct, else a plain number; returns the rounded value as text (no % sign)."""
    v = half_up(100 * x if pct else x, nd)
    s = f"{v:.{nd}f}"
    return s


def put(name, text, plain=None):
    assert re.fullmatch(r'[A-Za-z]+', name), name
    assert name not in M, f"duplicate macro {name}"
    M[name] = text
    PLAIN[name] = plain if plain is not None else text


def num(name, x, nd=0, pct=True):
    s = fmt(x, nd, pct)
    if s.startswith('-'):
        put(name, f"$-${s[1:]}", f"-{s[1:]}")
    else:
        put(name, s)


def thousands(n):
    return f"{n:,}".replace(',', '{,}'), f"{n:,}"


# ---------------------------------------------------------------------------------------------- samples
core = pd.read_csv(os.path.join(BASE, 'data', 'panel.csv'))
broad = pd.read_csv(os.path.join(BASE, 'data', 'panel_broad.csv'))
put('NFirms', str(core.cik.nunique()))
t, p = thousands(len(core)); put('NFirmYears', t, p)
put('NFirmsBroad', str(broad.cik.nunique()))
t, p = thousands(len(broad)); put('NFirmYearsBroad', t, p)

# ---------------------------------------------------------------------------------------------- empirics
sl = EMP['local']
num('SlopeOp', -sl['op']['slopes']['pooled']['b'], 2, pct=False)       # 0.46
num('SlopeCash', -sl['cash']['slopes']['pooled']['b'], 2, pct=False)   # 0.37
sr = EMP['spend_ratio']['median']
num('SpendRatio', sr, 1, pct=False)                                    # 3.3
num('WeightLo', ORG['headline']['weight_lo']['E2']['est'], 0, pct=False)   # E2: alpha(X - k) = spend ratio, alpha in [0.25, 0.45]
num('WeightHi', ORG['headline']['weight_hi']['E2']['est'], 0, pct=False)
num('TopDropOp', -EMP['top']['op']['diff_1619|q95']['diff'])           # 12 points, GAAP
num('TopDropCash', -EMP['top']['cash']['diff_1619|q95']['diff'])       # 15 points, FCF after SBC
num('ScaleSlope', -EMP['scale']['cash']['slope']['b'] * math.log(10))  # points per tenfold increase in revenue
num('CapIntGap', -EMP['capint']['cash']['2023-25']['gap'])            # 2023-25, cash basis
num('GapAvg', GAP['avg']['gap'])                                       # about 35 points
num('GapAvgOne', GAP['avg']['gap'], 1)
band40 = [b for b in GAP['bands'] if b['band'] == 4][0]                # growth 40 to 60%
num('GapFast', band40['gap'])
num('GapFastSM', band40['d_sms'])
band0 = [b for b in GAP['bands'] if b['band'] == 0][0]                 # growth below 10%
num('GapSlow', band0['gap'])
num('GapSlowGM', band0['d_gm'])
num('MedGrossMargin', STATS['median_gross_margin_2023_25'])
ga = STATS['ga_median_by_size']
num('GAsmall', ga['<1B']); num('GAmid', ga['1-10B']); num('GAlarge', ga['>10B'])
num('GAleanLo', STATS['ga_microsoft_oracle_range'][0], 1); num('GAleanHi', STATS['ga_microsoft_oracle_range'][1], 1)
num('PalantirGAAP', STATS['palantir_2025']['R_op'])

# ---------------------------------------------------------------------------------------------- estimands
# E1 = observed scores (all firm-years), E2 = organic frontier (pro forma adjusted where disclosed, otherwise
# acquisition-affected firm-years excluded). Model-facing statements use E2, descriptive statements E1.
H = ORG['headline']
def e(key, est='E2'):
    return H[key][est]['est']
def ci(key, est='E2'):
    return H[key][est]['ci90']
smp = ORG['samples']['E2']
t_, p_ = thousands(smp['n']); put('EtwoFirmYears', t_, p_); put('EtwoFirms', str(smp['firms']))
put('EtwoAffectedKept', str(smp['n_affected_kept'])); put('EtwoFastTwentyThree', str(smp['n_g_ge_40_2023_25']))
put('EoneFastTwentyThree', str(ORG['samples']['E1']['n_g_ge_40_2023_25']))
num('EtwoSlopeOp', -e('slope_op_pooled'), 2, pct=False); num('EtwoSlopeCash', -e('slope_cash_pooled'), 2, pct=False)
num('EtwoSlopeOpSe', H['slope_op_pooled']['E2']['se'], 2, pct=False)
num('EtwoSlopeCashSe', H['slope_cash_pooled']['E2']['se'], 2, pct=False)
num('SlopeOpDiffLo', H['slope_op_pooled']['E1_minus_E2']['ci90'][0], 2, pct=False)
num('SlopeOpDiffHi', H['slope_op_pooled']['E1_minus_E2']['ci90'][1], 2, pct=False)
num('SlopeCashDiffLo', H['slope_cash_pooled']['E1_minus_E2']['ci90'][0], 2, pct=False)
num('SlopeCashDiffHi', H['slope_cash_pooled']['E1_minus_E2']['ci90'][1], 2, pct=False)
for per, nm in [('2010_19', 'Early'), ('2020_25', 'Late')]:
    num('EoneSlopeOp' + nm, -e('slope_op_' + per, 'E1'), 2, pct=False); num('EtwoSlopeOp' + nm, -e('slope_op_' + per), 2, pct=False)
    num('EoneSlopeCash' + nm, -e('slope_cash_' + per, 'E1'), 2, pct=False); num('EtwoSlopeCash' + nm, -e('slope_cash_' + per), 2, pct=False)
num('EoneSpendRatio', e('spend_ratio', 'E1'), 1, pct=False); num('EtwoSpendRatio', e('spend_ratio'), 1, pct=False)
num('EoneWeightLo', e('weight_lo', 'E1'), 1, pct=False); num('EoneWeightHi', e('weight_hi', 'E1'), 1, pct=False)
num('EtwoWeightLoOne', e('weight_lo'), 1, pct=False); num('EtwoWeightHiOne', e('weight_hi'), 1, pct=False)
num('EoneScaleCash', -e('scale_tenfold_cash', 'E1')); num('EoneScaleCashOne', -e('scale_tenfold_cash', 'E1'), 1)
num('EoneScaleCashSe', H['scale_tenfold_cash']['E1']['se'], 1)
num('EtwoScaleCashOne', -e('scale_tenfold_cash'), 1); num('EtwoScaleCashSe', H['scale_tenfold_cash']['E2']['se'], 1)
num('EoneCapIntGap', -e('capint_gap_cash_2023_25', 'E1')); num('EtwoCapIntGap', -e('capint_gap_cash_2023_25'))
num('EtwoCapIntLo', -ci('capint_gap_cash_2023_25')[1]); num('EtwoCapIntHi', -ci('capint_gap_cash_2023_25')[0])
cg = H['capint_gap_cash_2023_25']['E2']
num('EtwoCapIntHiHalf', cg['hi']); num('EtwoCapIntLoHalf', cg['lo'])
num('EtwoCapIntOp', -e('capint_gap_op_2023_25')); num('EtwoCapIntOpLo', ci('capint_gap_op_2023_25')[0]); num('EtwoCapIntOpHi', ci('capint_gap_op_2023_25')[1])
num('EtwoScaleOpOne', e('scale_tenfold_op'), 1); num('EtwoScaleOpSe', H['scale_tenfold_op']['E2']['se'], 1)
num('ScaleDiffLo', H['scale_tenfold_cash']['E1_minus_E2']['ci90'][0], 1); num('ScaleDiffHi', H['scale_tenfold_cash']['E1_minus_E2']['ci90'][1], 1)
num('EtwoTopDropOp', -e('p95_change_op')); num('EtwoTopDropCash', -e('p95_change_cash'))
num('EtwoTfortyOp', e('T_op_g40_change')); num('EtwoTfortyCash', e('T_cash_g40_change'))
num('EtwoTfortyCashLo', ci('T_cash_g40_change')[0]); num('EtwoTfortyCashHi', ci('T_cash_g40_change')[1])
num('EtwoTfortyOpLo', ci('T_op_g40_change')[0]); num('EtwoTfortyOpHi', ci('T_op_g40_change')[1])
sp2 = H['spend_ratio']['E2']
num('EtwoSpendIqrLo', sp2['iqr'][0], 1, pct=False); num('EtwoSpendIqrHi', sp2['iqr'][1], 1, pct=False)
num('EtwoMedSM', sp2['med_sm']); num('EtwoMedExcess', sp2['med_excess'], 1)
num('EtwoGapAvgLo', ci('gap_avg')[0]); num('EtwoGapAvgHi', ci('gap_avg')[1])
num('EtwoGapSM', e('gap_sm'), 1); num('EtwoGapFastOne', e('gap_fast'), 1); num('EtwoGapFastSMOne', e('gap_fast_sm'), 1)
num('EtwoGapSlowOne', e('gap_slow'), 1); num('EtwoGapSlowGMOne', e('gap_slow_gm'), 1)
num('EtwoGapAvg', e('gap_avg')); num('EtwoGapAvgOne', e('gap_avg'), 1)
num('EtwoGapFast', e('gap_fast')); num('EtwoGapFastSM', e('gap_fast_sm'))
num('EtwoGapSlow', e('gap_slow')); num('EtwoGapSlowGM', e('gap_slow_gm'))

# ---------------------------------------------------------------------------------------------- ceiling
C = CAL['ceiling']
cases = [('Fav', 'favorable'), ('Cen', 'central'), ('Cons', 'conservative'), ('High', 'high compute')]
for tag, key in cases:
    c = C[key]
    num('Gstar' + tag, c['G100'])                      # market growth for R_max = 100, k = 0
    num('Gstar' + tag + 'One', c['G100'], 1)
    num('GstarAcc' + tag, c['G100_acc'])               # accountability costs only
    num('Margin' + tag, c['base'], 1)                  # margin term (ceiling at G = 0), one decimal
    num('Margin' + tag + 'R', c['base'])               # rounded
    num('Cfull' + tag, c['c_full'], 1)
    num('Cc' + tag, c['c_c'])
    for G, gname in [(0.05, 'Five'), (0.15, 'Fifteen'), (0.30, 'Thirty')]:
        num('Ceil' + tag + gname, c['base'] + G)       # ceiling at k = 0
    num('MarginAcc' + tag, c['base_acc'], 1)           # margin term with accountability costs only
    # Table tab:ceiling columns (G, k), psi = 0, delta_K = 0: R_max = base + (1 - k) G, one decimal
    for col, (G, kk) in zip('ABCDEF', [(0.05, 0), (0.15, 0), (0.30, 0), (0.15, 0.5), (0.05, 1.5), (0.30, 1.5)]):
        num('CeilTab' + tag + col, c['base'] + (1 - kk) * G, 1)
cc = {float(k): v for k, v in CAL['cc_sensitivity'].items()}
num('CcLo', min(cc)); num('CcHi', max(cc))
num('GstarCcLo', cc[min(cc)][0]); num('GstarCcHi', cc[max(cc)][0])
num('GstarAccCcLo', cc[min(cc)][1]); num('GstarAccCcHi', cc[max(cc)][1])
tau = {float(k): v for k, v in CAL['tau_sensitivity'].items()}
num('TauLow', 0.09); num('GstarTauLow', tau[0.09][0]); num('GstarAccTauLow', tau[0.09][1])
num('GstarTauLo', tau[0.15][0]); num('GstarTauHi', tau[0.21][0])
am = {float(k): v for k, v in CAL['amin_sensitivity'].items()}
num('GstarAminLo', am[min(am)][0]); num('GstarAminHi', am[max(am)][0])
num('AminLo', min(am), 1); num('AminHi', max(am), 1)
ce = CAL['cerr_sensitivity']
num('GstarCerrFav', ce['favorable'][1]); num('GstarCerrCons', ce['conservative'][1])
num('GstarCerrHigh', ce['high rates, unit loss'][1]); num('CerrHigh', ce['high rates, unit loss'][0], 1)
ps = CAL['psi_sensitivity']
loss = ps['ceiling_k15_G30_loss']
num('KcapLossNone', loss['none']['0.18'])
num('KcapLossDomLo', min(loss['domestic'].values())); num('KcapLossDomHi', max(loss['domestic'].values()))
num('KcapLossForLo', min(loss['foreign_15y'].values())); num('KcapLossForHi', max(loss['foreign_15y'].values()))
num('PsiAddMax', max(C[c_]['tau'] for c_ in C) * 1.5 * 0.30, 1)    # tau k G at k = 1.5, G = 0.30, largest tau
num('PsiFifteen', ps['psi']['foreign_15y'], 2, pct=False); num('PsiFive', ps['psi']['prior_5y'], 2, pct=False)
cen = C['central']
num('ReplCen', (1 - cen['tau']) * 0.25 * 0.5, 2)       # (1 - tau) delta_K k at delta_K = 0.25, k = 0.5, points
num('OwnMarkupFive', 3.3 * 0.05 / (1 - cen['tau']))    # Remark rem:owncompute: 0.6 x 5.5 x G / (1 - tau)
num('OwnMarkupFifteen', 3.3 * 0.15 / (1 - cen['tau']))

# Rule of 1000 (Proposition prop:saturation(d)) and the duration bound (Corollary cor:transient)
L1000 = {float(k): v for k, v in CAL['Lambda_rule1000'].items()}
num('LamThouLo', L1000[0.45], 1, pct=False); num('LamThouHi', L1000[0.25], 1, pct=False)
lp = CAL['lam_for_Pi']
num('LamPiLo', min(min(v.values()) for v in lp.values()), 2, pct=False)
num('LamPiHi', max(max(v.values()) for v in lp.values()), 2, pct=False)
mult = CAL['rule1000_multiple']
num('PullMultLo', min(min(v.values()) for v in mult.values()), 0, pct=False)
num('PullMultHi', max(max(v.values()) for v in mult.values()), 0, pct=False)


def transient_bound(s0, Rbar=10.0, m0=0.6, G=0.2, X=1.0, k=0.0, sbar=0.5):
    Rinf = m0 + (X - k) * G
    return math.log(sbar / s0) / math.log(1 + (Rbar - Rinf) / ((X - k) * (1 + G)))


put('TransOnePct', str(math.floor(transient_bound(0.01))))         # years at 1,000 points from 1% share
put('TransSmall', str(math.floor(transient_bound(1e-5))))          # from a thousandth of a percent
G_e, r_e, k_e = 0.05, 0.10, 0.5                                     # free-entry example of Proposition prop:entry
num('EntryScore', G_e + (r_e - G_e) * k_e, 1)
num('EntryRent', 1 - (G_e + (r_e - G_e) * k_e), 1)

# ---------------------------------------------------------------------------------------------- anchor
A = CAL['anchor']
put('AnchorN', str(A['n'])); put('AnchorTail', str(A['n_tail'])); put('AnchorAcqExcl', str(A['n_acq_excluded']))
put('AnchorMarginAbove', str(A['n_tail_m_above_p95']))
for nm, key in [('Mzero', 'm0_ub'), ('Dur', 'Rinf_ub'), ('Pi', 'Pi_ub'), ('MzeroLb', 'm0_lb'), ('DurLb', 'Rinf_lb'),
                ('PiLb', 'Pi_lb')]:
    q = A[key]
    num('Anchor' + nm + 'Lo', q[0]); num('Anchor' + nm + 'Med', q[1]); num('Anchor' + nm + 'Hi', q[2])
num('AnchorScoreMed', A['R'][1])
num('AnchorShift', A['shift'])
num('AnchorTransLo', A['Pi_ub'][1] / A['R'][1])                     # share of the median score that is transient
num('AnchorTransHi', A['Pi_lb'][1] / A['R'][1])
num('AnchorGapCen', cen['base'] - A['m0_ub'][1])
num('AnchorGapFav', C['favorable']['base'] - A['m0_ub'][1])
num('AnchorTaxGap', max(ps['anchor_tau_kg']), 1)                     # tau k g at the quartiles, at most (points)

num('MedCostRevenue', 1 - STATS['median_gross_margin_2023_25'])      # median cost of revenue, 2023-25
# firm-level facts about the E2 anchor (notes/calibration_anchor_E2.json, firm_years)
ANC = json.load(open(os.path.join(BASE, 'notes', 'calibration_anchor_E2.json')))
FY = ANC['E2']['firm_years']
def fy(name, year=None):
    return [r for r in FY if r['name'].startswith(name) and (year is None or r['year'] == year)]
clear25 = fy('Clear Secure', 2025)[0]
num('AnchorClearPi', max(clear25['Pi_ub'], clear25['Pi_lb']))         # surplus at most, either bound
big = fy('Palantir', 2025) + fy('Exzeo', 2025)                          # the two largest surpluses
num('AnchorBigPiLo', min(min(r['Pi_ub'], r['Pi_lb']) for r in big)); num('AnchorBigPiHi', max(max(r['Pi_ub'], r['Pi_lb']) for r in big))
mon = fy('monday')
put('AnchorMondayPi', str(math.floor(-100 * max(r['Pi_ub'] for r in mon))))  # scores at least this far below its durable level
num('AnchorMondayMzeroLo', min(r['m0_ub'] for r in mon)); num('AnchorMondayMzeroHi', max(r['m0_ub'] for r in mon))
put('AnchorPiPosShare', fmt(ANC['E2']['share_Pi_ub_positive']))
num('AnchorPiLoAbs', -CAL['anchor']['Pi_ub'][0])                     # a quarter of anchor firm-years are at least this far below
_e1 = {(r['name'], r['year']) for r in ANC['E1']['firm_years']}
_new = [r for r in FY if (r['name'], r['year']) not in _e1]            # firm-years admitted by the lower E2 cut-off
put('AnchorEntrants', str(len(_new))); put('AnchorEntrantsNeg', str(sum(r['Pi_ub'] < 0 for r in _new)))
# E1 comparison (observed-score anchor)
A1 = CAL['anchor_E1']
put('AnchorEoneN', str(A1['n'])); num('AnchorEoneMzeroMed', A1['m0_ub'][1]); num('AnchorEonePiMed', A1['Pi_ub'][1])
num('AnchorEonePiLbMed', A1['Pi_lb'][1]); num('AnchorEoneScoreMed', A1['R'][1])
num('AnchorEoneTransLo', A1['Pi_ub'][1] / A1['R'][1]); num('AnchorEoneTransHi', A1['Pi_lb'][1] / A1['R'][1])
put('AnchorEonePiPosShare', fmt(ANC['E1']['share_Pi_ub_positive']))
num('AnchorPthree', CAL['anchor']['p95']); num('AnchorEonePthree', A1['p95'])
num('AnchorG', CAL['anchor']['G'], 1); num('AnchorEoneG', A1['G'], 1)

# ---------------------------------------------------------------------------------------------- accountability floor
# Illustrative example of Proposition prop:amin (Remark rem:amin-values; checked by code/verify_theory.py 25d, 27c)
def amin_design(nh, na, N=24, L=10e6, ph=0.05, ch=5e5, pch=0.002, pa=0.02, ca=5e4, pca=0.005, itgc=3.5e5):
    P = 1.0
    if nh:
        P *= pch + (1 - pch) * ph ** nh
    if na:
        P *= pca + (1 - pca) * pa ** na
    return (itgc if na else 0.0) + nh * ch + na * ca + N * L * P
REV = 1e9
best_h = min(amin_design(n, 0) for n in range(7)); best_a = min(amin_design(0, n) for n in range(1, 7))
best = min(amin_design(i, j) for i in range(7) for j in range(7))
best_alt = max(min(amin_design(i, j, N=48) for i in range(7) for j in range(7)),
               min(amin_design(i, j, pca=0.01) for i in range(7) for j in range(7)))
direct = (343.0 * 1000 + 1.04e6) / REV                                # audit fees and SOX 404 cost at $1bn
c_line = 30e3 + 120e3 + 100e3 / 1.22 + 55e3 + 4 * 15e3                # ITGC line of one in-scope AI application
c_fb = 161e3                                                          # close fallback (companion paper)
floor0 = direct + best / REV
num('AminHuman', best_h / REV, 2); num('AminAI', best_a / REV, 2); num('AminBest', best / REV, 2)
num('AminAlt', best_alt / REV, 2); num('AminCM', 24 * 10e6 * 0.005 / REV, 2); num('AminDirect', direct, 2)
num('AminFloor', floor0, 2); num('ItgcLine', c_line / REV, 3); num('ItgcLineFb', (c_line + c_fb) / REV, 2)
put('ItgcApps', str(1 + math.ceil((0.005 - floor0) / (c_line / REV))))
put('ItgcAppsFb', str(1 + math.ceil((0.005 - floor0 - c_fb / REV) / ((c_line + c_fb) / REV))))

# ---------------------------------------------------------------------------------------------- pace
P = CAL['pace']
for tag, key in [('Cen', 'central'), ('Fast', 'fast')]:
    pc = P[key]; prm = pc['params']
    num('PaceCap' + tag, prm['kappa_abs'])
    num('PaceSucc' + tag, prm['varpi'], 2, pct=False)
    num('PaceDisr' + tag, pc['nuD'], 2, pct=False)
    num('PaceEmb' + tag, prm['Temb'], 0, pct=False)
    num('PaceReal' + tag, prm['bbar'])
    num('PaceFrz' + tag, (pc['clock'] - 1) / pc['clock'])
    num('PaceQ' + tag, pc['q'], 2, pct=False)
    num('PaceRate' + tag, pc['eff_rate'], 1)
    num('PaceDip' + tag, pc['2028']['dip'], 1)
    for y, yn in [('2028', 'Eight'), ('2031', 'One'), ('2036', 'Six')]:
        num('Pace' + tag + yn, pc[y]['s'], 1 if pc[y]['s'] < 0.05 else 0)
put('PaceNproc', str(P['central']['params']['n_proc']))
put('PaceFastDone', str(math.floor(P['fast']['complete_year'] + 0.5)))
assert P['central']['cross_years'] is not None
put('PaceCrossCen', str(math.floor(P['central']['cross_years'] + 0.5)))
slow = CAL['variants']['slow_public']
num('PaceCapSlow', slow['rho_chg'])
V = CAL['variants']
num('VarDipOneShare', V['public_guided_dip_1pt']['2036']['s'])
num('VarDipTwoShare', V['public_guided_dip_2pt']['2036']['s'])
num('VarDipOneInit', V['public_guided_dip_1pt']['a0_share'])
num('VarDipOneMzero', V['public_guided_dip_1pt']['m0']['2036'] - A['m0_ub'][0])
num('VarCenMzero', V['central_fluid']['m0']['2036'] - A['m0_ub'][0])
assert V['slow_public']['2036']['s'] < 0.01
num('VarSlowShare', V['slow_public']['2036']['s'], 1)

# ---------------------------------------------------------------------------------------------- horizons
YN = [('2028', 'Eight'), ('2031', 'One'), ('2036', 'Six')]
for y, yn in YN:
    ub = CAL['upper_bound'][y]; lb = CAL['lower_bound'][y]
    for b, tag in [(ub, 'Ub'), (lb, 'Lb')]:
        num(tag + yn + 'Lo', b['0.0']['R'][0]); num(tag + yn + 'Hi', b['0.0']['R'][1])
        num(tag + 'Dur' + yn + 'Lo', b['0.0']['Rinf'][0]); num(tag + 'Dur' + yn + 'Hi', b['0.0']['Rinf'][1])
    num('Hz' + yn + 'Lo', min(ub['0.0']['R'][0], lb['0.0']['R'][0]))
    num('Hz' + yn + 'Hi', max(ub['0.0']['R'][1], lb['0.0']['R'][1]))
    num('HzDur' + yn + 'Lo', min(ub['0.0']['Rinf'][0], lb['0.0']['Rinf'][0]))
    num('HzDur' + yn + 'Hi', max(ub['0.0']['Rinf'][1], lb['0.0']['Rinf'][1]))
    num('Kh' + yn + 'Lo', ub['0.5']['R'][0]); num('Kh' + yn + 'Hi', ub['0.5']['R'][1])
    kd = ps['k05_upper_bound']['domestic'][y]
    num('Kd' + yn + 'Lo', kd[0]); num('Kd' + yn + 'Hi', kd[1])

# ---------------------------------------------------------------------------------------------- acquired growth
# The treadmill of Proposition prop:acquired-score(f): the existing subscription base shrinks at -G_i = -ln NRR a year.
# Read from sections/tables/acquired_macros.tex (generated by code/verify_part2_acquirer.py from the F-1 extract).
acq_path = os.path.join(BASE, 'sections', 'tables', 'acquired_macros.tex')
if os.path.exists(acq_path):
    acq = dict(re.findall(r'\\providecommand\{\\(acq[A-Za-z]+)\}\{(.*)\}', open(acq_path).read()))
    gi = []
    for key in ['acqGiTwentyFour', 'acqGiTwentyFive']:
        v = acq[key].replace('\\ensuremath{-}', '-').replace('\\%', '')
        gi.append(-float(v))
    put('AcqTreadLo', f"{min(gi):.1f}"); put('AcqTreadHi', f"{max(gi):.1f}")

# ---------------------------------------------------------------------------------------------- write macros
os.makedirs(OUT_DIR, exist_ok=True)
lines = ['% Generated by code/paper1_macros.py from notes/calibration_results.json, notes/paper_stats.json,',
         '% notes/empirics_revised.json, notes/gap_decomposition.json and data/panel*.csv. Do not edit by hand.',
         '% Values are rounded half up; percentages are given without the percent sign.']
for k, v in M.items():
    lines.append(f"\\newcommand{{\\{k}}}{{{v}}}")
open(os.path.join(OUT_DIR, 'macros.tex'), 'w').write('\n'.join(lines) + '\n')

# ---------------------------------------------------------------------------------------------- plain abstract
src = open(os.path.join(BASE, 'sections', 'abstract.tex')).read()
body = src.split(r'\begin{abstract}', 1)[1].split(r'\end{abstract}', 1)[0]
body = re.sub(r'(?<!\\)%.*', '', body)                       # comments
body = body.replace(r'\noindent', '')


def expand(m):
    name = m.group(1)
    if name not in PLAIN:
        sys.exit(f"abstract uses undefined macro \\{name}")
    return PLAIN[name]


body = re.sub(r'\\(emph|textit|textbf)\{([^}]*)\}', r'\2', body)
if re.search(r'\\cite', body):
    sys.exit('the abstract must not cite')
body = re.sub(r'\\([A-Za-z]+)(\{\})?', expand, body)
body = (body.replace(r'\%', '%').replace('---', ' - ').replace('--', '-').replace('~', ' ')
        .replace(r'\$', '$').replace('$', '').replace(r'\,', ' ').replace('{,}', ','))
body = re.sub(r'\s+', ' ', body).strip()
if '\\' in body or '{' in body:
    sys.exit(f"unconverted LaTeX in abstract: {body}")
open(os.path.join(OUT_DIR, 'abstract_plain.txt'), 'w').write(body + '\n')
n = len(body)
print(f"wrote {len(M)} macros to paper1/macros.tex; abstract {n} characters (limit {MAX_ABSTRACT})")
if n > MAX_ABSTRACT:
    sys.exit(f"abstract too long: {n} > {MAX_ABSTRACT}")
