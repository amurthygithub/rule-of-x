"""Calibrate the maximal Rule-of-40 score by horizon (fourth revision: full cost, capacity, risk and transition dips).

Model: R* = R_inf + Pi with R_inf = m0 + (1-k) G (durable part) and Pi the transient growth surplus, X = 1,
free-cash-flow-after-SBC basis (Proposition score, Remark taxes). A firm still transforming at the horizon scores
lower by the in-flight dip d (Propositions tasks-scorepath and ext-waves(f)), which is reported separately.

Anchor (revision v2 of Paper 1, decision D-3: the E1 calibration rule is central, read from
notes/calibration_anchor_v3.json, the audited sample of code/estimate_v3.py; the all-tail E1, the organic E2 and the two
imputation bounds are sensitivity rows; set P1_V3_DIR to read a pinned snapshot of the v3 outputs). The data identify neither alpha nor lambda*h (Section 5), and a single
cross-firm intercept is infeasible for firms whose margins exceed it. We therefore invert the model firm by firm for the
top tail of 2023-25: firm-years at or above the 95th percentile of the cash-basis score, excluding acquisition-affected
firm-years (purchased growth is not the growth the model describes). On the after-tax cash basis, m = m0 - (1-tau) sigma
- k g (Remark taxes with psi = 0: growth spend is deductible, growth capital is not), so m0 = m + (1-tau) sigma + k g.
Growth spend sigma is bounded: the selling-and-marketing share is an upper bound (all S&M buys growth) and zero a lower
bound (none does). A firm-year that does not report S&M is treated as having none. Then R_inf = m0 + (1-k) G and
Pi = R - R_inf.

Horizons (new in this revision). The margin intercept is no longer a scenario range. It moves from the anchor toward the
full-cost margin term of Corollary ceiling (Table tab:ceiling, Appendix tab:fullcost) at the pace that the attainable and
expected frontiers allow (Propositions attainable and expected):
  m0(h) = m0_A + s(h) [m0_F - m0_A],
  s(h)  = bbar * min{1, q rho T_par n(t_R)},  t_R = (h - 2025)/(1 + nu_R T_frz),
  n(t)  = floor((t - T_emb)/T_par) + 1 for t >= T_emb (waves embedded by t),
  q     = varpi (params commit of 29 Oct 2026: varpi and bbar come from outcome surveys, which already include
          disruptions, so the haircut exp(-nu_D T_emb), nu_D = nu_L (1 - kappa_keep) + nu_V, is not applied; nu_D is
          kept for the shock-timing results),
  rho   = min{change capacity, decision capacity, security-review capacity}, as shares of the program a year.
The full-cost margin term m0_F is horizon-specific (compute share c_c by horizon, CC below), and pass-through phi is a
scenario dimension (PHI below; phi = 0 is the fixed-prices case of Table tab:calib).
The high end of each range pairs the anchor's upper quartile with the favorable full-cost term and the fast pace; the
low end pairs the lower quartile with the central full-cost term and the central pace (an exceptional firm executes at
least as well as a typical one). The dip of a firm still transforming at h is d = a_r T_pb [m0_F - m0_A], with attempt
rate a_r = rho/(1 + nu_R T_frz) and one-time plus parallel-run costs of T_pb years of the savings attempted, as long as
the program has not been completed (expected embedded share below one).
  Pi scales the 2025 interquartile range by mu^(1/(1-alpha)) (demand pull relative to 2025) and by (1-k)^(1/(1-alpha)).
The lower-bound case shifts every m0 down by the anchor's median difference between the two bounds and scales the
lower-bound Pi, as in the third revision. Regime variants: a public firm that holds to a guided dip (Proposition
reg-dip), and a sponsor's faster decisions where decision bandwidth binds (Proposition reg-speed(c)).
The third-revision ranges (fixed m0 scenarios 40-62, 45-65, 50-69) are recomputed and stored under 'previous' so the
memo can report old and new numbers side by side.

Tax deductions for capital (Remark taxes; Part II Proposition acct-tax). The table keeps psi = 0 (capital not
deductible), which suits working capital and is a lower bound. Under current U.S. law domestic research and experimental
expenditure, including software development, is deducted when incurred (26 U.S.C. 174A, tax years beginning after
31 Dec 2024) and equipment acquired after 19 Jan 2025 takes the 100% allowance (IRS Notice 2026-11), so psi = 1; foreign
research is amortized over 15 years from the midpoint (26 U.S.C. 174), psi_15 = 0.532 at r = 0.10; the 2022-2024
five-year regime had psi_5 = 0.796. Block 'psi_sensitivity' reports the anchor intercepts, the k = 0.5 column and the
capital term of the ceiling under each.
"""
import json
import math
import os
import numpy as np
import pandas as pd

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # replication-package root
V3DIR = os.environ.get('P1_V3_DIR')                  # pinned snapshot of the v3 outputs (see code/paper1_macros.py)


def v3path(kind, name):
    return os.path.join(V3DIR, name) if V3DIR else os.path.join(BASE, kind, name)


TAU = 0.18                                          # central cash tax rate, Table ceiling


def psi_T(T, r=0.10):
    """PV per dollar of deductions taken ratably over T years from the midpoint of the first year (Prop. acct-tax(a))."""
    return (1 + (1 + r) ** (-T)) / (2 * T) + (1 - (1 + r) ** (-(T - 1))) / (r * T)


PSI = {'none': 0.0, 'foreign_15y': psi_T(15), 'prior_5y': psi_T(5), 'domestic': 1.0}
ALPHAS = [0.25, 0.45]
H0 = 2025                                           # end of the anchor period; the program starts after it

# ----------------------------------------------------------------------------------------------
# Full-cost margin terms (Corollary ceiling, Definition fullcost). The inputs duplicate those of
# code/verify_theory.py section 20, which checks that this script's JSON reproduces them.
# ----------------------------------------------------------------------------------------------
S_REF = 1e9                                         # reference revenue for fixed and per-process costs, $
WAGE_GOV = 88400 * (1 + 0.4287)                     # compliance officer (SOC 13-1041) mean wage, OEWS May 2025, loaded (ECEC)

# ----------------------------------------------------------------------------------------------
# Compute share at full automation, by horizon (params commit of 29 Oct 2026; notes/assumptions_round2.md Section 2).
# The same values are in data/tasks/params.yaml part1_ceiling.c_c_compute_share (engine tests/test_regression.py checks
# that they agree). c_c(H) = s_L x kappa(H): s_L the labor cost the ceiling automates (share of revenue), kappa the
# compute cost per dollar of labor replaced (retries, verification, orchestration; human review is priced in a_min and
# the full-cost floors). Explicit path:
#   kappa(H) = omega_H kappa_front + (1 - omega_H) kappa_fixed(H),  kappa_fixed(H) = max(kappa_2025 / D^(H - 2025),
#              floor_share kappa_2025),
# with s_L 0.60 [0.50, 0.65] (c), kappa_2025 0.10 [0.01, 0.35] (b: METR run costs, Stevens 2026, AI-native products),
# D = 5 [3, 10] a year (a: Gundlach et al. 2026), kappa_front 0.33 [0.10, 0.50] (d, capped by the value test kappa < 1),
# omega_H the share of automated labor cost in tasks reached within two years of H (d), floor_share 0.005 (d).
# Values (value, credible bounds, class): sources read 29 Oct 2026.
# ----------------------------------------------------------------------------------------------
CC_PATH = dict(s_L=0.60, kappa_2025=0.10, D=5.0, floor_share=0.005, kappa_front=0.33,
               omega={'2028': 0.6, '2031': 0.4, '2036': 0.25})


def cc_path(h):
    """c_c of the explicit path for horizon h ('2028', '2031', '2036'), or at 2025 prices for h = 'prices2025'."""
    c = CC_PATH
    if h == 'prices2025':
        return c['s_L'] * c['kappa_2025']
    om = c['omega'][h]
    k_fixed = max(c['kappa_2025'] / c['D'] ** (int(h) - H0_PRICES), c['floor_share'] * c['kappa_2025'])
    return c['s_L'] * (om * c['kappa_front'] + (1 - om) * k_fixed)


H0_PRICES = 2025
CC = {'prices2025': (0.06, (0.01, 0.20), 'b'),       # 2025 prices, no price path (b-anchored); the static ceiling
      '2028': (0.12, (0.02, 0.30), 'd'), '2031': (0.08, (0.01, 0.25), 'd'), '2036': (0.05, (0.01, 0.20), 'd')}
assert all(abs(cc_path(h) - v[0]) < 0.005 for h, v in CC.items()), 'compute-share path and CC centrals disagree'
# Cases. c_c is a class d composite at every horizon (and b-anchored only at 2025 prices), so by the rule below the
# favorable and conservative cases take the central value halved and doubled; the credible bounds above are the
# scenario bounds of the sensitivity (cc_sensitivity). The 0.40 high-compute case of earlier drafts exceeds the
# value-test cap s_L x 0.5 = 0.30, so it is kept only for comparison and labelled infeasible at full automation.
CC_CASES = {h: (v[0] / 2, v[0], 2 * v[0]) for h, v in CC.items()}
CC_HIGH = 0.40
CC_VALUE_TEST_CAP = CC_PATH['s_L'] * 0.5

FC = {  # favorable, central, conservative; c_c by horizon is in CC_CASES; the high-compute case uses central values
    # Rules (Appendix Table tab:fullcost): factors with a sourced or precedent range (classes a to c in
    # notes/assumptions_register.md) take its low end, central value and high end; scenario (class d) composites take a
    # central value from the stated structure, halved and doubled.
    'c_c': CC_CASES['prices2025'], 'f': (0.02, 0.025, 0.03), 'tau': (0.15, 0.18, 0.21),
    'a_min': (0.015, 0.03, 0.046),                  # register band [0.005, 0.046] (b); the third revision used 6%
    # c_sec: risk cost of Proposition tasks-security(b) scaled from today's spend, plus PQC and AI compliance
    's0': (0.0069, 0.0069, 0.0069),                 # security spend, share of revenue (IANS 2025; a, flagged)
    'L0': (4.0, 2.0, 1.0),                          # ln(C_inc/C_s): controls remove 98, 86, 63% of expected loss (d)
    'Me': (1.0, 2.0, 3.0),                          # exposure multiplier at full automation (params autonomy multipliers, d)
    'sec_it': (0.119, 0.099, 0.086),                # security share of IT spend (IANS 2024, 2026, 2020; a)
    'phi_pqc': (0.0075, 0.015, 0.03),               # PQC migration a year, share of IT spend (d)
    'aic_fixed': (12e3 + 10e3 + 2.5e3 + (5e3 + 13e3) / 3 + 0.10 * WAGE_GOV,
                  30e3 + 35e3 + 6e3 + (13.5e3 + 30e3) / 3 + 0.25 * WAGE_GOV,
                  150e3 + 60e3 + 9e3 + (20e3 + 50e3) / 3 + 1.00 * WAGE_GOV),   # SOC 2, ISO 42001, NIST AI RMF ($/yr)
    'aic_pp': (0.5, 1.0, 2.0),                      # factor on 48 processes x ($30k red team + $10k PIA / T_up) (d)
    # c_mnt: (delta_M + kappa_reval / T_up) x build stock per revenue
    'delta_M': (0.10, 0.17, 0.40),                  # register: 0.17 [0.10, 0.40] (b)
    'kappa_rv': (0.05, 0.10, 0.20),                 # d
    'T_up': (1.75, 1.22, 0.99),                     # c: median GA model life from 2025; 0.99 = shortest observed
    'B': (0.012, 0.024, 0.048),                     # 48 processes x $0.5M (b) at $1B revenue (d)
    # c_err = errors and hallucination + misbehavior (Proposition tasks-cerr) + common-mode (Proposition ext-commonmode(a));
    # rates from data/tasks/params_reliability.yaml (a, b), loss severities and exposure scenario (d)
    'A_auto': (0.30, 0.30, 0.30),                   # in-house cost of the automated work, share of revenue (d)
    # no review at full automation (Lemma fullcost(c), FI-5): the measured catch rates are those of human reviewers, so
    # the ceiling uses the no-review rate e_o + e_h; AI review would lower it at most to chi(e_o + e_h), with its
    # compute in c_c. Omission 0.0345 in every case; hallucination 0.015 (favorable) and 0.05 (central, conservative:
    # worse rates fail the scope test of Lemma fullcost(c))
    'u_rev': (0.0345 + 0.015, 0.0345 + 0.05, 0.0345 + 0.05),
    'ell_e': (0.25, 0.5, 1.0),                      # loss per undetected error, multiple of the unit's in-house cost (d)
    'mu_m': (0.0005, 0.001, 0.002),                 # consequential misbehavior per task (d; file range 5e-5 to 1e-2)
    'd_m': (0.95, 0.60, 0.42),                      # monitor recall (a)
    'ell_m': (10.0, 10.0, 10.0),                    # loss scale per event, multiple of the unit's in-house cost (d)
    'p_tail': (2.3, 1.5, 1.15), 'Zcap': (100.0, 100.0, 100.0),   # Pareto tail index (b); least-privilege cap (d)
    'nu_cm': (0.5, 2.0, 6.0),                       # provider day-equivalent incidents a year (b)
    'XY': (1.0, 1.0, 1.0),                          # exposure X = A_auto, X/(2 Y_f) = 1, single provider H = 1 (d)
    # c_anc: management of AI spend (FinOps, which for API spend also covers vendor management) and fixed costs
    's_fin': (0.015, 0.03, 0.06),                   # d
    'anc_fixed': (62.5e3, 125e3, 250e3),            # incident-response retainer and legal review of 5 AI vendors (d)
}


def fullcost(case, h='prices2025'):
    """Full-cost floors and the ceiling's margin term for a case at horizon h (compute share CC_CASES[h])."""
    i = {'favorable': 0, 'central': 1, 'conservative': 2, 'high compute': 1}[case]
    v = {k: val[i] for k, val in FC.items()}
    v['c_c'] = CC_CASES[h][i]
    if case == 'high compute':
        v['c_c'] = CC_HIGH
    risk = v['s0'] / v['L0'] * (1 + v['L0'] + math.log(v['Me']))
    pqc = v['phi_pqc'] * v['s0'] / v['sec_it']
    aic = (v['aic_fixed'] + v['aic_pp'] * 48 * (30e3 + 10e3 / 1.22)) / S_REF
    c_sec = risk + pqc + aic
    c_mnt = (v['delta_M'] + v['kappa_rv'] / v['T_up']) * v['B']
    Emin = 1 + (1 - v['Zcap'] ** (1 - v['p_tail'])) / (v['p_tail'] - 1)
    c_err_e = v['A_auto'] * v['u_rev'] * v['ell_e']
    c_err_m = v['A_auto'] * v['mu_m'] * (1 - v['d_m']) * v['ell_m'] * Emin
    c_err_cm = v['nu_cm'] / 365 * v['A_auto'] * (1 + v['XY'])
    c_err = c_err_e + c_err_m + c_err_cm
    c_anc = v['s_fin'] * v['c_c'] + v['anc_fixed'] / S_REF
    c_full = c_mnt + c_sec + c_err + c_anc
    base = (1 - v['tau']) * (1 - v['c_c'] - v['f'] - v['a_min'] - c_full)
    base_acc = (1 - v['tau']) * (1 - v['c_c'] - v['f'] - v['a_min'])
    out = dict(c_c=v['c_c'], f=v['f'], a_min=v['a_min'], tau=v['tau'], risk=risk, pqc=pqc, aic=aic, c_sec=c_sec,
               c_mnt=c_mnt, c_err=c_err, c_err_e=c_err_e, c_err_m=c_err_m, c_err_cm=c_err_cm, c_anc=c_anc,
               c_full=c_full, base=base, base_acc=base_acc, G100=1 - base, G100_acc=1 - base_acc, horizon=h)
    if case == 'high compute':
        out.update(feasible_at_full_automation=CC_HIGH <= CC_VALUE_TEST_CAP, value_test_cap=CC_VALUE_TEST_CAP)
    return out


CASES = ['favorable', 'central', 'conservative', 'high compute']
CEIL = {c: fullcost(c) for c in CASES}               # static ceiling (Table tab:ceiling) at 2025 prices
CEIL_H = {h: {c: fullcost(c, h) for c in CASES} for h in ['2028', '2031', '2036']}   # by horizon (price path)
M0_FAV = {h: CEIL_H[h]['favorable']['base'] for h in CEIL_H}   # favorable full-cost margin term, by horizon
M0_CEN = {h: CEIL_H[h]['central']['base'] for h in CEIL_H}     # central full-cost margin term, by horizon
M0_CAP_OLD = (1 - 0.15) * (1 - 0.15 - 0.02 - 0.015) # third revision: favorable accountability-only margin term

# ----------------------------------------------------------------------------------------------
# Pass-through (params commit of 29 Oct 2026; notes/assumptions_round2.md Section 4). Scenario dimension phi, the
# industry pass-through of variable-cost savings (c_h and c_c; the non-discretionary cost a is not passed through),
# entering through the competition result of the companion paper and the engine: the firm keeps
# dur = 1 - phi (1 - HHI) of a saving every rival makes (theory_competition.tex eq:ext-game-dur; engine
# formulas.game_shares). phi = 0 is the fixed-prices case, reported beside the others. Anchors (b, read 29 Oct 2026):
# 0 to 0.1 for differentiated software in the short run (Apple/Analysis Group DMA study, 2025), 0.7 for an
# industry-wide cost shock (Ganapati, Shapiro and Walker 2020), 0.5 the central medium-run case. HHI = 0.25 is the
# engine's competition.hhi (four symmetric incumbents; class d). The saving passed through is today's non-fee unit
# cost of revenue of the median core firm in 2023-25, U0 = 1 - gamma0 - f, less the compute share that replaces it.
# ----------------------------------------------------------------------------------------------
PHI = (0.0, 0.5, 0.7)
HHI = 0.25


def dur(phi, hhi=HHI):
    return 1.0 - phi * (1.0 - hhi)

# ----------------------------------------------------------------------------------------------
# Pace and risk (Assumption program, Definition attainable(b), Proposition expected(c)). Values adopted by the params
# commit of 29 Oct 2026 (notes/assumptions_round2.md Sections 1.1 to 1.6; the same values are in data/tasks/params.yaml
# project_outcomes and change_capacity); sources read 29 Oct 2026:
#   change capacity kappa_abs 0.10 [0.05, 0.22] (b: WEF Future of Jobs 2025, about 12% of workers' work changes a year;
#     one-year reductions in filings 6 to 22%, Meta 2023 the high end; JOLTS layoffs 1% a month);
#   varpi, the probability that a funded transition creates value: 0.70 [0.54, 0.80] (b: BCG 2020, 30% win + 44% worry
#     zone = 74% created value, rounded down for self-report; low end S&P Global pilot attrition 0.54, high end BCG's
#     six-factor rate 0.80);
#   bbar, the share of targeted value realized: 0.67 [0.37, 0.85] (a, flagged: McKinsey 2021, n = 1,034, successful
#     transformations 67%, all others 37%, top quartile the high end);
#   T_emb = T_pb, the payback date including the parallel run: 1.25 [1, 2] years (b: Salesforce workforce actions
#     substantially complete about 13 months after announcement; McKinsey half of value within 18 months);
#   q = varpi, without the disruption haircut exp(-nu_D T_emb): varpi and bbar come from outcome surveys, which already
#     include leadership changes and strategy shifts, so the haircut would count them twice (it took q from 0.54 to 0.34).
#     nu_D = nu_L (1 - kappa_keep) + nu_V is kept and reported for the shock-timing results (Proposition ext-shocks):
#     nu_L sponsor hazard 0.204 [0.15, 0.30] (Korn Ferry C-suite tenure; practitioner data); kappa_keep 0.60 [0.30, 0.85]
#     (d), nu_V 0.15 [0.05, 0.30] (d);
#   nu_R 0.46 [0.30, 0.60] (b, flagged), T_frz 0.25 [0.08, 1.0] (b, flagged); T_par 0.17 [0.08, 0.42] (b: AI shadow mode
#     up to about five months); concurrent initiatives Phi 5 [3, 10] and decision units e 1 [0.5, 2] (d); load
#     breakpoints 0.70 and 0.78 for latency factors 1.0 and 0.5 (Proposition reg-speed(c)); security reviews 10 [5, 20]
#     per reviewer-quarter (d), two reviewers.
# The fast case takes the favorable end of every range and the slow case the unfavorable end. The central path is
# "AI migration only": the revealed pace of cost programs (REVEALED_PACE below) is reported beside it, not added to it.
# Set 'haircut': True in a case to restore q = varpi exp(-nu_D T_emb) (for inputs that are not outcome-survey based).
# ----------------------------------------------------------------------------------------------
N_PROC = 48
PACE = {
    'fast':    dict(kappa_abs=0.22, varpi=0.80, bbar=0.85, nuL=0.15, kkeep=0.85, nuV=0.05, nuR=0.30, Tfrz=0.08,
                    Tpar=0.08, Temb=1.0, Tpb=1.0, Phi=10, e=0.5, kap=0.70, sec=20 * 4 * 2, haircut=False),
    'central': dict(kappa_abs=0.10, varpi=0.70, bbar=0.67, nuL=0.204, kkeep=0.60, nuV=0.15, nuR=0.46, Tfrz=0.25,
                    Tpar=0.17, Temb=1.25, Tpb=1.25, Phi=5, e=1.0, kap=0.70, sec=10 * 4 * 2, haircut=False),
    'slow':    dict(kappa_abs=0.05, varpi=0.54, bbar=0.37, nuL=0.30, kkeep=0.30, nuV=0.30, nuR=0.60, Tfrz=1.00,
                    Tpar=0.42, Temb=2.0, Tpb=2.0, Phi=3, e=2.0, kap=0.70, sec=5 * 4 * 2, haircut=False),
}
# Values before the params commit (third and fourth revisions), recomputed under 'pace_previous' for comparison only
PACE_PREVIOUS = {
    'fast':    dict(PACE['fast'], kappa_abs=0.20, varpi=0.80, bbar=1.00, Temb=1.0, Tpb=1.0, haircut=True),
    'central': dict(PACE['central'], kappa_abs=0.10, varpi=0.54, bbar=0.85, Temb=2.0, Tpb=2.0, haircut=True),
    'slow':    dict(PACE['slow'], kappa_abs=0.05, varpi=0.30, bbar=0.50, Temb=3.0, Tpb=3.0, haircut=True),
}
# Revealed pace of cost programs (class c reference, not a model input; assumptions round 2 Section 1.5): own calculation
# on data/panel_v2_all.csv, SIC 7372, FY2022 revenue >= $100M, change FY2022 to FY2024, percentage points. Flag: to
# recompute on panel_v3 (computed on panel_v2, which the IM-1 sample audit is rebuilding).
REVEALED_PACE = dict(
    grounding='c', flag='to recompute on panel_v3', basis='data/panel_v2_all.csv, SIC 7372, FY2022 revenue >= $100M, FY2022-FY2024',
    gaap_op_margin=dict(n=149, p10=-7.8, p25=2.1, median=7.5, p75=21.5, p90=36.0),
    fcf_sbc_margin=dict(n=145, p10=-6.3, p25=1.3, median=9.5, p75=23.5, p90=35.4),
    gm_less_ga=dict(n=129, p10=-2.8, p25=0.4, median=3.8, p75=8.0, p90=13.0),
    spend_shares_median=dict(sm=-3.7, rd=-1.2, ga=-1.5, sbc=-0.9))
YEARS = [2028, 2031, 2036]


def rates(p, kap=None):
    kap = p['kap'] if kap is None else kap
    rho_chg = p['kappa_abs']
    rho_dec = kap * p['Phi'] / (N_PROC * p['e'] * p['Tpar'])
    rho_sec = p['sec'] / N_PROC
    rho = min(rho_chg, rho_dec, rho_sec)
    binding = ['change', 'decision', 'security'][int(np.argmin([rho_chg, rho_dec, rho_sec]))]
    nuD = p['nuL'] * (1 - p['kkeep']) + p['nuV']
    slow = 1 + p['nuR'] * p['Tfrz']
    # survival of a flight that lasts (1 + nu_R T_frz) T_emb in calendar time (Definition attainable(b)); applied only
    # when 'haircut' is set (outcome-survey rates already include disruptions)
    surv = math.exp(-nuD * slow * p['Temb'])
    q = p['varpi'] * (surv if p.get('haircut', False) else 1.0)
    return dict(rho=rho, binding=binding, rho_chg=rho_chg, rho_dec=rho_dec, rho_sec=rho_sec, nuD=nuD, q=q,
                q_with_dilated_haircut=p['varpi'] * surv, disruption_haircut_applied=bool(p.get('haircut', False)),
                clock=slow, eff_rate=q * rho / slow, eff_rate_realized=p['bbar'] * q * rho / slow, attempt_rate=rho / slow)


def _dM_at(dM, h):
    """dM is one number, or a dict {horizon year: dM} (the full-cost margin term moves with the compute share)."""
    return dM[h] if isinstance(dM, dict) else dM


def pace(p, dM, kap=None):
    """Waves of Assumption program: expected embedded share s (Proposition expected(c), greedy plan) and the in-flight
    dip by horizon. Waves of length T_par in program time t_R = t/(1 + nu_R T_frz); n(t_R) waves embedded by t."""
    out = rates(p, kap)
    for h in YEARS:
        tR = (h - H0) / out['clock']
        n = 0 if tR < p['Temb'] else math.floor((tR - p['Temb']) / p['Tpar'] + 1e-12) + 1
        raw = out['q'] * out['rho'] * p['Tpar'] * n
        done = raw >= 1
        out[h] = dict(n=n, s=p['bbar'] * min(1.0, raw), running=not done,
                      dip=0.0 if done else out['attempt_rate'] * p['Tpb'] * _dM_at(dM, h))
    # Derived dates quoted in Paper 1 (read by code/paper1_macros.py). With the greedy plan each embedded wave adds
    # step = q rho T_par to the expected embedded share (before bbar). complete_year: the calendar date at which the
    # program is embedded in expectation; cross_years: years after H0 at which the embedded gain bbar E dM first
    # exceeds the in-flight dip a_r T_pb dM (None if it never does while the program runs).
    step = out['q'] * out['rho'] * p['Tpar']
    n_full = math.ceil(1 / step - 1e-9)
    out['complete_year'] = H0 + out['clock'] * (p['Temb'] + (n_full - 1) * p['Tpar'])
    n_cross = math.floor(out['attempt_rate'] * p['Tpb'] / (p['bbar'] * step)) + 1
    out['cross_years'] = (out['clock'] * (p['Temb'] + (n_cross - 1) * p['Tpar'])
                          if n_cross < n_full else None)
    out['params'] = dict(p, dM=dM, n_proc=N_PROC)
    return out


def pace_fluid(p, dM, kap=None, dip_budget=None, dt=1 / 365):
    """Fluid version in program time, optionally with a dip budget (a public firm that holds to a guided dip,
    Proposition reg-dip): the calendar flow change bbar E dM - a T_pb dM/clock may not fall below -dip_budget, so the
    attempt rate a <= clock (dip_budget + bbar E dM)/(T_pb dM), and a <= rho; E(t) = q x (share attempted by t - T_emb)."""
    out = rates(p, kap)
    rho, q, clock = out['rho'], out['q'], out['clock']
    nT = int(round(((max(YEARS) - H0) / clock) / dt)) + 2
    lag = int(round(p['Temb'] / dt))
    cum = np.zeros(nT + 1)            # cumulative share attempted
    a_hist = np.zeros(nT + 1)
    # dM by calendar date: linear between the horizons, flat before the first (the compute share moves along its path)
    dM_t = (lambda t: float(np.interp(t, YEARS, [dM[h] for h in YEARS]))) if isinstance(dM, dict) else (lambda t: dM)
    for i in range(nT):
        E = min(1.0, q * (cum[i - lag] if i >= lag else 0.0))
        dMi = dM_t(H0 + i * dt * clock)
        if q * cum[i] >= 1.0:          # enough attempts made: the program winds down
            a = 0.0
        else:
            a = rho if dip_budget is None else min(rho, clock * (dip_budget + p['bbar'] * E * dMi) / (p['Tpb'] * dMi))
        a_hist[i] = a
        cum[i + 1] = cum[i] + a * dt
    for h in YEARS:
        i = int(round(((h - H0) / clock) / dt))
        E = min(1.0, q * (cum[i - lag] if i >= lag else 0.0))
        out[h] = dict(s=p['bbar'] * E, attempt_rate=a_hist[i], dip=a_hist[i] / clock * p['Tpb'] * _dM_at(dM, h),
                      running=a_hist[i] > 0)
    out['a0_share'] = a_hist[0] / rho                  # initial attempt rate as a share of the unconstrained one
    return out


# ----------------------------------------------------------------------------------------------
# Anchor (revision v2, D-3). Central: the E1 calibration rule, the 2023-25 firm-years of the audited sample (v3) at or
# above the 95th percentile of the cash score, without acquisition-affected firm-years; notes/calibration_anchor_v3.json
# (code/estimate_v3.py) holds it with the sensitivity blocks (E1all: every firm-year in the tail; E2, the organic sample;
# E2imp4 and E2imp8, the imputation bounds) and firm-cluster bootstrap intervals. The E1 block is reproduced below from
# data/panel_v3.csv. Only the lower-bound surplus Pi_lb > 0 is a conclusion; the upper-bound surplus has an interval
# that includes zero in every view (notes/inference_v3.md section 12).
# ----------------------------------------------------------------------------------------------
_av = json.load(open(v3path('notes', 'calibration_anchor_v3.json')))
d = pd.read_csv(v3path('data', 'panel_v3.csv'))
# Revealed pace of cost programs, recomputed on the audited panel (the flag of the params commit): change in the GAAP
# operating margin and in the FCF-after-SBC margin between fiscal 2022 and 2024 of the core firms with fiscal-2022
# revenue of at least $100 million, percentage points. A reference beside the central path, not a model input.
_r22 = d[(d.year == 2022) & (d.rev >= 1e8)][['cik', 'm_op', 'm_fcf_sbc']]
_r24 = d[d.year == 2024][['cik', 'm_op', 'm_fcf_sbc']]
_rv = _r22.merge(_r24, on='cik', suffixes=('_22', '_24'))
_qs = lambda x: dict(n=int(x.notna().sum()), **{nm: float(np.floor(10 * x.quantile(qq) + 0.5) / 10)
                                               for nm, qq in [('p10', .1), ('p25', .25), ('median', .5), ('p75', .75), ('p90', .9)]})
REVEALED_PACE_V2 = REVEALED_PACE
REVEALED_PACE = dict(grounding='c', basis='data/panel_v3.csv, core firms, FY2022 revenue >= $100M, FY2022-FY2024',
                     gaap_op_margin=_qs(100 * (_rv.m_op_24 - _rv.m_op_22)),
                     fcf_sbc_margin=_qs((100 * (_rv.m_fcf_sbc_24 - _rv.m_fcf_sbc_22)).dropna()),
                     previous_v2=REVEALED_PACE_V2)
# Grounding of the a_min band in the audited core sample (revision plan D8; the band itself is the params commit's): the
# 5th-percentile G&A share of firm-years with $1-10 billion of revenue and the 10th percentile above $10 billion, 2010-25.
_ga = d[d.ga.notna() & (d.rev > 0)].assign(gas=lambda x: x.ga / x.rev)
AMIN_GROUNDING = dict(basis='data/panel_v3.csv, 2010-25, G&A / revenue',
                      p5_1to10bn=float(_ga[(_ga.rev >= 1e9) & (_ga.rev < 1e10)].gas.quantile(.05)),
                      p10_above10bn=float(_ga[_ga.rev >= 1e10].gas.quantile(.10)),
                      n_1to10bn=int(((_ga.rev >= 1e9) & (_ga.rev < 1e10)).sum()), n_above10bn=int((_ga.rev >= 1e10).sum()),
                      band_used=(0.005, 0.046), note='band set from the broader software and internet universe; not changed here')
d = d[d.period == '2023-25'].copy()
d['R'] = d.g + d.m_fcf_sbc
_p95 = float(d.R.quantile(.95))
_tail = d[d.R >= _p95]
assert abs(_p95 - _av['E1']['p95']) < 1e-12 and len(_tail) == _av['E1']['n_tail'] \
    and int((_tail.acq_flag_v3 == 0).sum()) == _av['E1']['n'] and abs(float(d.g.median()) - _av['E1']['G']) < 1e-12, \
    'E1 block of calibration_anchor_v3.json does not reproduce from data/panel_v3.csv'
ANCHOR_CENTRAL = 'E1'
ANCHOR_SENS = ['E1all', 'E2', 'E2imp4', 'E2imp8']
ANCHORS = {nm: {k: v for k, v in _av[nm].items() if k != 'firm_years'} for nm in [ANCHOR_CENTRAL] + ANCHOR_SENS}
ANCHOR_BOOT = {nm: _av['bootstrap'][nm] for nm in [ANCHOR_CENTRAL] + ANCHOR_SENS}
anchor = ANCHORS[ANCHOR_CENTRAL]
top = pd.DataFrame(_av[ANCHOR_CENTRAL]['firm_years'])   # anchor firm-years (tax-deduction sensitivity)
q3 = lambda s: [float(s.quantile(.25)), float(s.quantile(.5)), float(s.quantile(.75))]
G25 = anchor['G']

HZ = {
    '2028': dict(G=(0.10, 0.20), mu=(1.0, 2.0)),
    '2031': dict(G=(0.08, 0.20), mu=(0.75, 1.5)),
    '2036': dict(G=(0.05, 0.30), mu=(0.5, 1.25)),
}
HZ_OLD_M0 = {'2028': (0.40, 0.62), '2031': (0.45, 0.65), '2036': (0.50, M0_CAP_OLD)}


def Pi_scaled(Pi0, mu, alpha, k):
    return Pi0 * mu ** (1 / (1 - alpha)) * (1 - k) ** (1 / (1 - alpha))


Pi_ub = (max(anchor['Pi_ub'][0], 0.0), anchor['Pi_ub'][2])
Pi_lb = (max(anchor['Pi_lb'][0], 0.0), anchor['Pi_lb'][2])
m0A = (anchor['m0_ub'][0], anchor['m0_ub'][2])      # anchor interquartile ends, upper-bound case
# the full-cost margin terms move with the compute share, so the distance to them is horizon-specific
dM_lo = {int(h): M0_CEN[h] - m0A[0] for h in M0_CEN}
dM_hi = {int(h): M0_FAV[h] - m0A[1] for h in M0_FAV}
PL = pace(PACE['central'], dM_lo)
PH = pace(PACE['fast'], dM_hi)
PREV = {nm: pace(PACE_PREVIOUS[nm], dM_lo) for nm in PACE_PREVIOUS}     # pre-commit pace values, for comparison

# Pass-through: the saving passed to prices is the non-fee unit cost of revenue the program removes. U0 is today's
# (median core firm, 2023-25, data/panel_v3.csv: 1 - gross margin - fees); at full automation the unit cost is c_c.
GM0 = float((d.gp / d.rev).median())
U0 = 1.0 - GM0 - FC['f'][1]


def base_phi(c, phi):
    """Margin term of a ceiling case c (fullcost output) when a share 1 - dur(phi) of the variable-cost saving
    U0 - c_c is passed to output prices; non-discretionary savings are kept."""
    return c['base'] - (1 - c['tau']) * (1 - dur(phi)) * (U0 - c['c_c'])


def horizon(h, Pi_25, m0_pair, dip_pair, shift=0.0, psi=0.0):
    p = HZ[h]
    rec = {}
    for k_pre in [0.0, 0.5]:
        k = (1 - psi * TAU) * k_pre                  # after-tax capital intensity (Remark taxes)
        m0 = (m0_pair[0] - shift, m0_pair[1] - shift)
        Rinf = (m0[0] + (1 - k) * p['G'][0], m0[1] + (1 - k) * p['G'][1])
        Pi = (min(Pi_scaled(Pi_25[0], p['mu'][0], a, k) for a in ALPHAS),
              max(Pi_scaled(Pi_25[1], p['mu'][1], a, k) for a in ALPHAS))
        R = (Rinf[0] + Pi[0], Rinf[1] + Pi[1])
        rec[str(k_pre)] = dict(m0=m0, Rinf=Rinf, Pi=Pi, R=R, dip=dip_pair,
                           R_net=(R[0] - dip_pair[0], R[1] - dip_pair[1]))
    return rec


out = dict(anchor=anchor, anchor_estimand='E1, calibration rule (D-3); sensitivity blocks in anchor_sensitivity',
           anchor_sensitivity=ANCHORS, anchor_bootstrap=ANCHOR_BOOT,
           ceiling=CEIL, ceiling_basis='2025 prices (c_c with no price path); ceiling_by_horizon follows the compute-share path',
           ceiling_by_horizon=CEIL_H,
           compute_share={'path': CC_PATH, 'values': {h: dict(value=v[0], bounds=v[1], grounding=v[2], model=cc_path(h),
                                                              cases=CC_CASES[h]) for h, v in CC.items()},
                          'high_compute_case': dict(value=CC_HIGH, feasible_at_full_automation=CC_HIGH <= CC_VALUE_TEST_CAP,
                                                    value_test_cap=CC_VALUE_TEST_CAP),
                          'case_rule': 'favorable and conservative = central halved and doubled (class d composite rule)'},
           pace={'central': PL, 'fast': PH}, pace_previous=PREV, revealed_pace=REVEALED_PACE, amin_grounding=AMIN_GROUNDING,
           upper_bound={}, lower_bound={}, previous={'upper_bound': {}, 'lower_bound': {}})


def horizon_ranges(phi=0.0):
    """Upper- and lower-bound horizon ranges at pass-through phi: the intercept moves toward the full-cost margin
    terms net of the saving passed to prices (the in-flight dip is a cost, so it is not passed through)."""
    res = {'upper_bound': {}, 'lower_bound': {}}
    for h in HZ:
        yi = int(h)
        s_pair = (PL[yi]['s'], PH[yi]['s'])
        tgt = (base_phi(CEIL_H[h]['central'], phi), base_phi(CEIL_H[h]['favorable'], phi))
        m0_pair = (m0A[0] + s_pair[0] * (tgt[0] - m0A[0]), m0A[1] + s_pair[1] * (tgt[1] - m0A[1]))
        dip_pair = (PL[yi]['dip'], PH[yi]['dip'])
        for b, Pi25, sh in [('upper_bound', Pi_ub, 0.0), ('lower_bound', Pi_lb, anchor['shift'])]:
            res[b][h] = horizon(h, Pi25, m0_pair, dip_pair, shift=sh)
            res[b][h]['s'] = s_pair
            res[b][h]['m0_target'] = tgt
    return res


_r0 = horizon_ranges(0.0)                            # fixed prices: the case reported in Table tab:calib
for b in ['upper_bound', 'lower_bound']:
    out[b] = _r0[b]
    for h in HZ:
        out['previous'][b][h] = horizon(h, Pi_ub if b == 'upper_bound' else Pi_lb, HZ_OLD_M0[h], (0.0, 0.0),
                                        shift=0.0 if b == 'upper_bound' else anchor['shift'])
# pass-through scenario dimension: ceilings (static and by horizon) and horizon ranges for each phi
out['pass_through'] = {'phi': list(PHI), 'hhi': HHI, 'U0': U0, 'gross_margin_median_2023_25': GM0,
                       'rule': 'dur = 1 - phi (1 - HHI) of the variable-cost saving U0 - c_c is kept; a is not passed through'}
for phi in PHI:
    rr = horizon_ranges(phi)
    out['pass_through'][f'{phi:.1f}'] = dict(
        dur=dur(phi),
        ceiling={c: dict(base=base_phi(CEIL[c], phi), G100=1 - base_phi(CEIL[c], phi)) for c in CASES},
        ceiling_by_horizon={h: {c: dict(base=base_phi(CEIL_H[h][c], phi), G100=1 - base_phi(CEIL_H[h][c], phi))
                                for c in CASES} for h in CEIL_H},
        upper_bound=rr['upper_bound'], lower_bound=rr['lower_bound'])

# Regime and pace variants, on the central path of Table tab:calib (revision v2): the median anchor firm-year's
# upper-bound intercept moving toward the central full-cost margin term at each horizon, output prices fixed
dM_c = {int(h): base_phi(CEIL_H[h]['central'], 0.0) - anchor['m0_ub'][1] for h in HZ}
var = {}
var['central_fluid'] = pace_fluid(PACE['central'], dM_c)
var['public_guided_dip_1pt'] = pace_fluid(PACE['central'], dM_c, dip_budget=0.01)
var['public_guided_dip_2pt'] = pace_fluid(PACE['central'], dM_c, dip_budget=0.02)
var['sponsor_latency_0.5'] = pace(PACE['central'], dM_c, kap=0.78)
var['slow_public'] = pace(PACE['slow'], dM_c, kap=0.70)
var['slow_sponsor_latency_0.5'] = pace(PACE['slow'], dM_c, kap=0.78)
for name, v in var.items():
    v['m0'] = {h: anchor['m0_ub'][1] + v[h]['s'] * dM_c[h] for h in YEARS}
out['variants'] = var
out['variants_basis'] = 'central path: median anchor firm-year, upper bound, central full-cost target at each horizon'
# compute-share sensitivity (Corollary ceiling): central case over the scenario bounds of c_c, and tau at 9%
def G100_central(cc, tau=None):
    v = {k: val[1] for k, val in FC.items()}
    tau = v['tau'] if tau is None else tau
    c = fullcost('central')
    c_anc = v['s_fin'] * cc + v['anc_fixed'] / S_REF
    full = c['c_full'] - c['c_anc'] + c_anc
    return 1 - (1 - tau) * (1 - cc - v['f'] - v['a_min'] - full), 1 - (1 - tau) * (1 - cc - v['f'] - v['a_min'])
# grid: the credible bounds of every horizon (0.01 to the value-test cap 0.30), the centrals and the old central 0.20
CC_GRID = sorted({0.01, 0.02, 0.05, 0.06, 0.08, 0.12, 0.20, 0.25, CC_VALUE_TEST_CAP})
out['cc_sensitivity'] = {f'{cc:.2f}': G100_central(cc) for cc in CC_GRID}
out['cc_sensitivity_by_horizon'] = {h: {f'{cc:.2f}': G100_central(cc) for cc in sorted({v[1][0], v[0], v[1][1]})}
                                    for h, v in CC.items()}
out['tau_sensitivity'] = {f'{t:.2f}': G100_central(FC['c_c'][1], t) for t in [0.09, 0.15, 0.18, 0.21]}
out['cerr_sensitivity'] = {}
for nm, ce in [('favorable', fullcost('favorable')['c_err']), ('central', fullcost('central')['c_err']),
               ('conservative', fullcost('conservative')['c_err']),
               ('high rates, unit loss', 0.30 * (0.18 * 0.55 + 0.20 * 0.80) * 1.0)]:
    c = fullcost('central')
    v = {k: val[1] for k, val in FC.items()}
    out['cerr_sensitivity'][nm] = (ce, 1 - (1 - v['tau']) * (1 - v['c_c'] - v['f'] - v['a_min'] - c['c_full'] + c['c_err'] - ce))
out['amin_sensitivity'] = {}
for am in [0.005, 0.03, 0.046]:
    v = {k: val[1] for k, val in FC.items()}
    c = fullcost('central')
    out['amin_sensitivity'][f'{am:.3f}'] = (1 - (1 - v['tau']) * (1 - v['c_c'] - v['f'] - am - c['c_full']),
                                            1 - (1 - v['tau']) * (1 - v['c_c'] - v['f'] - am))

# Tax deductions for capital: anchor intercepts, k = 0.5 column and the ceiling's capital term under each psi
psi_out = {'psi': PSI, 'anchor_m0_ub': {}, 'anchor_m0_lb': {}, 'k05_upper_bound': {}, 'ceiling_k15_G30_loss': {}}
for nm, ps in PSI.items():
    psi_out['anchor_m0_ub'][nm] = q3(top.m_fcf_sbc + (1 - TAU) * top.sig_ub + (1 - ps * TAU) * top.kg)
    psi_out['anchor_m0_lb'][nm] = q3(top.m_fcf_sbc + (1 - ps * TAU) * top.kg)
    psi_out['k05_upper_bound'][nm] = {}
    for h in HZ:
        yi = int(h)
        s_pair = (PL[yi]['s'], PH[yi]['s'])
        m0_pair = (m0A[0] + s_pair[0] * dM_lo[yi], m0A[1] + s_pair[1] * dM_hi[yi])
        psi_out['k05_upper_bound'][nm][h] = horizon(h, Pi_ub, m0_pair, (PL[yi]['dip'], PH[yi]['dip']), psi=ps)['0.5']['R']
    psi_out['ceiling_k15_G30_loss'][nm] = {f'{t:.2f}': (1 - ps * t) * 1.5 * 0.30 for t in FC['tau']}
psi_out['anchor_tau_kg'] = q3(TAU * top.kg)
out['psi_sensitivity'] = psi_out

C = lambda a: (1 - a) * a ** (a / (1 - a))
out['Lambda_rule1000'] = {a: ((10 - (0.5 + 0.2)) / C(a)) ** (1 - a) for a in [0.2, 0.25, 0.3, 0.45]}
out['lam_for_Pi'] = {b: {a: (P[1] / C(a)) ** (1 - a) for a in ALPHAS} for b, P in [('ub', Pi_ub), ('lb', Pi_lb)]}
out['rule1000_multiple'] = {b: {a: out['Lambda_rule1000'][a] / out['lam_for_Pi'][b][a] for a in ALPHAS} for b in ['ub', 'lb']}


# ----------------------------------------------------------------------------------------------
# Central path and tornado (revision v2; revision plan A9 and D5, panel item EX-5). The ranges above pair the extreme
# ends of every assumption, and their upper ends in 2028 and 2031 scaled the lower-bound surplus, for which the model
# gives no basis (when no spend buys growth the surplus is not a return to spend). They are kept in the JSON for the
# record only. The paper reports a central path and one-at-a-time sensitivities instead.
# Central path: the median anchor firm-year's intercept m_0A (central anchor, both bounds on growth spend) moves toward
# the central full-cost margin term at each horizon at central execution, output prices fixed, k = 0, market growth G
# held at the anchor's median growth of 2023-25 (the horizon ranges of G enter the tornado). The durable score is R_inf = m_0 + G. A transient surplus is added only under
# the upper bound on spend, where the model's scaling Pi ~ mu^(1/(1-alpha)) applies; at the median anchor firm-year it
# is zero (Pi_ub median below zero, floored), so the central maximal score equals the durable score.
# ----------------------------------------------------------------------------------------------
ALPHA_C = 0.35
CEN = {h: dict(G=G25, mu=sum(HZ[h]['mu']) / 2) for h in HZ}   # G held at the anchor's median growth (firm-level reading)


def central_path(anc=None, bound='ub', q=1, pace_case='central', target_case='central', phi=0.0, k_pre=0.0, psi=0.0,
                 G=None, mu=None, alpha=ALPHA_C, pi_q=None):
    """Path of the durable score (and the surplus under the upper bound) for one anchor firm-year type.
    q: quartile index of the anchor intercept; pi_q: quartile index of the surplus (None: the same as q)."""
    anc = anchor if anc is None else anc
    m0A_ = anc['m0_' + bound][q]
    Pi25 = max(anc['Pi_ub'][q if pi_q is None else pi_q], 0.0) if bound == 'ub' else 0.0
    tgt = {h: base_phi(CEIL_H[h][target_case], phi) for h in HZ}
    P = pace(PACE[pace_case], {int(h): tgt[h] - m0A_ for h in HZ})
    k = (1 - psi * TAU) * k_pre
    res = {'m0A': m0A_, 'Pi25': Pi25, 'R25': anc['R'][1]}
    for h in HZ:
        yi = int(h)
        G_ = CEN[h]['G'] if G is None else G[h]
        mu_ = CEN[h]['mu'] if mu is None else mu[h]
        m0 = m0A_ + P[yi]['s'] * (tgt[h] - m0A_)
        Rinf = m0 + (1 - k) * G_
        Pi = Pi_scaled(Pi25, mu_, alpha, k)
        res[h] = dict(s=P[yi]['s'], target=tgt[h], m0=m0, G=G_, mu=mu_, Rinf=Rinf, Pi=Pi, R=Rinf + Pi,
                      dip=P[yi]['dip'], R_net=Rinf + Pi - P[yi]['dip'], running=P[yi]['running'])
    return res


CP = {b: central_path(bound=b) for b in ['ub', 'lb']}
CP_PHI = {f'{phi:.1f}': {b: central_path(bound=b, phi=phi) for b in ['ub', 'lb']} for phi in PHI}
CP_ANCHOR = {nm: {b: central_path(anc=ANCHORS[nm], bound=b) for b in ['ub', 'lb']} for nm in ANCHORS}
lo_hi = lambda key: ({h: HZ[h][key][0] for h in HZ}, {h: HZ[h][key][1] for h in HZ})
G_lo, G_hi = lo_hi('G')
MU_lo, MU_hi = lo_hi('mu')
TORNADO_ITEMS = [   # (key, label, low-case kwargs, high-case kwargs); the reference is the central path, upper bound
    ('anchor_quartile', 'Anchor intercept: lower and upper quartile', dict(q=0, pi_q=1), dict(q=2, pi_q=1)),
    ('surplus', 'Transient surplus of the upper-quartile firm-year, pull and $\\alpha$ at their ends',
     dict(pi_q=2, mu=MU_lo, alpha=0.25), dict(pi_q=2, mu=MU_hi, alpha=0.45)),
    ('G', 'Market growth $G$ at the ends of its range', dict(G=G_lo), dict(G=G_hi)),
    ('pace', 'Execution: slow and fast', dict(pace_case='slow'), dict(pace_case='fast')),
    ('target', 'Full-cost target: conservative and favorable case', dict(target_case='conservative'),
     dict(target_case='favorable')),
    ('pass_through', 'Pass-through $\\varphi=0.7$ (fixed prices at the central value)', dict(phi=0.7), dict()),
    ('capital', 'Capital $k=0.5$, not deductible', dict(k_pre=0.5, psi=0.0), dict()),
    ('attribution', 'No selling and marketing buys growth (lower bound on spend)', dict(bound='lb'), dict()),
]
TORNADO = {}
for h in HZ:
    ref = CP['ub'][h]['R']
    rows_t = []
    for key, lab, klo, khi in TORNADO_ITEMS:
        lo_ = central_path(**klo)[h]['R']
        hi_ = central_path(**khi)[h]['R']
        rows_t.append(dict(key=key, label=lab, low=min(lo_, hi_), high=max(lo_, hi_)))
    an = [CP_ANCHOR[nm]['ub'][h]['R'] for nm in ANCHOR_SENS]
    rows_t.append(dict(key='anchor_sample', label='Anchor sample: every firm-year of the tail, E2, $M=4$, $M=8$',
                       low=min(an), high=max(an)))
    rows_t.append(dict(key='dip', label='A firm still transforming (in-flight dip)', low=ref - CP['ub'][h]['dip'], high=ref))
    rows_t.sort(key=lambda r: -(r['high'] - r['low']))
    TORNADO[h] = dict(reference=ref, rows=rows_t)
out['central_path'] = dict(alpha=ALPHA_C, scenario=CEN, path=CP, pass_through=CP_PHI, by_anchor=CP_ANCHOR)
out['tornado'] = TORNADO

# ----------------------------------------------------------------------------------------------
# The frontier-slope mapping of Section model-industry (D-2; notes/theory_fixes_v2.md 1.10): under a common frontier
# with k = 0, the Psi_chi slope -b on the estimator's grid g0 = 0, 0.05, ..., W implies ell = (S_beta/b)^alpha, with S_beta
# the least-squares slope of Delta^beta on that grid, and a steepest slope beta W^(beta-1) b/S_beta at the window's end.
# The calibration inverts the model firm by firm and does not use ell; the mapping is recorded for the text.
# ----------------------------------------------------------------------------------------------
FS3 = json.load(open(v3path('notes', 'frontier_slope_v3.json')))


def ell_map(b, W, a):
    be = 1 / a
    g_ = np.arange(0, W + 1e-9, 0.05)
    S_ = float(np.polyfit(g_, g_ ** be, 1)[0])
    return dict(ell=(S_ / b) ** a, steepest=be * W ** (be - 1) * b / S_)


ELL_ROWS = {'E1_cash_w60': (abs(FS3['central']['cash']['E1']['est']), 0.6),
            'E1_op_w60': (abs(FS3['central']['op']['E1']['est']), 0.6),
            'E2_cash_w60': (abs(FS3['central']['cash']['E2']['est']), 0.6),
            'E2_op_w60': (abs(FS3['central']['op']['E2']['est']), 0.6),
            'E1_cash_w40': (abs(FS3['grid']['cash']['chi90_w40']['E1']['est']), 0.4),
            'E1_op_w40': (abs(FS3['grid']['op']['chi90_w40']['E1']['est']), 0.4)}
out['ell_psi'] = {r: {f'{a:.2f}': ell_map(b, W, a) for a in (0.25, 0.30, 0.35, 0.45)} | dict(b=b, W=W)
                  for r, (b, W) in ELL_ROWS.items()}


def rng(t):
    a, b = int(np.floor(100 * t[0] + 0.5)), int(np.floor(100 * t[1] + 0.5))
    if a == b:
        return f"{a}"
    return f"${a}$ to {b}" if a < 0 else f"{a}--{b}"


def rng0(t):
    a, b = int(np.floor(100 * t[0] + 0.5)), int(np.floor(100 * t[1] + 0.5))
    return f"{a}" if a == b else f"{a}--{b}"


iq = lambda v: rng((v[0], v[2]))


def dipr(dp):
    lo, hi = sorted(dp)
    f1 = lambda x: f"{100 * x:.1f}".replace('.0', '') if abs(100 * x) < 1e-9 else f"{100 * x:.1f}"
    return f"{f1(lo)}" if abs(lo - hi) < 5e-4 else f"{f1(lo)}--{f1(hi)}"
A = anchor
_rr = lambda dd: f"{int(np.floor(100 * min(dd.values()) + 0.5))}--{int(np.floor(100 * max(dd.values()) + 0.5))}"
pt = lambda x: f"{int(np.floor(100 * x + 0.5))}"                 # points, rounded half up
pt1 = lambda x: f"{np.floor(1000 * x + 0.5) / 10:.1f}"
sgn = lambda x: ('$-$' + pt(x)[1:]) if pt(x).startswith('-') else pt(x)


def ci_txt(bl, key):
    lo, hi = bl[key]['ci90']
    f = lambda x: ('$-$' if x < 0 else '$+$') + f"{abs(np.floor(1000 * x + 0.5) / 10):.1f}"
    return f"[{f(lo)}, {f(hi)}]"


B0 = ANCHOR_BOOT[ANCHOR_CENTRAL]
rows = [f"2025 (anchor) & -- & -- & {pt(A['m0_ub'][1])} & {pt(A['m0_ub'][1] + G25)} & "
        f"{pt(A['m0_lb'][1])} & {pt(A['m0_lb'][1] + G25)} & -- \\\\"]
for h in HZ:
    u, l_ = CP['ub'][h], CP['lb'][h]
    rows.append(f"{h} & {pt(u['s'])} & {pt(u['target'])} & {pt(u['m0'])} & {pt(u['R'])} & {pt(l_['m0'])} & {pt(l_['R'])} & "
                f"{pt1(u['dip']) if u['running'] else '0'} \\\\")
srow = []
lab = {'E1': 'E1, calibration rule (central)', 'E1all': 'E1, every firm-year of the tail', 'E2': 'E2, organic',
       'E2imp4': 'E2 plus imputed, $M=4$', 'E2imp8': 'E2 plus imputed, $M=8$'}
for nm in [ANCHOR_CENTRAL] + ANCHOR_SENS:
    an, bt = ANCHORS[nm], ANCHOR_BOOT[nm]
    srow.append(f"{lab[nm]} & {an['n']} ({an['n_firms']}) & {pt(an['m0_ub'][1])} & {sgn(an['Pi_ub'][1])} {ci_txt(bt, 'Pi_ub_med')} & "
                f"{pt(an['Pi_lb'][1])} {ci_txt(bt, 'Pi_lb_med')} & {pt(CP_ANCHOR[nm]['ub']['2036']['R'])} & "
                f"{pt(CP_ANCHOR[nm]['lb']['2036']['R'])} \\\\")
tab = r"""\begin{table}[t]\centering\small
\caption{Central path of the maximal Rule-of-40 score of an exceptional firm, at full cost and attainable pace (free-cash-flow-after-SBC basis, $X=1$, output prices fixed)}\label{tab:calib}
\resizebox{\textwidth}{!}{\begin{tabular}{lrrrrrrr}\toprule
 & \multicolumn{2}{c}{Program} & \multicolumn{2}{c}{All selling and marketing buys growth} & \multicolumn{2}{c}{None buys growth} & \\\cmidrule(lr){2-3}\cmidrule(lr){4-5}\cmidrule(lr){6-7}
Horizon & Realized $\bar b\,\mathcal E$ & Target $m_{0F}$ & $m_0$ & $R^*=R_\infty$ & $m_0$ & $R_\infty$ & Dip\\\midrule
""" + '\n'.join(rows) + r"""
\addlinespace\multicolumn{8}{l}{\emph{Anchor sample: 2025 medians and the 2036 central score}}\\
 & Firm-years (firms) & $m_0$ & $\Pi$, all buys growth & $\Pi$, none buys growth & \multicolumn{2}{c}{2036: $R^*$, all / $R_\infty$, none} & \\\midrule
""" + '\n'.join(r.replace(r' \\', r' & \\') for r in srow) + r"""
\bottomrule\end{tabular}}
\par\vspace{2pt}\footnotesize\raggedright Notes: Percentage points, rounded half up. The 2025 row inverts the model for the median of the """ + f"{A['n']}" + r""" firm-years of the audited sample at or above the 95th percentile of the 2023--25 cash score, without acquisition-affected firm-years (the calibration rule; Section~\ref{sec:empirics-anchor}): on the after-tax cash basis $m_0=m+(1-\tau)\sigma+kg$ with $\tau=""" + f"{TAU:g}" + r"""$, capital treated as not deductible ($\psi=0$), and $\sigma$ the selling-and-marketing share (all buys growth) or zero (none does); market growth at the anchor's median growth of """ + f"{pt1(G25)}" + r"""\%. Later rows: the central path, a scenario, not a forecast. The intercept moves toward the central full-cost margin term $m_{0F}$ at each horizon's compute share, $m_0=m_{0A}+\bar b\,\mathcal E\,(m_{0F}-m_{0A})$, with $\bar b\,\mathcal E$ the share of the program's benefits realized by the horizon under central execution (the upper bound of \autoref{prop:expected}(e)); $R_\infty=m_0+(1-k)G$ (\autoref{prop:optimum}) with $k=0$ and $G$ held at the anchor's median growth. A transient surplus is added only when all selling and marketing buys growth, where the model scales it by $\mu^{1/(1-\alpha)}$; at the median anchor firm-year it is zero, so the central maximal score is the durable score. Dip: the cost of the transitions in flight for a firm still transforming. Lower panel: medians of the surplus $\Pi=R-R_\infty$ with 90\% firm-cluster bootstrap intervals, and the central path from each sample's median intercept. Table~\ref{tab:tornado} gives the sensitivities.
\end{table}"""
open(f'{BASE}/sections/tables/tab_calib.tex', 'w').write(tab)

# Tornado (2036 and 2028), sorted by swing
def tornado_tex(h):
    T = TORNADO[h]
    lines = [f"{r['label']} & {pt(r['low'])} & {pt(r['high'])} & {pt(r['high'] - r['low'])} \\\\" for r in T['rows']]
    return lines, T['reference']


tl36, ref36 = tornado_tex('2036')
tl28, ref28 = tornado_tex('2028')
tabt = r"""\begin{table}[t]\centering\small
\caption{One-at-a-time sensitivity of the central maximal score (tornado), 2028 and 2036}\label{tab:tornado}
\begin{tabular}{@{}lrrr@{}}\toprule
Input moved to the ends of its range & Low & High & Swing\\\midrule
\multicolumn{4}{@{}l}{\emph{2036; central path """ + pt(ref36) + r"""}}\\
""" + '\n'.join(tl36) + r"""
\addlinespace\multicolumn{4}{@{}l}{\emph{2028; central path """ + pt(ref28) + r"""}}\\
""" + '\n'.join(tl28) + r"""
\bottomrule\end{tabular}
\par\vspace{2pt}\footnotesize\raggedright Notes: Points. Each row moves one input from the central path of Table~\ref{tab:calib} (all selling and marketing buys growth, $k=0$, central execution, the central full-cost target, fixed prices, $\alpha=""" + f"{ALPHA_C:g}" + r"""$) to the ends of its range, holding the others at their central values; rows sorted by swing. Ranges: anchor quartiles; $G$ and pull $\mu$ as in the scenario of each horizon (""" + '; '.join(f"{h}: $G$ {pt(HZ[h]['G'][0])}--{pt(HZ[h]['G'][1])}\\%, $\\mu$ {HZ[h]['mu'][0]:g}--{HZ[h]['mu'][1]:g}" for h in HZ) + r"""); slow and fast execution of Section~\ref{sec:horizons-ranges}; the conservative and favorable full-cost cases; pass-through $\varphi=0.7$ with a concentration of """ + f"{HHI:g}" + r"""; $k=0.5$ of capital per dollar of new revenue, not deductible ($\psi=0$), against the central $k=0$; the lower bound on growth spend; the four alternative anchor samples. One-sided rows compare one alternative with the central path. The surplus row adds the upper-quartile firm-year's transient surplus, which the median firm-year does not have, so both of its ends lie above the central path. All are scenario values.
\end{table}"""
open(f'{BASE}/sections/tables/tab_tornado.tex', 'w').write(tabt)

# Appendix Table tab:fullcost: every numeric cell written from FC and fullcost() (between markers in appendix_proofs.tex,
# where code/verify_theory.py check 20a reads it)
F = {c: fullcost(c) for c in CASES}
v3c = lambda key, fmt_: ' & '.join(fmt_(FC[key][i]) for i in range(3))
two = lambda x: f"{100 * x:.2f}"
g3 = lambda x: f"{x:g}"
FT = [
    r"\multicolumn{5}{@{}l}{\emph{Security, $c_{\mathrm{sec}}$}}\\",
    r"Security spending today, $c^{\rm sp}_0$ & " + v3c('s0', two) + r" & (a) survey of security officers, flagged\\",
    r"Control effectiveness $L_{\rm sec}$ & " + v3c('L0', g3) + r" & (d) controls remove " + ', '.join(f"{100 * (1 - math.exp(-x)):.0f}" for x in FC['L0']) + r"\% of loss\\",
    r"Exposure multiplier at full automation $\xi_{\rm exp}$ & " + v3c('Me', g3) + r" & (d) draft, write and transact rights\\",
    r"Risk cost $(c^{\rm sp}_0/L_{\rm sec})(1+L_{\rm sec}+\ln\xi_{\rm exp})$ & " + ' & '.join(two(F[c]['risk']) for c in CASES[:3]) + r" & Lemma~\ref{lem:fullcost}(b)\\",
    r"Post-quantum migration & " + ' & '.join(two(F[c]['pqc']) for c in CASES[:3]) + r" & (d) " + ', '.join(f"{100 * x:g}" for x in FC['phi_pqc']) + r"\% of IT spend a year; IT spend $c^{\rm sp}_0$ over the security share (a); windows in \citet{moody2026transition}; only public-sector estimates exist \citep{omb2024report}\\",
    r"AI compliance at \$1 billion of revenue & " + ' & '.join(two(F[c]['aic']) for c in CASES[:3]) + r" & vendor estimates for security attestation and ISO/IEC 42001, flagged; AI risk-framework staff, red-teaming and privacy assessments for 48 processes (d)\\",
    r"$c_{\mathrm{sec}}$ & " + ' & '.join(two(F[c]['c_sec']) for c in CASES[:3]) + r" & \\",
    r"\multicolumn{5}{@{}l}{\emph{Maintenance and revalidation, $c_{\mathrm{mnt}}$}}\\",
    r"Upkeep $\delta_M$ (share of builds a year) & " + v3c('delta_M', lambda x: f"{x:.2f}") + r" & (b) \citet{svanberg2024beyond}; software support fees\\",
    r"Revalidation cost per build $\varrho_{\rm rv}$ & " + v3c('kappa_rv', lambda x: f"{x:.2f}") + r" & (d)\\",
    r"Model-upgrade interval $T_{\mathrm{up}}$ (years) & " + v3c('T_up', lambda x: f"{x:.2f}") + r" & (c) vendor retirement dates\\",
    r"Builds $c_{\rm bld}$ & " + v3c('B', lambda x: f"{100 * x:.1f}") + r" & 48 processes at \$0.5 million (b), at \$1 billion of revenue (d)\\",
    r"$c_{\mathrm{mnt}}=(\delta_M+\varrho_{\rm rv}/T_{\mathrm{up}})c_{\rm bld}$ & " + ' & '.join(two(F[c]['c_mnt']) for c in CASES[:3]) + r" & Lemma~\ref{lem:fullcost}(a)\\",
    r"\multicolumn{5}{@{}l}{\emph{AI failure, $c_{\mathrm{err}}$}}\\",
    r"Error rate with no review $\bar u=\varepsilon^{\rm o}+\varepsilon^{\rm h}$ (per unit) & " + v3c('u_rev', lambda x: f"{x:.3f}") + r" & (a, b) omission and hallucination rates of retrieval-grounded work; no review at full automation, Lemma~\ref{lem:fullcost}(c)\\",
    r"Loss per undetected error $L_{\rm err}$ (multiple of the unit's cost) & " + v3c('ell_e', g3) + r" & (d)\\",
    r"Errors and hallucination, $W_A\bar uL_{\rm err}$, with $W_A=" + f"{100 * FC['A_auto'][1]:g}" + r"\%$ (d) & " + ' & '.join(two(F[c]['c_err_e']) for c in CASES[:3]) + r" & Lemma~\ref{lem:fullcost}(c)\\",
    r"Misbehavior, $W_A\varepsilon^{\rm m}(1-d^{\rm m})L_{\rm mis}\mathbb E\min\{Y,\bar Y\}$ & " + ' & '.join(two(F[c]['c_err_m']) for c in CASES[:3]) + r" & $\varepsilon^{\rm m}$ " + ', '.join(f"{100 * x:g}" for x in FC['mu_m']) + r"\% per task and $L_{\rm mis}=" + f"{FC['ell_m'][1]:g}" + r"$, $\bar Y=" + f"{FC['Zcap'][1]:g}" + r"$ (d); recall $d^{\rm m}$ " + ', '.join(f"{x:g}" for x in FC['d_m']) + r" (a); tail index $p_Y$ " + ', '.join(f"{x:g}" for x in FC['p_tail']) + r" (b); Lemma~\ref{lem:fullcost}(d)\\",
    r"Common-mode failures, $\nu_{\rm cm}T_{\rm con}[W_{\rm cm}+H_{\rm cm}W_{\rm cm}^2/(2Y_{\rm fb})]$ & " + ' & '.join(two(F[c]['c_err_cm']) for c in CASES[:3]) + r" & " + ', '.join(f"{x:g}" for x in FC['nu_cm']) + r" day-long provider incidents a year (b); $W_{\rm cm}=W_A$, $W_{\rm cm}/(2Y_{\rm fb})=1$, one provider (d); Lemma~\ref{lem:fullcost}(e)\\",
    r"$c_{\mathrm{err}}$ & " + ' & '.join(two(F[c]['c_err']) for c in CASES[:3]) + r" & \\",
    r"\multicolumn{5}{@{}l}{\emph{Other, $c_{\mathrm{anc}}$}}\\",
    r"Management of AI spend (share of $c_c$) & " + v3c('s_fin', lambda x: f"{100 * x:g}") + r" & (d)\\",
    r"$c_{\mathrm{anc}}$, with fixed incident-response and legal costs & " + ' & '.join(two(F[c]['c_anc']) for c in CASES[:3]) + r" & (d); high-compute case " + two(F['high compute']['c_anc']) + r"\\",
    r"\midrule",
    r"$c_{\mathrm{full}}$ & " + ' & '.join(two(F[c]['c_full']) for c in CASES[:3]) + r" & high-compute case " + two(F['high compute']['c_full']) + r"\\",
]
_ap = f'{BASE}/sections/appendix_proofs.tex'
_src = open(_ap).read()
_B, _E = '% BEGIN ROWS GENERATED BY code/calibrate_horizons.py (tab:fullcost); do not edit by hand\n', '% END ROWS GENERATED\n'
if _B not in _src:                                   # first run: replace the hand-typed rows
    i0 = _src.index('\\multicolumn{5}{@{}l}{\\emph{Security, $c_{\\mathrm{sec}}$}}\\\\')
    i1 = _src.index('\\bottomrule', i0)
    _src = _src[:i0] + _B + _E + _src[i1:]
i0 = _src.index(_B) + len(_B)
i1 = _src.index(_E)
_src = _src[:i0] + '\n'.join(FT) + '\n' + _src[i1:]
open(_ap, 'w').write(_src)


def _clean(o):
    if isinstance(o, dict):
        return {str(k): _clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_clean(v) for v in o]
    if isinstance(o, (np.floating, np.integer, np.bool_)):
        return o.item()
    return o


json.dump(_clean(out), open(f'{BASE}/notes/calibration_results.json', 'w'), indent=1)
print(json.dumps({k: v for k, v in anchor.items() if k != 'firms'}, indent=0))
print(anchor['firms'])
print('\n'.join(rows)); print('\n'.join(srow)); print('\n'.join(tl36))
for c, v in CEIL.items():
    print(f"ceiling {c:12s}: c_full={100 * v['c_full']:.2f} (mnt {100 * v['c_mnt']:.2f}, sec {100 * v['c_sec']:.2f}, "
          f"err {100 * v['c_err']:.2f}, anc {100 * v['c_anc']:.2f}); margin term {100 * v['base']:.2f} "
          f"(accountability only {100 * v['base_acc']:.2f}); G for 100: {100 * v['G100']:.2f}% ({100 * v['G100_acc']:.2f}%)")
for nm, P in [('central', PL), ('fast', PH)]:
    print(nm, {k: (round(v, 4) if isinstance(v, float) else v) for k, v in P.items() if not isinstance(k, int)},
          {h: {kk: round(vv, 4) for kk, vv in P[h].items() if not isinstance(vv, bool)} for h in YEARS})
for b in ['upper_bound', 'lower_bound']:
    print(b, 'NEW', {h: (rng(v['0.0']['R']), rng(v['0.0']['Rinf']), rng(v['0.0']['Pi']), rng(v['0.5']['R']),
                         rng(v['0.0']['R_net'])) for h, v in out[b].items()})
    print(b, 'OLD', {h: (rng(v['0.0']['R']), rng(v['0.0']['Rinf']), rng(v['0.0']['Pi']), rng(v['0.5']['R']))
                     for h, v in out['previous'][b].items()})
for name, v in var.items():
    print(name, {h: (round(v[h]['s'], 4), round(100 * v['m0'][h], 2), round(100 * v[h]['dip'], 2)) for h in YEARS},
          'binding', v['binding'], 'rho', round(v['rho'], 4))
print('c_c sensitivity (G* full cost, accountability only):', {k: tuple(round(100 * x, 2) for x in v) for k, v in out['cc_sensitivity'].items()})
print('tau sensitivity:', {k: tuple(round(100 * x, 2) for x in v) for k, v in out['tau_sensitivity'].items()})
for h, cs in CEIL_H.items():
    print(f"ceiling {h}: " + "; ".join(f"{c} c_c {100 * v['c_c']:.1f}, margin term {100 * v['base']:.2f}, G* {100 * v['G100']:.2f}% "
                                       f"({100 * v['G100_acc']:.2f}%)" for c, v in cs.items()))
for phi in PHI:
    pt = out['pass_through'][f'{phi:.1f}']
    print(f"pass-through phi = {phi:g} (dur {pt['dur']:.3f}): central G* 2025 prices {100 * pt['ceiling']['central']['G100']:.2f}%, "
          + ", ".join(f"{h} {100 * pt['ceiling_by_horizon'][h]['central']['G100']:.2f}%" for h in CEIL_H)
          + "; upper bound R* " + ", ".join(f"{h} {rng(v['0.0']['R'])}" for h, v in pt['upper_bound'].items())
          + "; lower bound R* " + ", ".join(f"{h} {rng(v['0.0']['R'])}" for h, v in pt['lower_bound'].items()))
for nm, P in PREV.items():
    print('pace before the params commit', nm, {k: (round(v, 4) if isinstance(v, float) else v) for k, v in P.items()
                                                if k in ('q', 'eff_rate', 'cross_years', 'complete_year')},
          {h: round(P[h]['s'], 4) for h in YEARS})
print('revealed pace reference (class c, panel_v3):', REVEALED_PACE['gaap_op_margin'])
print('c_err sensitivity (c_err, central G*):', {k: tuple(round(100 * x, 2) for x in v) for k, v in out['cerr_sensitivity'].items()})
print('psi:', {k: round(v, 4) for k, v in PSI.items()})
print('psi anchor m0_ub quartiles:', {k: [round(100 * x, 2) for x in v] for k, v in psi_out['anchor_m0_ub'].items()},
      'tau kg quartiles', [round(100 * x, 2) for x in psi_out['anchor_tau_kg']])
print('psi k=0.5 column (upper bound):', {k: {h: rng(r) for h, r in v.items()} for k, v in psi_out['k05_upper_bound'].items()})
print('psi ceiling loss at k=1.5, G=0.30:', {k: {t: round(100 * x, 2) for t, x in v.items()} for k, v in psi_out['ceiling_k15_G30_loss'].items()})
print('a_min sensitivity:', {k: tuple(round(100 * x, 2) for x in v) for k, v in out['amin_sensitivity'].items()})
print(out['Lambda_rule1000'], out['lam_for_Pi'], out['rule1000_multiple'])
